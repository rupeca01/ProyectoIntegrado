﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Usuario
    {
        private int idUsuario;
        private string nombre;
        private string apellidos;
        private string correo;
        private string contrasenya;
        private decimal altura;
        private decimal peso;
        private DateTime fechaNacimiento;

        public int IdUSuario { get { return idUsuario; } set { idUsuario = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public string Apellidos { get { return apellidos; } set { apellidos = value; } }
        public string Correo { get { return correo; } set { correo = value; } }
        public string Contrasenya { get { return contrasenya; } set { contrasenya = value; } }
        public decimal Altura { get { return altura; } set { altura = value; } }
        public decimal Peso { get { return peso; } set { peso = value; } }

        public Usuario()
        {

        }
    }
}
