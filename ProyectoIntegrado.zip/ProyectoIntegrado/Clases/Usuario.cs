﻿using aev7;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Usuario
    {
        private int idUsuario;
        private string nombre;
        private string apellidos;
        private string correo;
        private string contrasenya;
        private decimal altura;
        private decimal peso;
        private DateTime fechaNacimiento;
        private string sexo;
        private byte[] fotoPerfil;
        private string objetivo;

        public int IdUSuario { get { return idUsuario; } set { idUsuario = value; } }
        public DateTime FechaNacimiento { get { return fechaNacimiento; } set { fechaNacimiento = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public byte[] FotoPerfil { get { return fotoPerfil; } set { fotoPerfil = value; } }
        public string Sexo { get { return sexo; } set { sexo = value; } }
        public string Objetivo { get { return objetivo; } set { objetivo = value; } }
        public string Apellidos { get { return apellidos; } set { apellidos = value; } }
        public string Correo { get { return correo; } set { correo = value; } }
        public string Contrasenya { get { return contrasenya; } set { contrasenya = value; } }
        public decimal Altura { get { return altura; } set { altura = value; } }
        public decimal Peso { get { return peso; } set { peso = value; } }

        public Usuario()
        {

        }

        public Usuario(int id, string nom, string ape, string corr, string contra, decimal alt, decimal pes, DateTime fech, string sex)
        {
            this.idUsuario = id;
            this.nombre = nom;
            this.apellidos = ape;
            this.correo = corr;
            this.contrasenya = contra;
            this.altura = alt;
            this.peso = pes;
            this.fechaNacimiento = fech;
            this.sexo = sex;
        }
        public Usuario(int id)
        {
            this.idUsuario = id;
        }
        public Usuario(int id, string nom, string ap, string corr, string contra, DateTime fech) //Constructor provisional sin la foto
        {
            this.idUsuario = id;
            this.nombre = nom;
            this.apellidos = ap;
            this.correo = corr;
            this.contrasenya = contra;
            this.fechaNacimiento = fech;
        }

        public static List<Usuario> BuscarUsuario(string consulta)
        {
            List<Usuario> lista = new List<Usuario>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.

            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Usuario user = new Usuario(reader.GetInt32(0), reader.GetString(1), reader.GetString(2),
                        reader.GetString(3), reader.GetString(4), reader.GetDateTime(5));
                    lista.Add(user);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }

        public static bool ValidarUsuario(string consulta)
        {

            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);

            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                reader.Close();
                return true;

            }
            else
            {
                reader.Close();
                return false;
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
        }

        public int AgregarUsuario(Usuario usu) //Agrega el usuario a la bd
        {
            int retorno;
            string consulta = String.Format("INSERT INTO usuario (nombre,apellidos,correo,sexo,contraseña,fecha_nacimiento) VALUES " +
                "('{0}','{1}','{2}','{3}','{4}','{5}')", usu.nombre, usu.apellidos, usu.correo, usu.sexo, usu.contrasenya, usu.fechaNacimiento.ToString("yyyy/MM/dd"));

            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);

            retorno = comando.ExecuteNonQuery();

            return retorno;
        }

        //static public int Dieta(decimal peso, decimal altura, DateTime fecha, string objetivo, string correo, int id) //Agrega altura, peso, y fecha nacimiento a la bd y crea la dieta
        //{
        //    int retorno;
        //    string consulta = String.Format("UPDATE usuario SET (peso,altura,fecha_nacimiento) VALUES " +
        //        "('{0}','{1}','{2}' WHERE correo LIKE '{3}')", peso, altura, fecha, correo);
        //    string consulta2 = String.Format("INSERT INTO dieta (objetivo, idUsuario) VALUES ('{0}', '{1}')", objetivo, id);

        //    MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
        //    MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);

        //    retorno = comando.ExecuteNonQuery() + comando2.ExecuteNonQuery();

        //    return retorno;
        //}

        static public int Dieta(Usuario usu, string obj)
        {
            int retorno = 0;
            int idDieta = 0;

            string consulta = String.Format("UPDATE usuario SET peso = {0}, altura = {1} WHERE correo LIKE '{2}'", usu.peso, usu.altura, usu.correo); //Añade el peso y la altura al usuario.
            string consulta2 = String.Format("INSERT INTO dieta (objetivo, idUsuario, fecha_inicio, fecha_finalizacion) VALUES ('{0}', '{1}', '{2}', '{3}')", obj, usu.idUsuario, DateTime.Today.ToString("yyyy/MM/dd"), DateTime.Today.AddMonths(1).ToString("yyyy/MM/dd")); //Crea la dieta en la bd.        
            string consulta4 = String.Format("SELECT idDieta FROM dieta WHERE idUsuario LIKE {0}", usu.idUsuario);




            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);

            MySqlCommand comando4 = new MySqlCommand(consulta4, ConexionBD.Conexion);
            retorno += comando.ExecuteNonQuery() + comando2.ExecuteNonQuery();
            MySqlDataReader reader = comando4.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    idDieta = reader.GetInt32(0);
                }
                reader.Close();
            }
            reader.Close();

            string consulta3 = String.Format("UPDATE usuario SET idDieta = {0} WHERE idUsuario LIKE {1} ", idDieta, usu.idUsuario); //Añade la id de dieta a la tabla usuario
            MySqlCommand comando3 = new MySqlCommand(consulta3, ConexionBD.Conexion);

            retorno += comando3.ExecuteNonQuery();
            return retorno;
        }

        static public Usuario CargaUsuario(string corr) //Funcion que instancia un usuario con sus datos de la bd a partir del correo con el que se inició sesión
        {
            string consulta = String.Format("SELECT * FROM usuario WHERE correo LIKE '{0}'", corr);
            Usuario usu = new Usuario();
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    usu = new Usuario(reader.GetInt32(0),reader.GetString(2),reader.GetString(3),reader.GetString(6),
                        reader.GetString(7),reader.GetDecimal(8),reader.GetDecimal(9),reader.GetDateTime(4),reader.GetString(5)); //REVISAR, DA ERROR!!!
                }
                reader.Close();

            }
            reader.Close();
            return usu;
        }
        static public int ActualizaDatos(Usuario usu)
        {
            int retorno = 0;
            string consulta = String.Format("UPDATE usuario SET peso = {0}, altura = {1} WHERE correo LIKE '{2}'", usu.peso, usu.altura, usu.correo); //Añade el peso y la altura al usuario.
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }

        static public List<Usuario> BuscarID(string corr)
        {
            List<Usuario> lista = new List<Usuario>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Usuario user = new Usuario(reader.GetInt32(0));
                    lista.Add(user);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }

        public int CalcularEdad()
        {
            // Save today's date.
            var today = DateTime.Today;

            // Calculate the age.
            var age = today.Year - fechaNacimiento.Year;

            // Go back to the year in which the person was born in case of a leap year
            if (fechaNacimiento.Date > today.AddYears(-age)) age--;
            return age;
        }
    }
}
