﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Alimento
    {
        private decimal calorias;
        private decimal cantidad;
        private string nombre;
        private string tipo;

        public decimal Calorias { get { return calorias; } set { calorias = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public string Tipo { get { return tipo; } set { tipo = value; } }
        public decimal Cantidad { get { return cantidad; } set { cantidad = value; } }
    }
}
