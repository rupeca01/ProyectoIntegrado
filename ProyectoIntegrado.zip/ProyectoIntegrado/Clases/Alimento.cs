﻿using aev7;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Alimento
    {
        private decimal calories;
        private decimal quantity;
        private string name;

        public decimal Calories { get { return calories; } set { calories = value; } }
        public string Name { get { return name; } set { name = value; } }
        public decimal Quantity { get { return quantity; } set { quantity = value; } }

        public Alimento(decimal cal, string nom, decimal cant)
        {
            this.calories = cal;
            this.name = nom;
            this.quantity = cant;
        }


        static public List<Alimento> BuscarAlimentos(string tipo)
        {
            List<Alimento> lista = new List<Alimento>();
            string consulta = String.Format("SELECT calorias, nombre, cantidad FROM alimentos WHERE tipo_Alimentos LIKE '{0}'", tipo);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecuto el comando y recibo en un DataReader la lista de registros seleccionados.
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader y cargamos la lista de alimentos.
                while (reader.Read())
                {
                    Alimento alim = new Alimento(reader.GetDecimal(0),reader.GetString(1),reader.GetDecimal(2));
                    lista.Add(alim);
                }
            }

            // devolvemos la lista cargada con los usuarios.
            return lista;
        }
    }
}
