﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Comidas
    {
       /* public int GenerarDesayuno(string tipoDieta)
        {

        }

        public int GenerarAlmuerzo(string tipoDieta)
        {

        }

        public int GenerarComida(string tipoDieta)
        {

        }

        public int GenerarMerienda(string tipoDieta)
        {

        }

        public int GenerarCena(string tipoDieta)
        {

        } */
    }
}
