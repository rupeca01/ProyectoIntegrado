﻿using aev7;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Comidas
    {
        static public double GenerarCaloriasDiarias(string sexo, decimal peso, decimal altura, int edad, string objetivo)
        {
            double calorias = 0;
            if (sexo == "male")
            {
                calorias = Convert.ToDouble(66 + (13.7 * Convert.ToDouble(peso)) + Convert.ToDouble(5 * altura) - (6.8 * edad));
                calorias = calorias * 1.375;
                if (objetivo.ToLower() == "Gain muscle")
                {
                    calorias += 200;
                }
                else if (objetivo.ToLower() == "Lose weight")
                {
                    calorias -= 200;
                }
            }
            else
            {
                calorias = Convert.ToDouble(65 + (9.6 * Convert.ToDouble(peso)) + (1.8 * Convert.ToDouble(altura)) - (4.7 * edad));
                calorias = calorias * 1.375;
                if (objetivo == "Gain muscle")
                {
                    calorias += 200;
                }
                else if (objetivo == "Lose weight")
                {
                    calorias -= 200;
                }
            }
            return calorias;
        }



        static public double calcularProteinas(decimal peso)
        {
            double gramosP = 0;
            gramosP = Convert.ToDouble(peso) * 2.2;
            double caloriasP = gramosP * 4;
            return caloriasP;
        }
        static public double calcularGrasas(decimal peso)
        {
            double gramosG = 0;
            gramosG = Convert.ToDouble(peso) * 1;
            double caloriasG = gramosG * 9;
            return caloriasG;
        }
        static public double calcularHidratosCarbono(string sexo, decimal peso, decimal altura, int edad, string objetivo)
        {
            double caloriasHC = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) - calcularProteinas(peso) - calcularGrasas(peso);
            return caloriasHC;
        }



        static public string GenerarDesayuno(decimal peso, string sexo, decimal altura, int edad, string objetivo)
        {
            double caloriasDesayuno = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) * 0.3;
            double proteinasDesayuno = calcularProteinas(peso) * 0.3;
            double grasasDesayuno = calcularGrasas(peso) * 0.3;
            double carbohDesayuno = calcularHidratosCarbono(sexo, peso, altura, edad, objetivo) * 0.3;



            string desayuno = caloriasDesayuno.ToString("F") + " total calories\n\r " + proteinasDesayuno.ToString("F") + " proteins " + grasasDesayuno.ToString("F") + " fats " + carbohDesayuno.ToString("F") + " carbohydrates";
            return desayuno;
        }
        static public string GenerarAlmuerzo(decimal peso, string sexo, decimal altura, int edad, string objetivo)
        {
            double caloriasAlmuerzo = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) * 0.1;
            double proteinasAlmuerzo = calcularProteinas(peso) * 0.1;
            double grasasAlmuerzo = calcularGrasas(peso) * 0.1;
            double carbohAlmuerzo = calcularHidratosCarbono(sexo, peso, altura, edad, objetivo) * 0.1;



            string almuerzo = caloriasAlmuerzo.ToString("F") + " total calories\n\r " + proteinasAlmuerzo.ToString("F") + " proteins " + grasasAlmuerzo.ToString("F") + " fats " + carbohAlmuerzo.ToString("F") + " carbohydrates";
            return almuerzo;
        }



        static public string GenerarComida(decimal peso, string sexo, decimal altura, int edad, string objetivo)
        {
            double caloriasComida = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) * 0.3;
            double proteinasComida = calcularProteinas(peso) * 0.3;
            double grasasComida = calcularGrasas(peso) * 0.3;
            double carbohComida = calcularHidratosCarbono(sexo, peso, altura, edad, objetivo) * 0.3;



            string comida = caloriasComida.ToString("F") + " total calories\n\r " + proteinasComida.ToString("F") + " proteins " + grasasComida.ToString("F") + " fats " + carbohComida.ToString("F") + " carbohydrates";
            return comida;
        }



        static public string GenerarMerienda(decimal peso, string sexo, decimal altura, int edad, string objetivo)
        {
            double caloriasMerienda = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) * 0.1;
            double proteinasMerienda = calcularProteinas(peso) * 0.1;
            double grasasMerienda = calcularGrasas(peso) * 0.1;
            double carbohMerienda = calcularHidratosCarbono(sexo, peso, altura, edad, objetivo) * 0.1;



            string merienda = caloriasMerienda.ToString("F") + " total calories\n\r " + proteinasMerienda.ToString("F") + " proteins " + grasasMerienda.ToString("F") + " fats " + carbohMerienda.ToString("F") + " carbohydrates";
            return merienda;
        }



        static public string GenerarCena(decimal peso, string sexo, decimal altura, int edad, string objetivo)
        {
            double caloriascena = GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo) * 0.2;
            double proteinasCena = calcularProteinas(peso) * 0.2;
            double grasasCena = calcularGrasas(peso) * 0.2;
            double carbohCena = calcularHidratosCarbono(sexo, peso, altura, edad, objetivo) * 0.2;



            string cena = caloriascena.ToString("F") + " total calories\n\r " + proteinasCena.ToString("F") + " proteins " + grasasCena.ToString("F") + " fats " + carbohCena.ToString("F") + " carbohydrates";
            return cena;
        }

        static public int SubirComidas(string desayuno, string almuerzo, string comida, string merienda, string cena, string correo) //Agrega las opciones del usuario a la bd
        {
            int retorno;
            int idD = 0;
            string consulta1 = String.Format("SELECT idDieta FROM usuario WHERE correo LIKE '{0}'", correo);
            MySqlCommand comando1 = new MySqlCommand(consulta1, ConexionBD.Conexion);
            MySqlDataReader reader1 = comando1.ExecuteReader();
            if (reader1.HasRows)
            {
                while (reader1.Read())
                {
                    idD = reader1.GetInt32(0);
                }
                reader1.Close();
            }
            reader1.Close();

            string consulta2 = String.Format("INSERT INTO comida (idDieta, desayuno, almuerzo, comidaa, merienda, cena) VALUES ({0}, '{1}', '{2}', '{3}', '{4}', '{5}')"
                                                , idD, desayuno, almuerzo, comida, merienda, cena);
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            retorno = comando2.ExecuteNonQuery();

            return retorno;
        }
        static public string BajarComidas(string comida, string correo)
        {
            string retorno = "";
            int idD = 0;
            string consulta1 = String.Format("SELECT idDieta FROM usuario WHERE correo LIKE '{0}'", correo);
            MySqlCommand comando1 = new MySqlCommand(consulta1, ConexionBD.Conexion);
            MySqlDataReader reader1 = comando1.ExecuteReader();
            if (reader1.HasRows)
            {
                while (reader1.Read())
                {
                    idD = reader1.GetInt32(0);
                }
                reader1.Close();
            }
            reader1.Close();

            string consulta2 = String.Format("SELECT {0} FROM comida WHERE idDieta LIKE {1}", comida, idD);
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    retorno = reader2.GetString(0);
                }
                reader2.Close();

            }
            reader2.Close();
            return retorno;
        }
    }
}
