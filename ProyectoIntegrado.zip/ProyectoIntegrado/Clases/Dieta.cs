﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Dieta
    {

        private int idDieta;
        private int idUsuario;
        private string objetivo;
        private DateTime fecha_Inicio;
        private DateTime fecha_Final;


        public int IdDieta { get { return idDieta; } set { idDieta = value; } }

        public int IdUsuario { get { return idUsuario; } set { idDieta = value; } }

        public string Objetivo { get { return objetivo; } set { objetivo = value; } }

        public DateTime Fecha_Inicio { get { return fecha_Inicio; } set { fecha_Inicio = value; } }

        public DateTime Fecha_Final{ get { return fecha_Final; } set { fecha_Final = value; } }

        public Dieta()
        {

        }
        
    }   
}
