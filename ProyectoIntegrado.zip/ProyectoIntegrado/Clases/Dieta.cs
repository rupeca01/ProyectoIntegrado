﻿using aev7;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Dieta
    {

        private int idDieta;
        private int idUsuario;
        private string objetivo;
        private DateTime fecha_Inicio;
        private DateTime fecha_Final;


        public int IdDieta { get { return idDieta; } set { idDieta = value; } }

        public int IdUsuario { get { return idUsuario; } set { idDieta = value; } }

        public string Objetivo { get { return objetivo; } set { objetivo = value; } }

        public DateTime Fecha_Inicio { get { return fecha_Inicio; } set { fecha_Inicio = value; } }

        public DateTime Fecha_Final{ get { return fecha_Final; } set { fecha_Final = value; } }

        public Dieta()
        {

        }

        public Dieta(int idD)
        {
            this.idDieta = idD;
        }

        public static List<Dieta> BuscarDieta(int idUs) //Versión que recibe el id del usuario y devuelve la lista de sus dietas.
        {
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta = String.Format("SELECT idDieta FROM dieta WHERE idUsuario LIKE {0}", idUs);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Dieta d1 = new Dieta(reader.GetInt32(0));
                    lista.Add(d1);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }


        public static List<Dieta> BuscarDieta(string corr) //Versión que recibe el correo del usuario y devuelve la lista de sus dietas.
        {
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.

            string consulta = String.Format("SELECT idDieta FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Dieta d1 = new Dieta(reader.GetInt32(0));
                    lista.Add(d1);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }

        public static string FechaInicio(string corr) //Función que retorna la fecha de inicio de la dieta desde la bd
        {
            string retorno="";
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            string consulta = String.Format("SELECT fecha_inicio FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    retorno = reader.GetString(0);
                }
                reader.Close();
            }
            reader.Close();
            return retorno;
        }

        public static string FechaFinal(string corr) //Función que retorna la fecha de finalización de la dieta desde la bd
        {
            string retorno = "";
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            string consulta = String.Format("SELECT fecha_finalizacion FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    retorno = reader.GetString(0);
                }
                reader.Close();
            }
            reader.Close();
            return retorno;
        }

    }   
}
