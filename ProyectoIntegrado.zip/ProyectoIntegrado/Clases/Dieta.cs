﻿using aev7;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases
{
    class Dieta
    {

        private int idDieta;
        private int idUsuario;
        private DateTime fecha_Inicio;
        private DateTime fecha_Final;


        public int IdDieta { get { return idDieta; } set { idDieta = value; } }

        public int IdUsuario { get { return idUsuario; } set { idDieta = value; } }

        public DateTime Fecha_Inicio { get { return fecha_Inicio; } set { fecha_Inicio = value; } }

        public DateTime Fecha_Final{ get { return fecha_Final; } set { fecha_Final = value; } }

        public Dieta()
        {

        }

        public Dieta(int idD)
        {
            this.idDieta = idD;
        }

        public static List<Dieta> BuscarDieta(int idUs) //Versión que recibe el id del usuario y devuelve la lista de sus dietas.
        {
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta = String.Format("SELECT idDieta FROM dieta WHERE idUsuario LIKE {0}", idUs);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Dieta d1 = new Dieta(reader.GetInt32(0));
                    lista.Add(d1);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }


        public static List<Dieta> BuscarDieta(string corr) //Versión que recibe el correo del usuario y devuelve la lista de sus dietas.
        {
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.

            string consulta = String.Format("SELECT idDieta FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Dieta d1 = new Dieta(reader.GetInt32(0));
                    lista.Add(d1);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            reader.Close();
            return lista;
        }

        public static string FechaInicio(string corr) //Función que retorna la fecha de inicio de la dieta desde la bd
        {
            string retorno="";
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            string consulta = String.Format("SELECT fecha_inicio FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    retorno = reader.GetString(0);
                }
                reader.Close();
            }
            reader.Close();
            return retorno;
        }

        public static string FechaFinal(string corr) //Función que retorna la fecha de finalización de la dieta desde la bd
        {
            string retorno = "";
            int idUs = 0;
            List<Dieta> lista = new List<Dieta>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.
            string consulta2 = String.Format("SELECT idUsuario FROM usuario WHERE correo LIKE '{0}'", corr);
            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    idUs = reader2.GetInt32(0);
                }
                reader2.Close();
            }
            reader2.Close();
            string consulta = String.Format("SELECT fecha_finalizacion FROM dieta WHERE idUsuario LIKE {0}", idUs);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    retorno = reader.GetString(0);
                }
                reader.Close();
            }
            reader.Close();
            return retorno;
        }

        static public int SubirOpciones(string correo, string b1, string b2, string b3, string b4, string b5, string b6, string b7,
                                        string l1, string l2, string l3, string l4, string l5, string l6, string l7,
                                        string m1, string m2, string m3, string m4, string m5, string m6, string m7,
                                        string s1, string s2, string s3, string s4, string s5, string s6, string s7,
                                        string d1, string d2, string d3, string d4, string d5, string d6, string d7) //Agrega las opciones del usuario a la bd
        {
            int retorno;
            int idD = 0;
            string consulta1 = String.Format("SELECT idDieta FROM usuario WHERE correo LIKE '{0}'", correo);
            MySqlCommand comando1 = new MySqlCommand(consulta1, ConexionBD.Conexion);
            MySqlDataReader reader1 = comando1.ExecuteReader();
            if (reader1.HasRows)
            {
                while (reader1.Read())
                {
                    idD = reader1.GetInt32(0);
                }
                reader1.Close();
            }
            reader1.Close();
            string consulta2 = String.Format("INSERT INTO opciones (idDieta, desayuno1, desayuno2, desayuno3, desayuno4, desayuno5, desayuno6, desayuno7," +
                                                "almuerzo1, almuerzo2, almuerzo3, almuerzo4, almuerzo5, almuerzo6, almuerzo7," +
                                                "comidaa1, comidaa2, comidaa3, comidaa4, comidaa5, comidaa6, comidaa7," +
                                                "merienda1, merienda2, merienda3, merienda4, merienda5, merienda6, merienda7," +
                                                "cena1, cena2, cena3, cena4, cena5, cena6, cena7)" +
                                                "VALUES ({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}'," +
                                                "'{12}','{13}','{14}','{15}','{16}','{17}','{18}','{19}','{20}','{21}','{22}','{23}'," +
                                                "'{24}','{25}','{26}','{27}','{28}','{29}','{30}','{31}','{32}','{33}','{34}','{35}')", idD,b1, b2, b3, b4, b5, b6, b7, l1, l2, l3, l4, l5, l6, l7,
                                                m1, m2, m3, m4, m5, m6, m7, s1, s2, s3, s4, s5, s6, s7, d1, d2, d3, d4, d5, d6, d7);

            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);

            retorno = comando2.ExecuteNonQuery();

            return retorno;
        }

        static public string BajarOpciones(string comida, string correo)
        {
            string retorno = "";
            int idD = 0;
            string consulta1 = String.Format("SELECT idDieta FROM usuario WHERE correo LIKE '{0}'", correo);
            MySqlCommand comando1 = new MySqlCommand(consulta1, ConexionBD.Conexion);
            MySqlDataReader reader1 = comando1.ExecuteReader();
            if (reader1.HasRows)
            {
                while (reader1.Read())
                {
                    idD = reader1.GetInt32(0);
                }
                reader1.Close();
            }
            reader1.Close();

            string consulta2 = String.Format("SELECT {0} FROM opciones WHERE idDieta LIKE {1}", comida, idD);
            MySqlCommand comando2 = new MySqlCommand(consulta2, ConexionBD.Conexion);
            MySqlDataReader reader2 = comando2.ExecuteReader();
            if (reader2.HasRows)
            {
                while (reader2.Read())
                {
                    retorno = reader2.GetString(0);
                }
                reader2.Close();

            }
            reader2.Close();
            return retorno;
        }

    }   
}
