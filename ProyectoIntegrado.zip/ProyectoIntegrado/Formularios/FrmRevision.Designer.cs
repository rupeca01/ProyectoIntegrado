﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmRevision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRevision));
            this.lblRevision = new System.Windows.Forms.Label();
            this.pcbLogoRevision = new System.Windows.Forms.PictureBox();
            this.lblAlturaRevision = new System.Windows.Forms.Label();
            this.lblCmRevision = new System.Windows.Forms.Label();
            this.lblPesoRevision = new System.Windows.Forms.Label();
            this.lblKgRevision = new System.Windows.Forms.Label();
            this.tbrAlturaRevision = new System.Windows.Forms.TrackBar();
            this.nudKgRevision = new System.Windows.Forms.NumericUpDown();
            this.lblObjRevision = new System.Windows.Forms.Label();
            this.cmbObjRevision = new System.Windows.Forms.ComboBox();
            this.btnCalcRevision = new System.Windows.Forms.Button();
            this.btnVolverRe = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRevision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbrAlturaRevision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKgRevision)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRevision
            // 
            this.lblRevision.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblRevision.AutoSize = true;
            this.lblRevision.Font = new System.Drawing.Font("High Tower Text", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevision.ForeColor = System.Drawing.Color.White;
            this.lblRevision.Location = new System.Drawing.Point(429, 44);
            this.lblRevision.Name = "lblRevision";
            this.lblRevision.Size = new System.Drawing.Size(213, 71);
            this.lblRevision.TabIndex = 2;
            this.lblRevision.Text = "Review";
            // 
            // pcbLogoRevision
            // 
            this.pcbLogoRevision.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoRevision.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoRevision.Name = "pcbLogoRevision";
            this.pcbLogoRevision.Size = new System.Drawing.Size(287, 172);
            this.pcbLogoRevision.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoRevision.TabIndex = 3;
            this.pcbLogoRevision.TabStop = false;
            // 
            // lblAlturaRevision
            // 
            this.lblAlturaRevision.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAlturaRevision.AutoSize = true;
            this.lblAlturaRevision.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlturaRevision.ForeColor = System.Drawing.Color.White;
            this.lblAlturaRevision.Location = new System.Drawing.Point(18, 24);
            this.lblAlturaRevision.Name = "lblAlturaRevision";
            this.lblAlturaRevision.Size = new System.Drawing.Size(103, 32);
            this.lblAlturaRevision.TabIndex = 5;
            this.lblAlturaRevision.Text = "Height:";
            // 
            // lblCmRevision
            // 
            this.lblCmRevision.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCmRevision.AutoSize = true;
            this.lblCmRevision.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCmRevision.ForeColor = System.Drawing.Color.White;
            this.lblCmRevision.Location = new System.Drawing.Point(541, 24);
            this.lblCmRevision.Name = "lblCmRevision";
            this.lblCmRevision.Size = new System.Drawing.Size(50, 32);
            this.lblCmRevision.TabIndex = 7;
            this.lblCmRevision.Text = "cm";
            // 
            // lblPesoRevision
            // 
            this.lblPesoRevision.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPesoRevision.AutoSize = true;
            this.lblPesoRevision.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoRevision.ForeColor = System.Drawing.Color.White;
            this.lblPesoRevision.Location = new System.Drawing.Point(274, 272);
            this.lblPesoRevision.Name = "lblPesoRevision";
            this.lblPesoRevision.Size = new System.Drawing.Size(108, 32);
            this.lblPesoRevision.TabIndex = 8;
            this.lblPesoRevision.Text = "Weight:";
            // 
            // lblKgRevision
            // 
            this.lblKgRevision.AutoSize = true;
            this.lblKgRevision.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKgRevision.ForeColor = System.Drawing.Color.White;
            this.lblKgRevision.Location = new System.Drawing.Point(528, 276);
            this.lblKgRevision.Name = "lblKgRevision";
            this.lblKgRevision.Size = new System.Drawing.Size(41, 28);
            this.lblKgRevision.TabIndex = 17;
            this.lblKgRevision.Text = "Kg";
            // 
            // tbrAlturaRevision
            // 
            this.tbrAlturaRevision.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbrAlturaRevision.LargeChange = 1;
            this.tbrAlturaRevision.Location = new System.Drawing.Point(141, 25);
            this.tbrAlturaRevision.Maximum = 230;
            this.tbrAlturaRevision.Name = "tbrAlturaRevision";
            this.tbrAlturaRevision.Size = new System.Drawing.Size(364, 56);
            this.tbrAlturaRevision.TabIndex = 18;
            this.tbrAlturaRevision.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tbrAlturaRevision.Scroll += new System.EventHandler(this.tbrAlturaRevision_Scroll);
            // 
            // nudKgRevision
            // 
            this.nudKgRevision.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nudKgRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudKgRevision.Location = new System.Drawing.Point(402, 276);
            this.nudKgRevision.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudKgRevision.Name = "nudKgRevision";
            this.nudKgRevision.Size = new System.Drawing.Size(120, 27);
            this.nudKgRevision.TabIndex = 19;
            // 
            // lblObjRevision
            // 
            this.lblObjRevision.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblObjRevision.AutoSize = true;
            this.lblObjRevision.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObjRevision.ForeColor = System.Drawing.Color.White;
            this.lblObjRevision.Location = new System.Drawing.Point(239, 331);
            this.lblObjRevision.Name = "lblObjRevision";
            this.lblObjRevision.Size = new System.Drawing.Size(143, 32);
            this.lblObjRevision.TabIndex = 20;
            this.lblObjRevision.Text = "Objectives:";
            // 
            // cmbObjRevision
            // 
            this.cmbObjRevision.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbObjRevision.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbObjRevision.FormattingEnabled = true;
            this.cmbObjRevision.Items.AddRange(new object[] {
            "Lose weight",
            "Gain muscle",
            "Keep healthy"});
            this.cmbObjRevision.Location = new System.Drawing.Point(405, 332);
            this.cmbObjRevision.Name = "cmbObjRevision";
            this.cmbObjRevision.Size = new System.Drawing.Size(220, 35);
            this.cmbObjRevision.TabIndex = 21;
            // 
            // btnCalcRevision
            // 
            this.btnCalcRevision.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnCalcRevision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCalcRevision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCalcRevision.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcRevision.ForeColor = System.Drawing.Color.White;
            this.btnCalcRevision.Location = new System.Drawing.Point(404, 428);
            this.btnCalcRevision.Name = "btnCalcRevision";
            this.btnCalcRevision.Size = new System.Drawing.Size(238, 49);
            this.btnCalcRevision.TabIndex = 24;
            this.btnCalcRevision.Text = "Generate";
            this.btnCalcRevision.UseVisualStyleBackColor = false;
            this.btnCalcRevision.Click += new System.EventHandler(this.btnCalcRevision_Click);
            // 
            // btnVolverRe
            // 
            this.btnVolverRe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVolverRe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnVolverRe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolverRe.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverRe.ForeColor = System.Drawing.Color.White;
            this.btnVolverRe.Location = new System.Drawing.Point(829, 428);
            this.btnVolverRe.Name = "btnVolverRe";
            this.btnVolverRe.Size = new System.Drawing.Size(118, 49);
            this.btnVolverRe.TabIndex = 25;
            this.btnVolverRe.Text = "Return";
            this.btnVolverRe.UseVisualStyleBackColor = false;
            this.btnVolverRe.Click += new System.EventHandler(this.btnVolverRe_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.lblCmRevision);
            this.panel1.Controls.Add(this.tbrAlturaRevision);
            this.panel1.Controls.Add(this.lblAlturaRevision);
            this.panel1.Location = new System.Drawing.Point(267, 173);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(619, 75);
            this.panel1.TabIndex = 26;
            // 
            // FrmRevision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(972, 581);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnVolverRe);
            this.Controls.Add(this.btnCalcRevision);
            this.Controls.Add(this.cmbObjRevision);
            this.Controls.Add(this.lblObjRevision);
            this.Controls.Add(this.nudKgRevision);
            this.Controls.Add(this.lblKgRevision);
            this.Controls.Add(this.lblPesoRevision);
            this.Controls.Add(this.pcbLogoRevision);
            this.Controls.Add(this.lblRevision);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRevision";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmRevision_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRevision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbrAlturaRevision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKgRevision)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.PictureBox pcbLogoRevision;
        private System.Windows.Forms.Label lblAlturaRevision;
        private System.Windows.Forms.Label lblCmRevision;
        private System.Windows.Forms.Label lblPesoRevision;
        private System.Windows.Forms.Label lblKgRevision;
        private System.Windows.Forms.TrackBar tbrAlturaRevision;
        private System.Windows.Forms.NumericUpDown nudKgRevision;
        private System.Windows.Forms.Label lblObjRevision;
        private System.Windows.Forms.ComboBox cmbObjRevision;
        private System.Windows.Forms.Button btnCalcRevision;
        private System.Windows.Forms.Button btnVolverRe;
        private System.Windows.Forms.Panel panel1;
    }
}