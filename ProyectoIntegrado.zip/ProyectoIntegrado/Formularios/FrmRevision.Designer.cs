﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmRevision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRevision));
            this.lblRevision = new System.Windows.Forms.Label();
            this.pcbLogoRevision = new System.Windows.Forms.PictureBox();
            this.lblExplicacionRevision = new System.Windows.Forms.Label();
            this.lblAlturaRevision = new System.Windows.Forms.Label();
            this.lblCmRevision = new System.Windows.Forms.Label();
            this.lblPesoRevision = new System.Windows.Forms.Label();
            this.lblKgRevision = new System.Windows.Forms.Label();
            this.tbrAlturaRevision = new System.Windows.Forms.TrackBar();
            this.nudKgRevision = new System.Windows.Forms.NumericUpDown();
            this.lblObjRevision = new System.Windows.Forms.Label();
            this.cmbObjRevision = new System.Windows.Forms.ComboBox();
            this.btnCalcRevision = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRevision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbrAlturaRevision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKgRevision)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRevision
            // 
            this.lblRevision.AutoSize = true;
            this.lblRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevision.Location = new System.Drawing.Point(436, 9);
            this.lblRevision.Name = "lblRevision";
            this.lblRevision.Size = new System.Drawing.Size(144, 44);
            this.lblRevision.TabIndex = 2;
            this.lblRevision.Text = "Review";
            // 
            // pcbLogoRevision
            // 
            this.pcbLogoRevision.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoRevision.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoRevision.Name = "pcbLogoRevision";
            this.pcbLogoRevision.Size = new System.Drawing.Size(238, 148);
            this.pcbLogoRevision.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoRevision.TabIndex = 3;
            this.pcbLogoRevision.TabStop = false;
            // 
            // lblExplicacionRevision
            // 
            this.lblExplicacionRevision.AutoSize = true;
            this.lblExplicacionRevision.Location = new System.Drawing.Point(304, 75);
            this.lblExplicacionRevision.Name = "lblExplicacionRevision";
            this.lblExplicacionRevision.Size = new System.Drawing.Size(46, 17);
            this.lblExplicacionRevision.TabIndex = 4;
            this.lblExplicacionRevision.Text = "label1";
            // 
            // lblAlturaRevision
            // 
            this.lblAlturaRevision.AutoSize = true;
            this.lblAlturaRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlturaRevision.Location = new System.Drawing.Point(304, 207);
            this.lblAlturaRevision.Name = "lblAlturaRevision";
            this.lblAlturaRevision.Size = new System.Drawing.Size(70, 24);
            this.lblAlturaRevision.TabIndex = 5;
            this.lblAlturaRevision.Text = "Height:";
            // 
            // lblCmRevision
            // 
            this.lblCmRevision.AutoSize = true;
            this.lblCmRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCmRevision.Location = new System.Drawing.Point(754, 207);
            this.lblCmRevision.Name = "lblCmRevision";
            this.lblCmRevision.Size = new System.Drawing.Size(36, 24);
            this.lblCmRevision.TabIndex = 7;
            this.lblCmRevision.Text = "cm";
            // 
            // lblPesoRevision
            // 
            this.lblPesoRevision.AutoSize = true;
            this.lblPesoRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoRevision.Location = new System.Drawing.Point(288, 276);
            this.lblPesoRevision.Name = "lblPesoRevision";
            this.lblPesoRevision.Size = new System.Drawing.Size(74, 24);
            this.lblPesoRevision.TabIndex = 8;
            this.lblPesoRevision.Text = "Weight:";
            // 
            // lblKgRevision
            // 
            this.lblKgRevision.AutoSize = true;
            this.lblKgRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKgRevision.Location = new System.Drawing.Point(502, 276);
            this.lblKgRevision.Name = "lblKgRevision";
            this.lblKgRevision.Size = new System.Drawing.Size(33, 24);
            this.lblKgRevision.TabIndex = 17;
            this.lblKgRevision.Text = "Kg";
            // 
            // tbrAlturaRevision
            // 
            this.tbrAlturaRevision.LargeChange = 1;
            this.tbrAlturaRevision.Location = new System.Drawing.Point(373, 195);
            this.tbrAlturaRevision.Maximum = 230;
            this.tbrAlturaRevision.Name = "tbrAlturaRevision";
            this.tbrAlturaRevision.Size = new System.Drawing.Size(345, 56);
            this.tbrAlturaRevision.TabIndex = 18;
            this.tbrAlturaRevision.Scroll += new System.EventHandler(this.tbrAlturaRevision_Scroll);
            // 
            // nudKgRevision
            // 
            this.nudKgRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudKgRevision.Location = new System.Drawing.Point(368, 276);
            this.nudKgRevision.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudKgRevision.Name = "nudKgRevision";
            this.nudKgRevision.Size = new System.Drawing.Size(120, 27);
            this.nudKgRevision.TabIndex = 19;
            // 
            // lblObjRevision
            // 
            this.lblObjRevision.AutoSize = true;
            this.lblObjRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObjRevision.Location = new System.Drawing.Point(259, 337);
            this.lblObjRevision.Name = "lblObjRevision";
            this.lblObjRevision.Size = new System.Drawing.Size(103, 24);
            this.lblObjRevision.TabIndex = 20;
            this.lblObjRevision.Text = "Objectives:";
            // 
            // cmbObjRevision
            // 
            this.cmbObjRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbObjRevision.FormattingEnabled = true;
            this.cmbObjRevision.Items.AddRange(new object[] {
            "Lose weight",
            "Gain muscle",
            "Keep healthy"});
            this.cmbObjRevision.Location = new System.Drawing.Point(368, 336);
            this.cmbObjRevision.Name = "cmbObjRevision";
            this.cmbObjRevision.Size = new System.Drawing.Size(220, 28);
            this.cmbObjRevision.TabIndex = 21;
            // 
            // btnCalcRevision
            // 
            this.btnCalcRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcRevision.Location = new System.Drawing.Point(342, 424);
            this.btnCalcRevision.Name = "btnCalcRevision";
            this.btnCalcRevision.Size = new System.Drawing.Size(238, 49);
            this.btnCalcRevision.TabIndex = 24;
            this.btnCalcRevision.Text = "Generate";
            this.btnCalcRevision.UseVisualStyleBackColor = true;
            this.btnCalcRevision.Click += new System.EventHandler(this.btnCalcRevision_Click);
            // 
            // FrmRevision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 581);
            this.Controls.Add(this.btnCalcRevision);
            this.Controls.Add(this.cmbObjRevision);
            this.Controls.Add(this.lblObjRevision);
            this.Controls.Add(this.nudKgRevision);
            this.Controls.Add(this.tbrAlturaRevision);
            this.Controls.Add(this.lblKgRevision);
            this.Controls.Add(this.lblPesoRevision);
            this.Controls.Add(this.lblCmRevision);
            this.Controls.Add(this.lblAlturaRevision);
            this.Controls.Add(this.lblExplicacionRevision);
            this.Controls.Add(this.pcbLogoRevision);
            this.Controls.Add(this.lblRevision);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRevision";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmRevision_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRevision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbrAlturaRevision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKgRevision)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.PictureBox pcbLogoRevision;
        private System.Windows.Forms.Label lblExplicacionRevision;
        private System.Windows.Forms.Label lblAlturaRevision;
        private System.Windows.Forms.Label lblCmRevision;
        private System.Windows.Forms.Label lblPesoRevision;
        private System.Windows.Forms.Label lblKgRevision;
        private System.Windows.Forms.TrackBar tbrAlturaRevision;
        private System.Windows.Forms.NumericUpDown nudKgRevision;
        private System.Windows.Forms.Label lblObjRevision;
        private System.Windows.Forms.ComboBox cmbObjRevision;
        private System.Windows.Forms.Button btnCalcRevision;
    }
}