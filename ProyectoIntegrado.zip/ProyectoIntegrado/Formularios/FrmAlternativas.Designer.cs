﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmAlternativas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAlternativas));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContactoAlt = new System.Windows.Forms.Button();
            this.btnRevisionAlt = new System.Windows.Forms.Button();
            this.btnForoAlt = new System.Windows.Forms.Button();
            this.btnDietaAlt = new System.Windows.Forms.Button();
            this.btnAlternAlt = new System.Windows.Forms.Button();
            this.lblAlternativas = new System.Windows.Forms.Label();
            this.btnPerfilAlt = new System.Windows.Forms.Button();
            this.btnCSAlt = new System.Windows.Forms.Button();
            this.grbTiposAlt = new System.Windows.Forms.GroupBox();
            this.rdbCarboAlt = new System.Windows.Forms.RadioButton();
            this.rdbFatsAlt = new System.Windows.Forms.RadioButton();
            this.rdbProteinAlt = new System.Windows.Forms.RadioButton();
            this.dtgvAlt = new System.Windows.Forms.DataGridView();
            this.grbCalcAlt = new System.Windows.Forms.GroupBox();
            this.pcbHelpAlt = new System.Windows.Forms.PictureBox();
            this.btnCalcAlt = new System.Windows.Forms.Button();
            this.txtQuantAlt = new System.Windows.Forms.TextBox();
            this.txtCalAlt = new System.Windows.Forms.TextBox();
            this.lblQuantAlt = new System.Windows.Forms.Label();
            this.lblCalAlt = new System.Windows.Forms.Label();
            this.pcbLogoAlternatives = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.grbTiposAlt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAlt)).BeginInit();
            this.grbCalcAlt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbHelpAlt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoAlternatives)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.btnContactoAlt);
            this.panel1.Controls.Add(this.btnRevisionAlt);
            this.panel1.Controls.Add(this.btnForoAlt);
            this.panel1.Controls.Add(this.btnDietaAlt);
            this.panel1.Controls.Add(this.btnAlternAlt);
            this.panel1.Location = new System.Drawing.Point(12, 238);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 16;
            // 
            // btnContactoAlt
            // 
            this.btnContactoAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnContactoAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactoAlt.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactoAlt.ForeColor = System.Drawing.Color.White;
            this.btnContactoAlt.Location = new System.Drawing.Point(0, 260);
            this.btnContactoAlt.Name = "btnContactoAlt";
            this.btnContactoAlt.Size = new System.Drawing.Size(160, 59);
            this.btnContactoAlt.TabIndex = 4;
            this.btnContactoAlt.Text = "Contact";
            this.btnContactoAlt.UseVisualStyleBackColor = false;
            this.btnContactoAlt.Click += new System.EventHandler(this.btnContactoAlt_Click);
            // 
            // btnRevisionAlt
            // 
            this.btnRevisionAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRevisionAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRevisionAlt.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionAlt.ForeColor = System.Drawing.Color.White;
            this.btnRevisionAlt.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionAlt.Name = "btnRevisionAlt";
            this.btnRevisionAlt.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionAlt.TabIndex = 3;
            this.btnRevisionAlt.Text = "Review";
            this.btnRevisionAlt.UseVisualStyleBackColor = false;
            this.btnRevisionAlt.Click += new System.EventHandler(this.btnRevisionAlt_Click);
            // 
            // btnForoAlt
            // 
            this.btnForoAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnForoAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnForoAlt.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoAlt.ForeColor = System.Drawing.Color.White;
            this.btnForoAlt.Location = new System.Drawing.Point(0, 130);
            this.btnForoAlt.Name = "btnForoAlt";
            this.btnForoAlt.Size = new System.Drawing.Size(160, 59);
            this.btnForoAlt.TabIndex = 2;
            this.btnForoAlt.Text = "Forum";
            this.btnForoAlt.UseVisualStyleBackColor = false;
            this.btnForoAlt.Click += new System.EventHandler(this.btnForoAlt_Click);
            // 
            // btnDietaAlt
            // 
            this.btnDietaAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDietaAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDietaAlt.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaAlt.ForeColor = System.Drawing.Color.White;
            this.btnDietaAlt.Location = new System.Drawing.Point(0, 3);
            this.btnDietaAlt.Name = "btnDietaAlt";
            this.btnDietaAlt.Size = new System.Drawing.Size(163, 59);
            this.btnDietaAlt.TabIndex = 1;
            this.btnDietaAlt.Text = "Diet";
            this.btnDietaAlt.UseVisualStyleBackColor = false;
            this.btnDietaAlt.Click += new System.EventHandler(this.btnDietaAlt_Click);
            // 
            // btnAlternAlt
            // 
            this.btnAlternAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAlternAlt.Enabled = false;
            this.btnAlternAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAlternAlt.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternAlt.ForeColor = System.Drawing.Color.White;
            this.btnAlternAlt.Location = new System.Drawing.Point(0, 65);
            this.btnAlternAlt.Name = "btnAlternAlt";
            this.btnAlternAlt.Size = new System.Drawing.Size(160, 59);
            this.btnAlternAlt.TabIndex = 0;
            this.btnAlternAlt.Text = "Alternatives";
            this.btnAlternAlt.UseVisualStyleBackColor = false;
            // 
            // lblAlternativas
            // 
            this.lblAlternativas.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblAlternativas.AutoSize = true;
            this.lblAlternativas.Font = new System.Drawing.Font("High Tower Text", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlternativas.Location = new System.Drawing.Point(348, 36);
            this.lblAlternativas.Name = "lblAlternativas";
            this.lblAlternativas.Size = new System.Drawing.Size(333, 71);
            this.lblAlternativas.TabIndex = 20;
            this.lblAlternativas.Text = "Alternatives";
            // 
            // btnPerfilAlt
            // 
            this.btnPerfilAlt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPerfilAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnPerfilAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPerfilAlt.Font = new System.Drawing.Font("High Tower Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerfilAlt.Location = new System.Drawing.Point(867, 9);
            this.btnPerfilAlt.Name = "btnPerfilAlt";
            this.btnPerfilAlt.Size = new System.Drawing.Size(78, 26);
            this.btnPerfilAlt.TabIndex = 33;
            this.btnPerfilAlt.Text = "Profile";
            this.btnPerfilAlt.UseVisualStyleBackColor = false;
            this.btnPerfilAlt.Click += new System.EventHandler(this.btnPerfilAlt_Click);
            // 
            // btnCSAlt
            // 
            this.btnCSAlt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCSAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCSAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCSAlt.Font = new System.Drawing.Font("High Tower Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCSAlt.Location = new System.Drawing.Point(783, 9);
            this.btnCSAlt.Name = "btnCSAlt";
            this.btnCSAlt.Size = new System.Drawing.Size(78, 26);
            this.btnCSAlt.TabIndex = 32;
            this.btnCSAlt.Text = "Log Out";
            this.btnCSAlt.UseVisualStyleBackColor = false;
            this.btnCSAlt.Click += new System.EventHandler(this.btnCSAlt_Click);
            // 
            // grbTiposAlt
            // 
            this.grbTiposAlt.BackColor = System.Drawing.Color.Black;
            this.grbTiposAlt.Controls.Add(this.rdbCarboAlt);
            this.grbTiposAlt.Controls.Add(this.rdbFatsAlt);
            this.grbTiposAlt.Controls.Add(this.rdbProteinAlt);
            this.grbTiposAlt.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbTiposAlt.ForeColor = System.Drawing.Color.White;
            this.grbTiposAlt.Location = new System.Drawing.Point(202, 161);
            this.grbTiposAlt.Name = "grbTiposAlt";
            this.grbTiposAlt.Size = new System.Drawing.Size(164, 184);
            this.grbTiposAlt.TabIndex = 34;
            this.grbTiposAlt.TabStop = false;
            this.grbTiposAlt.Text = "Select Food Type";
            // 
            // rdbCarboAlt
            // 
            this.rdbCarboAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbCarboAlt.AutoSize = true;
            this.rdbCarboAlt.Location = new System.Drawing.Point(6, 133);
            this.rdbCarboAlt.Name = "rdbCarboAlt";
            this.rdbCarboAlt.Size = new System.Drawing.Size(132, 24);
            this.rdbCarboAlt.TabIndex = 2;
            this.rdbCarboAlt.TabStop = true;
            this.rdbCarboAlt.Text = "Carbohydrates";
            this.rdbCarboAlt.UseVisualStyleBackColor = true;
            this.rdbCarboAlt.CheckedChanged += new System.EventHandler(this.rdbCarboAlt_CheckedChanged);
            // 
            // rdbFatsAlt
            // 
            this.rdbFatsAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbFatsAlt.AutoSize = true;
            this.rdbFatsAlt.Location = new System.Drawing.Point(6, 85);
            this.rdbFatsAlt.Name = "rdbFatsAlt";
            this.rdbFatsAlt.Size = new System.Drawing.Size(58, 24);
            this.rdbFatsAlt.TabIndex = 1;
            this.rdbFatsAlt.TabStop = true;
            this.rdbFatsAlt.Text = "Fats";
            this.rdbFatsAlt.UseVisualStyleBackColor = true;
            this.rdbFatsAlt.CheckedChanged += new System.EventHandler(this.rdbFatsAlt_CheckedChanged);
            // 
            // rdbProteinAlt
            // 
            this.rdbProteinAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbProteinAlt.AutoSize = true;
            this.rdbProteinAlt.Location = new System.Drawing.Point(6, 40);
            this.rdbProteinAlt.Name = "rdbProteinAlt";
            this.rdbProteinAlt.Size = new System.Drawing.Size(82, 24);
            this.rdbProteinAlt.TabIndex = 0;
            this.rdbProteinAlt.TabStop = true;
            this.rdbProteinAlt.Text = "Protein";
            this.rdbProteinAlt.UseVisualStyleBackColor = true;
            this.rdbProteinAlt.CheckedChanged += new System.EventHandler(this.rdbProteinAlt_CheckedChanged);
            // 
            // dtgvAlt
            // 
            this.dtgvAlt.AllowUserToAddRows = false;
            this.dtgvAlt.AllowUserToDeleteRows = false;
            this.dtgvAlt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtgvAlt.BackgroundColor = System.Drawing.Color.Black;
            this.dtgvAlt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvAlt.Location = new System.Drawing.Point(472, 136);
            this.dtgvAlt.Name = "dtgvAlt";
            this.dtgvAlt.RowHeadersWidth = 51;
            this.dtgvAlt.RowTemplate.Height = 24;
            this.dtgvAlt.Size = new System.Drawing.Size(473, 437);
            this.dtgvAlt.TabIndex = 35;
            this.dtgvAlt.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvAlt_CellContentClick);
            // 
            // grbCalcAlt
            // 
            this.grbCalcAlt.Controls.Add(this.pcbHelpAlt);
            this.grbCalcAlt.Controls.Add(this.btnCalcAlt);
            this.grbCalcAlt.Controls.Add(this.txtQuantAlt);
            this.grbCalcAlt.Controls.Add(this.txtCalAlt);
            this.grbCalcAlt.Controls.Add(this.lblQuantAlt);
            this.grbCalcAlt.Controls.Add(this.lblCalAlt);
            this.grbCalcAlt.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalcAlt.ForeColor = System.Drawing.Color.White;
            this.grbCalcAlt.Location = new System.Drawing.Point(202, 351);
            this.grbCalcAlt.Name = "grbCalcAlt";
            this.grbCalcAlt.Size = new System.Drawing.Size(244, 222);
            this.grbCalcAlt.TabIndex = 36;
            this.grbCalcAlt.TabStop = false;
            this.grbCalcAlt.Text = "Calculator";
            // 
            // pcbHelpAlt
            // 
            this.pcbHelpAlt.Image = global::ProyectoIntegrado.Properties.Resources.help;
            this.pcbHelpAlt.Location = new System.Drawing.Point(166, 189);
            this.pcbHelpAlt.Name = "pcbHelpAlt";
            this.pcbHelpAlt.Size = new System.Drawing.Size(25, 22);
            this.pcbHelpAlt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbHelpAlt.TabIndex = 5;
            this.pcbHelpAlt.TabStop = false;
            this.pcbHelpAlt.Click += new System.EventHandler(this.pcbHelpAlt_Click);
            // 
            // btnCalcAlt
            // 
            this.btnCalcAlt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCalcAlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCalcAlt.Location = new System.Drawing.Point(67, 182);
            this.btnCalcAlt.Name = "btnCalcAlt";
            this.btnCalcAlt.Size = new System.Drawing.Size(93, 29);
            this.btnCalcAlt.TabIndex = 4;
            this.btnCalcAlt.Text = "Calculate";
            this.btnCalcAlt.UseVisualStyleBackColor = false;
            this.btnCalcAlt.Click += new System.EventHandler(this.btnCalcAlt_Click);
            // 
            // txtQuantAlt
            // 
            this.txtQuantAlt.Enabled = false;
            this.txtQuantAlt.Location = new System.Drawing.Point(103, 96);
            this.txtQuantAlt.Name = "txtQuantAlt";
            this.txtQuantAlt.Size = new System.Drawing.Size(115, 27);
            this.txtQuantAlt.TabIndex = 3;
            // 
            // txtCalAlt
            // 
            this.txtCalAlt.Location = new System.Drawing.Point(75, 44);
            this.txtCalAlt.Name = "txtCalAlt";
            this.txtCalAlt.Size = new System.Drawing.Size(143, 27);
            this.txtCalAlt.TabIndex = 2;
            // 
            // lblQuantAlt
            // 
            this.lblQuantAlt.AutoSize = true;
            this.lblQuantAlt.Location = new System.Drawing.Point(6, 99);
            this.lblQuantAlt.Name = "lblQuantAlt";
            this.lblQuantAlt.Size = new System.Drawing.Size(101, 20);
            this.lblQuantAlt.TabIndex = 1;
            this.lblQuantAlt.Text = "Quantity (g):";
            // 
            // lblCalAlt
            // 
            this.lblCalAlt.AutoSize = true;
            this.lblCalAlt.Location = new System.Drawing.Point(6, 44);
            this.lblCalAlt.Name = "lblCalAlt";
            this.lblCalAlt.Size = new System.Drawing.Size(71, 20);
            this.lblCalAlt.TabIndex = 0;
            this.lblCalAlt.Text = "Calories:";
            // 
            // pcbLogoAlternatives
            // 
            this.pcbLogoAlternatives.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoAlternatives.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoAlternatives.Name = "pcbLogoAlternatives";
            this.pcbLogoAlternatives.Size = new System.Drawing.Size(257, 148);
            this.pcbLogoAlternatives.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoAlternatives.TabIndex = 17;
            this.pcbLogoAlternatives.TabStop = false;
            // 
            // FrmAlternativas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(957, 588);
            this.Controls.Add(this.grbCalcAlt);
            this.Controls.Add(this.dtgvAlt);
            this.Controls.Add(this.grbTiposAlt);
            this.Controls.Add(this.btnPerfilAlt);
            this.Controls.Add(this.btnCSAlt);
            this.Controls.Add(this.lblAlternativas);
            this.Controls.Add(this.pcbLogoAlternatives);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAlternativas";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmAlternativas_Load);
            this.panel1.ResumeLayout(false);
            this.grbTiposAlt.ResumeLayout(false);
            this.grbTiposAlt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAlt)).EndInit();
            this.grbCalcAlt.ResumeLayout(false);
            this.grbCalcAlt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbHelpAlt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoAlternatives)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContactoAlt;
        private System.Windows.Forms.Button btnRevisionAlt;
        private System.Windows.Forms.Button btnForoAlt;
        private System.Windows.Forms.Button btnDietaAlt;
        private System.Windows.Forms.Button btnAlternAlt;
        private System.Windows.Forms.PictureBox pcbLogoAlternatives;
        private System.Windows.Forms.Label lblAlternativas;
        private System.Windows.Forms.Button btnPerfilAlt;
        private System.Windows.Forms.Button btnCSAlt;
        private System.Windows.Forms.GroupBox grbTiposAlt;
        private System.Windows.Forms.RadioButton rdbCarboAlt;
        private System.Windows.Forms.RadioButton rdbFatsAlt;
        private System.Windows.Forms.RadioButton rdbProteinAlt;
        private System.Windows.Forms.DataGridView dtgvAlt;
        private System.Windows.Forms.GroupBox grbCalcAlt;
        private System.Windows.Forms.Button btnCalcAlt;
        private System.Windows.Forms.TextBox txtQuantAlt;
        private System.Windows.Forms.TextBox txtCalAlt;
        private System.Windows.Forms.Label lblQuantAlt;
        private System.Windows.Forms.Label lblCalAlt;
        private System.Windows.Forms.PictureBox pcbHelpAlt;
    }
}