﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmAlternativas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAlternativas));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContactoAlt = new System.Windows.Forms.Button();
            this.btnRevisionAlt = new System.Windows.Forms.Button();
            this.btnForoAlt = new System.Windows.Forms.Button();
            this.btnDietaAlt = new System.Windows.Forms.Button();
            this.btnAlternAlt = new System.Windows.Forms.Button();
            this.pcbLogoAlternatives = new System.Windows.Forms.PictureBox();
            this.lblAlternativas = new System.Windows.Forms.Label();
            this.btnPerfilAlt = new System.Windows.Forms.Button();
            this.btnCSAlt = new System.Windows.Forms.Button();
            this.grbTiposAlt = new System.Windows.Forms.GroupBox();
            this.rdbProteinAlt = new System.Windows.Forms.RadioButton();
            this.rdbFatsAlt = new System.Windows.Forms.RadioButton();
            this.rdbCarboAlt = new System.Windows.Forms.RadioButton();
            this.dtgvAlt = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoAlternatives)).BeginInit();
            this.grbTiposAlt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAlt)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnContactoAlt);
            this.panel1.Controls.Add(this.btnRevisionAlt);
            this.panel1.Controls.Add(this.btnForoAlt);
            this.panel1.Controls.Add(this.btnDietaAlt);
            this.panel1.Controls.Add(this.btnAlternAlt);
            this.panel1.Location = new System.Drawing.Point(12, 221);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 16;
            // 
            // btnContactoAlt
            // 
            this.btnContactoAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactoAlt.Location = new System.Drawing.Point(0, 260);
            this.btnContactoAlt.Name = "btnContactoAlt";
            this.btnContactoAlt.Size = new System.Drawing.Size(160, 59);
            this.btnContactoAlt.TabIndex = 4;
            this.btnContactoAlt.Text = "Contact";
            this.btnContactoAlt.UseVisualStyleBackColor = true;
            this.btnContactoAlt.Click += new System.EventHandler(this.btnContactoAlt_Click);
            // 
            // btnRevisionAlt
            // 
            this.btnRevisionAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionAlt.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionAlt.Name = "btnRevisionAlt";
            this.btnRevisionAlt.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionAlt.TabIndex = 3;
            this.btnRevisionAlt.Text = "Review";
            this.btnRevisionAlt.UseVisualStyleBackColor = true;
            this.btnRevisionAlt.Click += new System.EventHandler(this.btnRevisionAlt_Click);
            // 
            // btnForoAlt
            // 
            this.btnForoAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoAlt.Location = new System.Drawing.Point(0, 130);
            this.btnForoAlt.Name = "btnForoAlt";
            this.btnForoAlt.Size = new System.Drawing.Size(160, 59);
            this.btnForoAlt.TabIndex = 2;
            this.btnForoAlt.Text = "Forum";
            this.btnForoAlt.UseVisualStyleBackColor = true;
            this.btnForoAlt.Click += new System.EventHandler(this.btnForoAlt_Click);
            // 
            // btnDietaAlt
            // 
            this.btnDietaAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaAlt.Location = new System.Drawing.Point(0, 0);
            this.btnDietaAlt.Name = "btnDietaAlt";
            this.btnDietaAlt.Size = new System.Drawing.Size(160, 59);
            this.btnDietaAlt.TabIndex = 1;
            this.btnDietaAlt.Text = "Diet";
            this.btnDietaAlt.UseVisualStyleBackColor = true;
            this.btnDietaAlt.Click += new System.EventHandler(this.btnDietaAlt_Click);
            // 
            // btnAlternAlt
            // 
            this.btnAlternAlt.Enabled = false;
            this.btnAlternAlt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternAlt.Location = new System.Drawing.Point(0, 65);
            this.btnAlternAlt.Name = "btnAlternAlt";
            this.btnAlternAlt.Size = new System.Drawing.Size(160, 59);
            this.btnAlternAlt.TabIndex = 0;
            this.btnAlternAlt.Text = "Alternatives";
            this.btnAlternAlt.UseVisualStyleBackColor = true;
            // 
            // pcbLogoAlternatives
            // 
            this.pcbLogoAlternatives.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoAlternatives.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoAlternatives.Name = "pcbLogoAlternatives";
            this.pcbLogoAlternatives.Size = new System.Drawing.Size(238, 148);
            this.pcbLogoAlternatives.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoAlternatives.TabIndex = 17;
            this.pcbLogoAlternatives.TabStop = false;
            // 
            // lblAlternativas
            // 
            this.lblAlternativas.AutoSize = true;
            this.lblAlternativas.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlternativas.Location = new System.Drawing.Point(424, 9);
            this.lblAlternativas.Name = "lblAlternativas";
            this.lblAlternativas.Size = new System.Drawing.Size(220, 44);
            this.lblAlternativas.TabIndex = 20;
            this.lblAlternativas.Text = "Alternatives";
            // 
            // btnPerfilAlt
            // 
            this.btnPerfilAlt.Location = new System.Drawing.Point(855, 9);
            this.btnPerfilAlt.Name = "btnPerfilAlt";
            this.btnPerfilAlt.Size = new System.Drawing.Size(78, 26);
            this.btnPerfilAlt.TabIndex = 33;
            this.btnPerfilAlt.Text = "Profile";
            this.btnPerfilAlt.UseVisualStyleBackColor = true;
            this.btnPerfilAlt.Click += new System.EventHandler(this.btnPerfilAlt_Click);
            // 
            // btnCSAlt
            // 
            this.btnCSAlt.Location = new System.Drawing.Point(771, 9);
            this.btnCSAlt.Name = "btnCSAlt";
            this.btnCSAlt.Size = new System.Drawing.Size(78, 26);
            this.btnCSAlt.TabIndex = 32;
            this.btnCSAlt.Text = "Log Out";
            this.btnCSAlt.UseVisualStyleBackColor = true;
            this.btnCSAlt.Click += new System.EventHandler(this.btnCSAlt_Click);
            // 
            // grbTiposAlt
            // 
            this.grbTiposAlt.Controls.Add(this.rdbCarboAlt);
            this.grbTiposAlt.Controls.Add(this.rdbFatsAlt);
            this.grbTiposAlt.Controls.Add(this.rdbProteinAlt);
            this.grbTiposAlt.Location = new System.Drawing.Point(280, 110);
            this.grbTiposAlt.Name = "grbTiposAlt";
            this.grbTiposAlt.Size = new System.Drawing.Size(134, 184);
            this.grbTiposAlt.TabIndex = 34;
            this.grbTiposAlt.TabStop = false;
            this.grbTiposAlt.Text = "Select Food Type";
            // 
            // rdbProteinAlt
            // 
            this.rdbProteinAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbProteinAlt.AutoSize = true;
            this.rdbProteinAlt.Location = new System.Drawing.Point(6, 40);
            this.rdbProteinAlt.Name = "rdbProteinAlt";
            this.rdbProteinAlt.Size = new System.Drawing.Size(74, 21);
            this.rdbProteinAlt.TabIndex = 0;
            this.rdbProteinAlt.TabStop = true;
            this.rdbProteinAlt.Text = "Protein";
            this.rdbProteinAlt.UseVisualStyleBackColor = true;
            this.rdbProteinAlt.CheckedChanged += new System.EventHandler(this.rdbProteinAlt_CheckedChanged);
            // 
            // rdbFatsAlt
            // 
            this.rdbFatsAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbFatsAlt.AutoSize = true;
            this.rdbFatsAlt.Location = new System.Drawing.Point(6, 85);
            this.rdbFatsAlt.Name = "rdbFatsAlt";
            this.rdbFatsAlt.Size = new System.Drawing.Size(56, 21);
            this.rdbFatsAlt.TabIndex = 1;
            this.rdbFatsAlt.TabStop = true;
            this.rdbFatsAlt.Text = "Fats";
            this.rdbFatsAlt.UseVisualStyleBackColor = true;
            this.rdbFatsAlt.CheckedChanged += new System.EventHandler(this.rdbFatsAlt_CheckedChanged);
            // 
            // rdbCarboAlt
            // 
            this.rdbCarboAlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rdbCarboAlt.AutoSize = true;
            this.rdbCarboAlt.Location = new System.Drawing.Point(6, 133);
            this.rdbCarboAlt.Name = "rdbCarboAlt";
            this.rdbCarboAlt.Size = new System.Drawing.Size(122, 21);
            this.rdbCarboAlt.TabIndex = 2;
            this.rdbCarboAlt.TabStop = true;
            this.rdbCarboAlt.Text = "Carbohydrates";
            this.rdbCarboAlt.UseVisualStyleBackColor = true;
            this.rdbCarboAlt.CheckedChanged += new System.EventHandler(this.rdbCarboAlt_CheckedChanged);
            // 
            // dtgvAlt
            // 
            this.dtgvAlt.AllowUserToAddRows = false;
            this.dtgvAlt.AllowUserToDeleteRows = false;
            this.dtgvAlt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvAlt.Location = new System.Drawing.Point(460, 114);
            this.dtgvAlt.Name = "dtgvAlt";
            this.dtgvAlt.RowHeadersWidth = 51;
            this.dtgvAlt.RowTemplate.Height = 24;
            this.dtgvAlt.Size = new System.Drawing.Size(473, 426);
            this.dtgvAlt.TabIndex = 35;
            // 
            // FrmAlternativas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 553);
            this.Controls.Add(this.dtgvAlt);
            this.Controls.Add(this.grbTiposAlt);
            this.Controls.Add(this.btnPerfilAlt);
            this.Controls.Add(this.btnCSAlt);
            this.Controls.Add(this.lblAlternativas);
            this.Controls.Add(this.pcbLogoAlternatives);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAlternativas";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmAlternativas_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoAlternatives)).EndInit();
            this.grbTiposAlt.ResumeLayout(false);
            this.grbTiposAlt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAlt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContactoAlt;
        private System.Windows.Forms.Button btnRevisionAlt;
        private System.Windows.Forms.Button btnForoAlt;
        private System.Windows.Forms.Button btnDietaAlt;
        private System.Windows.Forms.Button btnAlternAlt;
        private System.Windows.Forms.PictureBox pcbLogoAlternatives;
        private System.Windows.Forms.Label lblAlternativas;
        private System.Windows.Forms.Button btnPerfilAlt;
        private System.Windows.Forms.Button btnCSAlt;
        private System.Windows.Forms.GroupBox grbTiposAlt;
        private System.Windows.Forms.RadioButton rdbCarboAlt;
        private System.Windows.Forms.RadioButton rdbFatsAlt;
        private System.Windows.Forms.RadioButton rdbProteinAlt;
        private System.Windows.Forms.DataGridView dtgvAlt;
    }
}