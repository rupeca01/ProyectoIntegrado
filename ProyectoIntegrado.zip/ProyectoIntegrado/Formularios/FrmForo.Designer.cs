﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmForo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWIPForo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContactoContacto = new System.Windows.Forms.Button();
            this.btnRevisionContacto = new System.Windows.Forms.Button();
            this.btnForoContacto = new System.Windows.Forms.Button();
            this.btnDietaContacto = new System.Windows.Forms.Button();
            this.btnAlternContacto = new System.Windows.Forms.Button();
            this.pcbLogoPerfil = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoPerfil)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWIPForo
            // 
            this.lblWIPForo.AutoSize = true;
            this.lblWIPForo.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWIPForo.Location = new System.Drawing.Point(240, 242);
            this.lblWIPForo.Name = "lblWIPForo";
            this.lblWIPForo.Size = new System.Drawing.Size(507, 69);
            this.lblWIPForo.TabIndex = 0;
            this.lblWIPForo.Text = "Work In Progress";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnContactoContacto);
            this.panel1.Controls.Add(this.btnRevisionContacto);
            this.panel1.Controls.Add(this.btnForoContacto);
            this.panel1.Controls.Add(this.btnDietaContacto);
            this.panel1.Controls.Add(this.btnAlternContacto);
            this.panel1.Location = new System.Drawing.Point(12, 177);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 16;
            // 
            // btnContactoContacto
            // 
            this.btnContactoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactoContacto.Location = new System.Drawing.Point(0, 260);
            this.btnContactoContacto.Name = "btnContactoContacto";
            this.btnContactoContacto.Size = new System.Drawing.Size(160, 59);
            this.btnContactoContacto.TabIndex = 4;
            this.btnContactoContacto.Text = "Contact";
            this.btnContactoContacto.UseVisualStyleBackColor = true;
            // 
            // btnRevisionContacto
            // 
            this.btnRevisionContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionContacto.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionContacto.Name = "btnRevisionContacto";
            this.btnRevisionContacto.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionContacto.TabIndex = 3;
            this.btnRevisionContacto.Text = "Review";
            this.btnRevisionContacto.UseVisualStyleBackColor = true;
            // 
            // btnForoContacto
            // 
            this.btnForoContacto.Enabled = false;
            this.btnForoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoContacto.Location = new System.Drawing.Point(0, 130);
            this.btnForoContacto.Name = "btnForoContacto";
            this.btnForoContacto.Size = new System.Drawing.Size(160, 59);
            this.btnForoContacto.TabIndex = 2;
            this.btnForoContacto.Text = "Forum";
            this.btnForoContacto.UseVisualStyleBackColor = true;
            // 
            // btnDietaContacto
            // 
            this.btnDietaContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaContacto.Location = new System.Drawing.Point(0, 0);
            this.btnDietaContacto.Name = "btnDietaContacto";
            this.btnDietaContacto.Size = new System.Drawing.Size(160, 59);
            this.btnDietaContacto.TabIndex = 1;
            this.btnDietaContacto.Text = "Diet";
            this.btnDietaContacto.UseVisualStyleBackColor = true;
            // 
            // btnAlternContacto
            // 
            this.btnAlternContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternContacto.Location = new System.Drawing.Point(0, 65);
            this.btnAlternContacto.Name = "btnAlternContacto";
            this.btnAlternContacto.Size = new System.Drawing.Size(160, 59);
            this.btnAlternContacto.TabIndex = 0;
            this.btnAlternContacto.Text = "Alternatives";
            this.btnAlternContacto.UseVisualStyleBackColor = true;
            // 
            // pcbLogoPerfil
            // 
            this.pcbLogoPerfil.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoPerfil.Name = "pcbLogoPerfil";
            this.pcbLogoPerfil.Size = new System.Drawing.Size(160, 148);
            this.pcbLogoPerfil.TabIndex = 17;
            this.pcbLogoPerfil.TabStop = false;
            // 
            // FrmForo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 530);
            this.Controls.Add(this.pcbLogoPerfil);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblWIPForo);
            this.Name = "FrmForo";
            this.Text = "FrmForo";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoPerfil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWIPForo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContactoContacto;
        private System.Windows.Forms.Button btnRevisionContacto;
        private System.Windows.Forms.Button btnForoContacto;
        private System.Windows.Forms.Button btnDietaContacto;
        private System.Windows.Forms.Button btnAlternContacto;
        private System.Windows.Forms.PictureBox pcbLogoPerfil;
    }
}