﻿using aev7;
using ProyectoIntegrado.Clases;
using ProyectoIntegrado.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado
{

    public partial class FrmInicioSesion : Form
    {
        public static string mail; //Almacena el mail del usuario al momento del login
        public FrmInicioSesion()
        {
            InitializeComponent();
        }

        private void FrmInicioSesion_Load(object sender, EventArgs e)
        {

        }

        private void linklblRegistro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmRegistro f2 = new FrmRegistro();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnInicioSesion_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConexionBD.Conexion != null)
                {
                    ConexionBD.CerrarConexion();
                    ConexionBD.AbrirConexion();
                    bool credenciales = false;
                    credenciales = Usuario.ValidarUsuario(string.Format("SELECT correo, contraseña FROM usuario WHERE correo LIKE '{0}' AND contraseña LIKE '{1}'", txtEmailInicio.Text, txtPasswordInicio.Text));
                    if (credenciales)
                    {
                        mail = txtEmailInicio.Text; //Almacena el mail para el siguente formulario
                        List<Dieta> ld = new List<Dieta>();
                        ld = Dieta.BuscarDieta(txtEmailInicio.Text);
                        if (ld.Count == 0)
                        {
                            FrmRevision f2 = new FrmRevision();
                            this.Hide();
                            f2.ShowDialog();
                            this.Close();
                            this.Dispose();
                        }
                        else
                        {
                            FrmDieta f2 = new FrmDieta();
                            this.Hide();
                            f2.ShowDialog();
                            this.Close();
                            this.Dispose();
                        }

                    }
                    else
                    {
                        MessageBox.Show("E-mail or password are incorrect.");
                    }
                    ConexionBD.CerrarConexion();

                }
                else
                {
                    MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    ConexionBD.CerrarConexion();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }
    }
}
