﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmRevision : Form
    {
        public FrmRevision()
        {
            InitializeComponent();
        }

        private void tbrAlturaRevision_Scroll(object sender, EventArgs e)
        {
            lblCmRevision.Text = tbrAlturaRevision.Value.ToString() + " cm";
        }

        private void FrmRevision_Load(object sender, EventArgs e)
        {
            ConexionBD.CerrarConexion();
            ConexionBD.AbrirConexion();
            lblCmRevision.Text = tbrAlturaRevision.Value.ToString() + " cm";
            if (Usuario.ComprobacionReturn(FrmInicioSesion.mail))
            {
                btnVolverRe.Visible = true;
            }
            else
            {
                btnVolverRe.Visible = false;
            }
            ConexionBD.CerrarConexion();
        }

        private void btnCalcRevision_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            try
            {
                if (ConexionBD.Conexion != null)
                {
                    ConexionBD.CerrarConexion();
                    ConexionBD.AbrirConexion();
                    Usuario usu = new Usuario();
                    usu.Peso = nudKgRevision.Value;
                    usu.Altura = tbrAlturaRevision.Value;
                    usu.Objetivo = cmbObjRevision.Text;
                    List<Usuario> l = Usuario.BuscarID(FrmInicioSesion.mail);
                    usu.IdUSuario = l[0].IdUSuario;
                    usu.Correo = FrmInicioSesion.mail;
                    usu.Sexo = Usuario.ConsultaSexo(FrmInicioSesion.mail);
                    usu.FechaNacimiento = Usuario.ConsultaFecha(FrmInicioSesion.mail);
                    List<Dieta> listaDieta = new List<Dieta>();
                    listaDieta = Dieta.BuscarDieta(usu.IdUSuario);
                    if (listaDieta.Count == 0)
                    {
                        resultado = Usuario.Dieta(usu, cmbObjRevision.Text);
                        string desayuno = Comidas.GenerarDesayuno(usu.Peso, usu.Sexo, usu.Altura, usu.CalcularEdad(), usu.Objetivo);
                        string almuerzo = Comidas.GenerarAlmuerzo(usu.Peso, usu.Sexo, usu.Altura, usu.CalcularEdad(), usu.Objetivo);
                        string comida = Comidas.GenerarComida(usu.Peso, usu.Sexo, usu.Altura, usu.CalcularEdad(), usu.Objetivo);
                        string merienda = Comidas.GenerarMerienda(usu.Peso, usu.Sexo, usu.Altura, usu.CalcularEdad(), usu.Objetivo);
                        string cena = Comidas.GenerarCena(usu.Peso, usu.Sexo, usu.Altura, usu.CalcularEdad(), usu.Objetivo);
                        Comidas.SubirComidas(desayuno, almuerzo, comida, merienda, cena, FrmInicioSesion.mail);
                        ConexionBD.CerrarConexion();


                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("There is an active diet and a new one won't be generated. Do you wish to update your data? ", "Changes confirmation", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            resultado = Usuario.ActualizaDatos(usu);
                            ConexionBD.CerrarConexion();
                        }
                        else if (dialogResult == DialogResult.No)
                        {
                            MessageBox.Show("Changes won't be applied");
                            FrmDieta f2 = new FrmDieta();
                            this.Hide();
                            f2.ShowDialog();
                            this.Close();
                            this.Dispose();
                            ConexionBD.CerrarConexion();
                        }
                    }

                    if (resultado > 0)
                    {
                        FrmDieta f2 = new FrmDieta();
                        this.Hide();
                        f2.ShowDialog();
                        this.Close();
                        this.Dispose();
                        ConexionBD.CerrarConexion();

                    }
                    ConexionBD.CerrarConexion();
                }
                else
                {
                    MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    ConexionBD.CerrarConexion();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }

        private void btnVolverRe_Click(object sender, EventArgs e)
        {
            FrmDieta f2 = new FrmDieta();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }
    }
}
