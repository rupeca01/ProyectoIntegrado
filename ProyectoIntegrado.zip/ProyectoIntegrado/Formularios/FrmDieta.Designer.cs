﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmDieta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDieta));
            this.pcbLogoDieta = new System.Windows.Forms.PictureBox();
            this.lblDieta = new System.Windows.Forms.Label();
            this.lblFechaDieta = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContacto = new System.Windows.Forms.Button();
            this.btnRevisionDieta = new System.Windows.Forms.Button();
            this.btnForoDieta = new System.Windows.Forms.Button();
            this.btnDietaDieta = new System.Windows.Forms.Button();
            this.btnAlternDieta = new System.Windows.Forms.Button();
            this.btnCSDieta = new System.Windows.Forms.Button();
            this.btnPerfilDieta = new System.Windows.Forms.Button();
            this.txtDesDieta = new System.Windows.Forms.TextBox();
            this.lblDesDieta = new System.Windows.Forms.Label();
            this.lblAlmuDieta = new System.Windows.Forms.Label();
            this.txtAlmuDieta = new System.Windows.Forms.TextBox();
            this.txtComDieta = new System.Windows.Forms.TextBox();
            this.lblComDieta = new System.Windows.Forms.Label();
            this.txtMerDieta = new System.Windows.Forms.TextBox();
            this.lblMerDieta = new System.Windows.Forms.Label();
            this.txtCenaDieta = new System.Windows.Forms.TextBox();
            this.lblCenaDieta = new System.Windows.Forms.Label();
            this.tlpDieta = new System.Windows.Forms.TableLayoutPanel();
            this.txtDSUD = new System.Windows.Forms.TextBox();
            this.txtDSAD = new System.Windows.Forms.TextBox();
            this.txtDFD = new System.Windows.Forms.TextBox();
            this.txtDTHD = new System.Windows.Forms.TextBox();
            this.txtDWD = new System.Windows.Forms.TextBox();
            this.txtDTD = new System.Windows.Forms.TextBox();
            this.txtDMD = new System.Windows.Forms.TextBox();
            this.txtSSUD = new System.Windows.Forms.TextBox();
            this.txtSSAD = new System.Windows.Forms.TextBox();
            this.txtSFD = new System.Windows.Forms.TextBox();
            this.txtSTHD = new System.Windows.Forms.TextBox();
            this.txtSWD = new System.Windows.Forms.TextBox();
            this.txtSTD = new System.Windows.Forms.TextBox();
            this.txtSMD = new System.Windows.Forms.TextBox();
            this.txtMSUD = new System.Windows.Forms.TextBox();
            this.txtMSAD = new System.Windows.Forms.TextBox();
            this.txtMFD = new System.Windows.Forms.TextBox();
            this.txtMTHD = new System.Windows.Forms.TextBox();
            this.txtMWD = new System.Windows.Forms.TextBox();
            this.txtMTD = new System.Windows.Forms.TextBox();
            this.txtMMD = new System.Windows.Forms.TextBox();
            this.txtLSUD = new System.Windows.Forms.TextBox();
            this.txtLSAD = new System.Windows.Forms.TextBox();
            this.txtLFD = new System.Windows.Forms.TextBox();
            this.txtLTHD = new System.Windows.Forms.TextBox();
            this.txtLWD = new System.Windows.Forms.TextBox();
            this.txtLTD = new System.Windows.Forms.TextBox();
            this.txtLMD = new System.Windows.Forms.TextBox();
            this.txtBSUD = new System.Windows.Forms.TextBox();
            this.txtBSAD = new System.Windows.Forms.TextBox();
            this.txtBFD = new System.Windows.Forms.TextBox();
            this.txtBTHD = new System.Windows.Forms.TextBox();
            this.txtBWD = new System.Windows.Forms.TextBox();
            this.txtxBTD = new System.Windows.Forms.TextBox();
            this.txtBMD = new System.Windows.Forms.TextBox();
            this.lblCenaD = new System.Windows.Forms.Label();
            this.lblAlmuerzoD = new System.Windows.Forms.Label();
            this.lblDesayunoD = new System.Windows.Forms.Label();
            this.lblDomingoD = new System.Windows.Forms.Label();
            this.lblSabadoD = new System.Windows.Forms.Label();
            this.lblViernesD = new System.Windows.Forms.Label();
            this.lblJuevesD = new System.Windows.Forms.Label();
            this.lblMiercolesD = new System.Windows.Forms.Label();
            this.lblLunesD = new System.Windows.Forms.Label();
            this.lblMartesD = new System.Windows.Forms.Label();
            this.lblComidaD = new System.Windows.Forms.Label();
            this.lblMeriendaD = new System.Windows.Forms.Label();
            this.btnSaveDieta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoDieta)).BeginInit();
            this.panel1.SuspendLayout();
            this.tlpDieta.SuspendLayout();
            this.SuspendLayout();
            // 
            // pcbLogoDieta
            // 
            this.pcbLogoDieta.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoDieta.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoDieta.Name = "pcbLogoDieta";
            this.pcbLogoDieta.Size = new System.Drawing.Size(238, 148);
            this.pcbLogoDieta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoDieta.TabIndex = 4;
            this.pcbLogoDieta.TabStop = false;
            // 
            // lblDieta
            // 
            this.lblDieta.AutoSize = true;
            this.lblDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDieta.Location = new System.Drawing.Point(350, 52);
            this.lblDieta.Name = "lblDieta";
            this.lblDieta.Size = new System.Drawing.Size(88, 44);
            this.lblDieta.TabIndex = 6;
            this.lblDieta.Text = "Diet";
            // 
            // lblFechaDieta
            // 
            this.lblFechaDieta.AutoSize = true;
            this.lblFechaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaDieta.Location = new System.Drawing.Point(548, 72);
            this.lblFechaDieta.Name = "lblFechaDieta";
            this.lblFechaDieta.Size = new System.Drawing.Size(53, 24);
            this.lblFechaDieta.TabIndex = 9;
            this.lblFechaDieta.Text = "Date:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnContacto);
            this.panel1.Controls.Add(this.btnRevisionDieta);
            this.panel1.Controls.Add(this.btnForoDieta);
            this.panel1.Controls.Add(this.btnDietaDieta);
            this.panel1.Controls.Add(this.btnAlternDieta);
            this.panel1.Location = new System.Drawing.Point(12, 184);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 10;
            // 
            // btnContacto
            // 
            this.btnContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContacto.Location = new System.Drawing.Point(0, 260);
            this.btnContacto.Name = "btnContacto";
            this.btnContacto.Size = new System.Drawing.Size(160, 59);
            this.btnContacto.TabIndex = 5;
            this.btnContacto.Text = "Contact";
            this.btnContacto.UseVisualStyleBackColor = true;
            this.btnContacto.Click += new System.EventHandler(this.btnContacto_Click);
            // 
            // btnRevisionDieta
            // 
            this.btnRevisionDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionDieta.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionDieta.Name = "btnRevisionDieta";
            this.btnRevisionDieta.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionDieta.TabIndex = 4;
            this.btnRevisionDieta.Text = "Review";
            this.btnRevisionDieta.UseVisualStyleBackColor = true;
            this.btnRevisionDieta.Click += new System.EventHandler(this.btnRevisionDieta_Click);
            // 
            // btnForoDieta
            // 
            this.btnForoDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoDieta.Location = new System.Drawing.Point(0, 130);
            this.btnForoDieta.Name = "btnForoDieta";
            this.btnForoDieta.Size = new System.Drawing.Size(160, 59);
            this.btnForoDieta.TabIndex = 3;
            this.btnForoDieta.Text = "Forum";
            this.btnForoDieta.UseVisualStyleBackColor = true;
            this.btnForoDieta.Click += new System.EventHandler(this.btnForoDieta_Click);
            // 
            // btnDietaDieta
            // 
            this.btnDietaDieta.Enabled = false;
            this.btnDietaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaDieta.Location = new System.Drawing.Point(0, 0);
            this.btnDietaDieta.Name = "btnDietaDieta";
            this.btnDietaDieta.Size = new System.Drawing.Size(160, 59);
            this.btnDietaDieta.TabIndex = 1;
            this.btnDietaDieta.Text = "Diet";
            this.btnDietaDieta.UseVisualStyleBackColor = true;
            // 
            // btnAlternDieta
            // 
            this.btnAlternDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternDieta.Location = new System.Drawing.Point(0, 65);
            this.btnAlternDieta.Name = "btnAlternDieta";
            this.btnAlternDieta.Size = new System.Drawing.Size(160, 59);
            this.btnAlternDieta.TabIndex = 2;
            this.btnAlternDieta.Text = "Alternatives";
            this.btnAlternDieta.UseVisualStyleBackColor = true;
            this.btnAlternDieta.Click += new System.EventHandler(this.btnAlternDieta_Click);
            // 
            // btnCSDieta
            // 
            this.btnCSDieta.Location = new System.Drawing.Point(1148, 12);
            this.btnCSDieta.Name = "btnCSDieta";
            this.btnCSDieta.Size = new System.Drawing.Size(78, 26);
            this.btnCSDieta.TabIndex = 11;
            this.btnCSDieta.Text = "Log Out";
            this.btnCSDieta.UseVisualStyleBackColor = true;
            this.btnCSDieta.Click += new System.EventHandler(this.btnCSDieta_Click);
            // 
            // btnPerfilDieta
            // 
            this.btnPerfilDieta.Location = new System.Drawing.Point(1232, 12);
            this.btnPerfilDieta.Name = "btnPerfilDieta";
            this.btnPerfilDieta.Size = new System.Drawing.Size(78, 26);
            this.btnPerfilDieta.TabIndex = 12;
            this.btnPerfilDieta.Text = "Profile";
            this.btnPerfilDieta.UseVisualStyleBackColor = true;
            this.btnPerfilDieta.Click += new System.EventHandler(this.btnPerfilDieta_Click);
            // 
            // txtDesDieta
            // 
            this.txtDesDieta.Enabled = false;
            this.txtDesDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesDieta.Location = new System.Drawing.Point(312, 184);
            this.txtDesDieta.Multiline = true;
            this.txtDesDieta.Name = "txtDesDieta";
            this.txtDesDieta.Size = new System.Drawing.Size(194, 59);
            this.txtDesDieta.TabIndex = 13;
            // 
            // lblDesDieta
            // 
            this.lblDesDieta.AutoSize = true;
            this.lblDesDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesDieta.Location = new System.Drawing.Point(206, 197);
            this.lblDesDieta.Name = "lblDesDieta";
            this.lblDesDieta.Size = new System.Drawing.Size(90, 24);
            this.lblDesDieta.TabIndex = 14;
            this.lblDesDieta.Text = "Breakfast:";
            // 
            // lblAlmuDieta
            // 
            this.lblAlmuDieta.AutoSize = true;
            this.lblAlmuDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlmuDieta.Location = new System.Drawing.Point(228, 271);
            this.lblAlmuDieta.Name = "lblAlmuDieta";
            this.lblAlmuDieta.Size = new System.Drawing.Size(68, 24);
            this.lblAlmuDieta.TabIndex = 15;
            this.lblAlmuDieta.Text = "Lunch:";
            // 
            // txtAlmuDieta
            // 
            this.txtAlmuDieta.Enabled = false;
            this.txtAlmuDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlmuDieta.Location = new System.Drawing.Point(312, 259);
            this.txtAlmuDieta.Multiline = true;
            this.txtAlmuDieta.Name = "txtAlmuDieta";
            this.txtAlmuDieta.Size = new System.Drawing.Size(194, 59);
            this.txtAlmuDieta.TabIndex = 16;
            // 
            // txtComDieta
            // 
            this.txtComDieta.Enabled = false;
            this.txtComDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComDieta.Location = new System.Drawing.Point(312, 325);
            this.txtComDieta.Multiline = true;
            this.txtComDieta.Name = "txtComDieta";
            this.txtComDieta.Size = new System.Drawing.Size(194, 59);
            this.txtComDieta.TabIndex = 18;
            // 
            // lblComDieta
            // 
            this.lblComDieta.AutoSize = true;
            this.lblComDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComDieta.Location = new System.Drawing.Point(240, 337);
            this.lblComDieta.Name = "lblComDieta";
            this.lblComDieta.Size = new System.Drawing.Size(56, 24);
            this.lblComDieta.TabIndex = 17;
            this.lblComDieta.Text = "Meal:";
            // 
            // txtMerDieta
            // 
            this.txtMerDieta.Enabled = false;
            this.txtMerDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMerDieta.Location = new System.Drawing.Point(312, 389);
            this.txtMerDieta.Multiline = true;
            this.txtMerDieta.Name = "txtMerDieta";
            this.txtMerDieta.Size = new System.Drawing.Size(194, 59);
            this.txtMerDieta.TabIndex = 20;
            // 
            // lblMerDieta
            // 
            this.lblMerDieta.AutoSize = true;
            this.lblMerDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMerDieta.Location = new System.Drawing.Point(229, 401);
            this.lblMerDieta.Name = "lblMerDieta";
            this.lblMerDieta.Size = new System.Drawing.Size(67, 24);
            this.lblMerDieta.TabIndex = 19;
            this.lblMerDieta.Text = "Snack:";
            // 
            // txtCenaDieta
            // 
            this.txtCenaDieta.Enabled = false;
            this.txtCenaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCenaDieta.Location = new System.Drawing.Point(312, 455);
            this.txtCenaDieta.Multiline = true;
            this.txtCenaDieta.Name = "txtCenaDieta";
            this.txtCenaDieta.Size = new System.Drawing.Size(194, 59);
            this.txtCenaDieta.TabIndex = 22;
            // 
            // lblCenaDieta
            // 
            this.lblCenaDieta.AutoSize = true;
            this.lblCenaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaDieta.Location = new System.Drawing.Point(225, 467);
            this.lblCenaDieta.Name = "lblCenaDieta";
            this.lblCenaDieta.Size = new System.Drawing.Size(71, 24);
            this.lblCenaDieta.TabIndex = 21;
            this.lblCenaDieta.Text = "Dinner:";
            // 
            // tlpDieta
            // 
            this.tlpDieta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tlpDieta.ColumnCount = 8;
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.42857F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.57143F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 97F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tlpDieta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tlpDieta.Controls.Add(this.txtDSUD, 7, 5);
            this.tlpDieta.Controls.Add(this.txtDSAD, 6, 5);
            this.tlpDieta.Controls.Add(this.txtDFD, 5, 5);
            this.tlpDieta.Controls.Add(this.txtDTHD, 4, 5);
            this.tlpDieta.Controls.Add(this.txtDWD, 3, 5);
            this.tlpDieta.Controls.Add(this.txtDTD, 2, 5);
            this.tlpDieta.Controls.Add(this.txtDMD, 1, 5);
            this.tlpDieta.Controls.Add(this.txtSSUD, 7, 4);
            this.tlpDieta.Controls.Add(this.txtSSAD, 6, 4);
            this.tlpDieta.Controls.Add(this.txtSFD, 5, 4);
            this.tlpDieta.Controls.Add(this.txtSTHD, 4, 4);
            this.tlpDieta.Controls.Add(this.txtSWD, 3, 4);
            this.tlpDieta.Controls.Add(this.txtSTD, 2, 4);
            this.tlpDieta.Controls.Add(this.txtSMD, 1, 4);
            this.tlpDieta.Controls.Add(this.txtMSUD, 7, 3);
            this.tlpDieta.Controls.Add(this.txtMSAD, 6, 3);
            this.tlpDieta.Controls.Add(this.txtMFD, 5, 3);
            this.tlpDieta.Controls.Add(this.txtMTHD, 4, 3);
            this.tlpDieta.Controls.Add(this.txtMWD, 3, 3);
            this.tlpDieta.Controls.Add(this.txtMTD, 2, 3);
            this.tlpDieta.Controls.Add(this.txtMMD, 1, 3);
            this.tlpDieta.Controls.Add(this.txtLSUD, 7, 2);
            this.tlpDieta.Controls.Add(this.txtLSAD, 6, 2);
            this.tlpDieta.Controls.Add(this.txtLFD, 5, 2);
            this.tlpDieta.Controls.Add(this.txtLTHD, 4, 2);
            this.tlpDieta.Controls.Add(this.txtLWD, 3, 2);
            this.tlpDieta.Controls.Add(this.txtLTD, 2, 2);
            this.tlpDieta.Controls.Add(this.txtLMD, 1, 2);
            this.tlpDieta.Controls.Add(this.txtBSUD, 7, 1);
            this.tlpDieta.Controls.Add(this.txtBSAD, 6, 1);
            this.tlpDieta.Controls.Add(this.txtBFD, 5, 1);
            this.tlpDieta.Controls.Add(this.txtBTHD, 4, 1);
            this.tlpDieta.Controls.Add(this.txtBWD, 3, 1);
            this.tlpDieta.Controls.Add(this.txtxBTD, 2, 1);
            this.tlpDieta.Controls.Add(this.txtBMD, 1, 1);
            this.tlpDieta.Controls.Add(this.lblCenaD, 0, 5);
            this.tlpDieta.Controls.Add(this.lblAlmuerzoD, 0, 2);
            this.tlpDieta.Controls.Add(this.lblDesayunoD, 0, 1);
            this.tlpDieta.Controls.Add(this.lblDomingoD, 7, 0);
            this.tlpDieta.Controls.Add(this.lblSabadoD, 6, 0);
            this.tlpDieta.Controls.Add(this.lblViernesD, 5, 0);
            this.tlpDieta.Controls.Add(this.lblJuevesD, 4, 0);
            this.tlpDieta.Controls.Add(this.lblMiercolesD, 3, 0);
            this.tlpDieta.Controls.Add(this.lblLunesD, 1, 0);
            this.tlpDieta.Controls.Add(this.lblMartesD, 2, 0);
            this.tlpDieta.Controls.Add(this.lblComidaD, 0, 3);
            this.tlpDieta.Controls.Add(this.lblMeriendaD, 0, 4);
            this.tlpDieta.Location = new System.Drawing.Point(560, 195);
            this.tlpDieta.Name = "tlpDieta";
            this.tlpDieta.RowCount = 6;
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29.26829F));
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.7317F));
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tlpDieta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tlpDieta.Size = new System.Drawing.Size(750, 309);
            this.tlpDieta.TabIndex = 23;
            // 
            // txtDSUD
            // 
            this.txtDSUD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDSUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDSUD.Location = new System.Drawing.Point(656, 254);
            this.txtDSUD.Multiline = true;
            this.txtDSUD.Name = "txtDSUD";
            this.txtDSUD.Size = new System.Drawing.Size(90, 49);
            this.txtDSUD.TabIndex = 40;
            // 
            // txtDSAD
            // 
            this.txtDSAD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDSAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDSAD.Location = new System.Drawing.Point(560, 254);
            this.txtDSAD.Multiline = true;
            this.txtDSAD.Name = "txtDSAD";
            this.txtDSAD.Size = new System.Drawing.Size(90, 49);
            this.txtDSAD.TabIndex = 35;
            // 
            // txtDFD
            // 
            this.txtDFD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDFD.Location = new System.Drawing.Point(465, 254);
            this.txtDFD.Multiline = true;
            this.txtDFD.Name = "txtDFD";
            this.txtDFD.Size = new System.Drawing.Size(89, 49);
            this.txtDFD.TabIndex = 30;
            // 
            // txtDTHD
            // 
            this.txtDTHD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDTHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDTHD.Location = new System.Drawing.Point(368, 254);
            this.txtDTHD.Multiline = true;
            this.txtDTHD.Name = "txtDTHD";
            this.txtDTHD.Size = new System.Drawing.Size(91, 49);
            this.txtDTHD.TabIndex = 25;
            // 
            // txtDWD
            // 
            this.txtDWD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDWD.Location = new System.Drawing.Point(274, 254);
            this.txtDWD.Multiline = true;
            this.txtDWD.Name = "txtDWD";
            this.txtDWD.Size = new System.Drawing.Size(88, 49);
            this.txtDWD.TabIndex = 20;
            // 
            // txtDTD
            // 
            this.txtDTD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDTD.Location = new System.Drawing.Point(179, 254);
            this.txtDTD.Multiline = true;
            this.txtDTD.Name = "txtDTD";
            this.txtDTD.Size = new System.Drawing.Size(89, 49);
            this.txtDTD.TabIndex = 15;
            // 
            // txtDMD
            // 
            this.txtDMD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtDMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDMD.Location = new System.Drawing.Point(85, 254);
            this.txtDMD.Multiline = true;
            this.txtDMD.Name = "txtDMD";
            this.txtDMD.Size = new System.Drawing.Size(88, 49);
            this.txtDMD.TabIndex = 10;
            // 
            // txtSSUD
            // 
            this.txtSSUD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSSUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSUD.Location = new System.Drawing.Point(656, 194);
            this.txtSSUD.Multiline = true;
            this.txtSSUD.Name = "txtSSUD";
            this.txtSSUD.Size = new System.Drawing.Size(90, 49);
            this.txtSSUD.TabIndex = 39;
            // 
            // txtSSAD
            // 
            this.txtSSAD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSSAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSAD.Location = new System.Drawing.Point(560, 194);
            this.txtSSAD.Multiline = true;
            this.txtSSAD.Name = "txtSSAD";
            this.txtSSAD.Size = new System.Drawing.Size(90, 49);
            this.txtSSAD.TabIndex = 34;
            // 
            // txtSFD
            // 
            this.txtSFD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSFD.Location = new System.Drawing.Point(465, 194);
            this.txtSFD.Multiline = true;
            this.txtSFD.Name = "txtSFD";
            this.txtSFD.Size = new System.Drawing.Size(89, 49);
            this.txtSFD.TabIndex = 29;
            // 
            // txtSTHD
            // 
            this.txtSTHD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSTHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSTHD.Location = new System.Drawing.Point(368, 194);
            this.txtSTHD.Multiline = true;
            this.txtSTHD.Name = "txtSTHD";
            this.txtSTHD.Size = new System.Drawing.Size(91, 49);
            this.txtSTHD.TabIndex = 24;
            // 
            // txtSWD
            // 
            this.txtSWD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSWD.Location = new System.Drawing.Point(274, 194);
            this.txtSWD.Multiline = true;
            this.txtSWD.Name = "txtSWD";
            this.txtSWD.Size = new System.Drawing.Size(88, 49);
            this.txtSWD.TabIndex = 19;
            // 
            // txtSTD
            // 
            this.txtSTD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSTD.Location = new System.Drawing.Point(179, 194);
            this.txtSTD.Multiline = true;
            this.txtSTD.Name = "txtSTD";
            this.txtSTD.Size = new System.Drawing.Size(89, 49);
            this.txtSTD.TabIndex = 14;
            // 
            // txtSMD
            // 
            this.txtSMD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtSMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSMD.Location = new System.Drawing.Point(85, 194);
            this.txtSMD.Multiline = true;
            this.txtSMD.Name = "txtSMD";
            this.txtSMD.Size = new System.Drawing.Size(88, 49);
            this.txtSMD.TabIndex = 9;
            // 
            // txtMSUD
            // 
            this.txtMSUD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMSUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSUD.Location = new System.Drawing.Point(656, 137);
            this.txtMSUD.Multiline = true;
            this.txtMSUD.Name = "txtMSUD";
            this.txtMSUD.Size = new System.Drawing.Size(90, 49);
            this.txtMSUD.TabIndex = 38;
            // 
            // txtMSAD
            // 
            this.txtMSAD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMSAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSAD.Location = new System.Drawing.Point(560, 137);
            this.txtMSAD.Multiline = true;
            this.txtMSAD.Name = "txtMSAD";
            this.txtMSAD.Size = new System.Drawing.Size(90, 49);
            this.txtMSAD.TabIndex = 33;
            // 
            // txtMFD
            // 
            this.txtMFD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMFD.Location = new System.Drawing.Point(465, 137);
            this.txtMFD.Multiline = true;
            this.txtMFD.Name = "txtMFD";
            this.txtMFD.Size = new System.Drawing.Size(89, 49);
            this.txtMFD.TabIndex = 28;
            // 
            // txtMTHD
            // 
            this.txtMTHD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMTHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMTHD.Location = new System.Drawing.Point(368, 137);
            this.txtMTHD.Multiline = true;
            this.txtMTHD.Name = "txtMTHD";
            this.txtMTHD.Size = new System.Drawing.Size(91, 49);
            this.txtMTHD.TabIndex = 23;
            // 
            // txtMWD
            // 
            this.txtMWD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMWD.Location = new System.Drawing.Point(274, 137);
            this.txtMWD.Multiline = true;
            this.txtMWD.Name = "txtMWD";
            this.txtMWD.Size = new System.Drawing.Size(88, 49);
            this.txtMWD.TabIndex = 18;
            // 
            // txtMTD
            // 
            this.txtMTD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMTD.Location = new System.Drawing.Point(179, 137);
            this.txtMTD.Multiline = true;
            this.txtMTD.Name = "txtMTD";
            this.txtMTD.Size = new System.Drawing.Size(89, 49);
            this.txtMTD.TabIndex = 13;
            // 
            // txtMMD
            // 
            this.txtMMD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtMMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMMD.Location = new System.Drawing.Point(85, 137);
            this.txtMMD.Multiline = true;
            this.txtMMD.Name = "txtMMD";
            this.txtMMD.Size = new System.Drawing.Size(88, 49);
            this.txtMMD.TabIndex = 8;
            // 
            // txtLSUD
            // 
            this.txtLSUD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLSUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLSUD.Location = new System.Drawing.Point(656, 81);
            this.txtLSUD.Multiline = true;
            this.txtLSUD.Name = "txtLSUD";
            this.txtLSUD.Size = new System.Drawing.Size(90, 49);
            this.txtLSUD.TabIndex = 37;
            // 
            // txtLSAD
            // 
            this.txtLSAD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLSAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLSAD.Location = new System.Drawing.Point(560, 81);
            this.txtLSAD.Multiline = true;
            this.txtLSAD.Name = "txtLSAD";
            this.txtLSAD.Size = new System.Drawing.Size(90, 49);
            this.txtLSAD.TabIndex = 32;
            // 
            // txtLFD
            // 
            this.txtLFD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLFD.Location = new System.Drawing.Point(465, 81);
            this.txtLFD.Multiline = true;
            this.txtLFD.Name = "txtLFD";
            this.txtLFD.Size = new System.Drawing.Size(89, 49);
            this.txtLFD.TabIndex = 27;
            // 
            // txtLTHD
            // 
            this.txtLTHD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLTHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLTHD.Location = new System.Drawing.Point(368, 81);
            this.txtLTHD.Multiline = true;
            this.txtLTHD.Name = "txtLTHD";
            this.txtLTHD.Size = new System.Drawing.Size(89, 49);
            this.txtLTHD.TabIndex = 22;
            // 
            // txtLWD
            // 
            this.txtLWD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLWD.Location = new System.Drawing.Point(274, 81);
            this.txtLWD.Multiline = true;
            this.txtLWD.Name = "txtLWD";
            this.txtLWD.Size = new System.Drawing.Size(88, 49);
            this.txtLWD.TabIndex = 17;
            // 
            // txtLTD
            // 
            this.txtLTD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLTD.Location = new System.Drawing.Point(179, 81);
            this.txtLTD.Multiline = true;
            this.txtLTD.Name = "txtLTD";
            this.txtLTD.Size = new System.Drawing.Size(89, 49);
            this.txtLTD.TabIndex = 12;
            // 
            // txtLMD
            // 
            this.txtLMD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtLMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLMD.Location = new System.Drawing.Point(85, 81);
            this.txtLMD.Multiline = true;
            this.txtLMD.Name = "txtLMD";
            this.txtLMD.Size = new System.Drawing.Size(88, 49);
            this.txtLMD.TabIndex = 7;
            // 
            // txtBSUD
            // 
            this.txtBSUD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBSUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBSUD.Location = new System.Drawing.Point(656, 26);
            this.txtBSUD.Multiline = true;
            this.txtBSUD.Name = "txtBSUD";
            this.txtBSUD.Size = new System.Drawing.Size(89, 49);
            this.txtBSUD.TabIndex = 36;
            // 
            // txtBSAD
            // 
            this.txtBSAD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBSAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBSAD.Location = new System.Drawing.Point(560, 26);
            this.txtBSAD.Multiline = true;
            this.txtBSAD.Name = "txtBSAD";
            this.txtBSAD.Size = new System.Drawing.Size(90, 49);
            this.txtBSAD.TabIndex = 31;
            // 
            // txtBFD
            // 
            this.txtBFD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBFD.Location = new System.Drawing.Point(465, 26);
            this.txtBFD.Multiline = true;
            this.txtBFD.Name = "txtBFD";
            this.txtBFD.Size = new System.Drawing.Size(89, 49);
            this.txtBFD.TabIndex = 26;
            // 
            // txtBTHD
            // 
            this.txtBTHD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBTHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBTHD.Location = new System.Drawing.Point(368, 26);
            this.txtBTHD.Multiline = true;
            this.txtBTHD.Name = "txtBTHD";
            this.txtBTHD.Size = new System.Drawing.Size(89, 49);
            this.txtBTHD.TabIndex = 21;
            // 
            // txtBWD
            // 
            this.txtBWD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBWD.Location = new System.Drawing.Point(274, 26);
            this.txtBWD.Multiline = true;
            this.txtBWD.Name = "txtBWD";
            this.txtBWD.Size = new System.Drawing.Size(88, 49);
            this.txtBWD.TabIndex = 16;
            // 
            // txtxBTD
            // 
            this.txtxBTD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtxBTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxBTD.Location = new System.Drawing.Point(179, 26);
            this.txtxBTD.Multiline = true;
            this.txtxBTD.Name = "txtxBTD";
            this.txtxBTD.Size = new System.Drawing.Size(89, 49);
            this.txtxBTD.TabIndex = 11;
            // 
            // txtBMD
            // 
            this.txtBMD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBMD.Location = new System.Drawing.Point(85, 26);
            this.txtBMD.Multiline = true;
            this.txtBMD.Name = "txtBMD";
            this.txtBMD.Size = new System.Drawing.Size(88, 49);
            this.txtBMD.TabIndex = 6;
            // 
            // lblCenaD
            // 
            this.lblCenaD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblCenaD.AutoSize = true;
            this.lblCenaD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaD.Location = new System.Drawing.Point(3, 270);
            this.lblCenaD.Name = "lblCenaD";
            this.lblCenaD.Size = new System.Drawing.Size(50, 17);
            this.lblCenaD.TabIndex = 25;
            this.lblCenaD.Text = "Dinner";
            // 
            // lblAlmuerzoD
            // 
            this.lblAlmuerzoD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblAlmuerzoD.AutoSize = true;
            this.lblAlmuerzoD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlmuerzoD.Location = new System.Drawing.Point(3, 97);
            this.lblAlmuerzoD.Name = "lblAlmuerzoD";
            this.lblAlmuerzoD.Size = new System.Drawing.Size(47, 17);
            this.lblAlmuerzoD.TabIndex = 24;
            this.lblAlmuerzoD.Text = "Lunch";
            // 
            // lblDesayunoD
            // 
            this.lblDesayunoD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblDesayunoD.AutoSize = true;
            this.lblDesayunoD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesayunoD.Location = new System.Drawing.Point(3, 42);
            this.lblDesayunoD.Name = "lblDesayunoD";
            this.lblDesayunoD.Size = new System.Drawing.Size(68, 17);
            this.lblDesayunoD.TabIndex = 24;
            this.lblDesayunoD.Text = "Breakfast";
            // 
            // lblDomingoD
            // 
            this.lblDomingoD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDomingoD.AutoSize = true;
            this.lblDomingoD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDomingoD.Location = new System.Drawing.Point(673, 3);
            this.lblDomingoD.Name = "lblDomingoD";
            this.lblDomingoD.Size = new System.Drawing.Size(56, 17);
            this.lblDomingoD.TabIndex = 24;
            this.lblDomingoD.Text = "Sunday";
            // 
            // lblSabadoD
            // 
            this.lblSabadoD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSabadoD.AutoSize = true;
            this.lblSabadoD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSabadoD.Location = new System.Drawing.Point(572, 3);
            this.lblSabadoD.Name = "lblSabadoD";
            this.lblSabadoD.Size = new System.Drawing.Size(65, 17);
            this.lblSabadoD.TabIndex = 24;
            this.lblSabadoD.Text = "Saturday";
            // 
            // lblViernesD
            // 
            this.lblViernesD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViernesD.AutoSize = true;
            this.lblViernesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViernesD.Location = new System.Drawing.Point(486, 3);
            this.lblViernesD.Name = "lblViernesD";
            this.lblViernesD.Size = new System.Drawing.Size(47, 17);
            this.lblViernesD.TabIndex = 24;
            this.lblViernesD.Text = "Friday";
            // 
            // lblJuevesD
            // 
            this.lblJuevesD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblJuevesD.AutoSize = true;
            this.lblJuevesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJuevesD.Location = new System.Drawing.Point(379, 3);
            this.lblJuevesD.Name = "lblJuevesD";
            this.lblJuevesD.Size = new System.Drawing.Size(68, 17);
            this.lblJuevesD.TabIndex = 24;
            this.lblJuevesD.Text = "Thursday";
            // 
            // lblMiercolesD
            // 
            this.lblMiercolesD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMiercolesD.AutoSize = true;
            this.lblMiercolesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiercolesD.Location = new System.Drawing.Point(276, 3);
            this.lblMiercolesD.Name = "lblMiercolesD";
            this.lblMiercolesD.Size = new System.Drawing.Size(83, 17);
            this.lblMiercolesD.TabIndex = 24;
            this.lblMiercolesD.Text = "Wednesday";
            // 
            // lblLunesD
            // 
            this.lblLunesD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLunesD.AutoSize = true;
            this.lblLunesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLunesD.Location = new System.Drawing.Point(100, 3);
            this.lblLunesD.Name = "lblLunesD";
            this.lblLunesD.Size = new System.Drawing.Size(58, 17);
            this.lblLunesD.TabIndex = 10;
            this.lblLunesD.Text = "Monday";
            // 
            // lblMartesD
            // 
            this.lblMartesD.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMartesD.AutoSize = true;
            this.lblMartesD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMartesD.Location = new System.Drawing.Point(192, 3);
            this.lblMartesD.Name = "lblMartesD";
            this.lblMartesD.Size = new System.Drawing.Size(63, 17);
            this.lblMartesD.TabIndex = 11;
            this.lblMartesD.Text = "Tuesday";
            // 
            // lblComidaD
            // 
            this.lblComidaD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblComidaD.AutoSize = true;
            this.lblComidaD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComidaD.Location = new System.Drawing.Point(3, 153);
            this.lblComidaD.Name = "lblComidaD";
            this.lblComidaD.Size = new System.Drawing.Size(38, 17);
            this.lblComidaD.TabIndex = 24;
            this.lblComidaD.Text = "Meal";
            // 
            // lblMeriendaD
            // 
            this.lblMeriendaD.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblMeriendaD.AutoSize = true;
            this.lblMeriendaD.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeriendaD.Location = new System.Drawing.Point(3, 210);
            this.lblMeriendaD.Name = "lblMeriendaD";
            this.lblMeriendaD.Size = new System.Drawing.Size(47, 17);
            this.lblMeriendaD.TabIndex = 25;
            this.lblMeriendaD.Text = "Snack";
            // 
            // btnSaveDieta
            // 
            this.btnSaveDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDieta.Location = new System.Drawing.Point(1150, 510);
            this.btnSaveDieta.Name = "btnSaveDieta";
            this.btnSaveDieta.Size = new System.Drawing.Size(160, 59);
            this.btnSaveDieta.TabIndex = 24;
            this.btnSaveDieta.Text = "Save";
            this.btnSaveDieta.UseVisualStyleBackColor = true;
            this.btnSaveDieta.Click += new System.EventHandler(this.btnSaveDieta_Click);
            // 
            // FrmDieta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1322, 573);
            this.Controls.Add(this.btnSaveDieta);
            this.Controls.Add(this.tlpDieta);
            this.Controls.Add(this.txtCenaDieta);
            this.Controls.Add(this.lblCenaDieta);
            this.Controls.Add(this.txtMerDieta);
            this.Controls.Add(this.lblMerDieta);
            this.Controls.Add(this.txtComDieta);
            this.Controls.Add(this.lblComDieta);
            this.Controls.Add(this.txtAlmuDieta);
            this.Controls.Add(this.lblAlmuDieta);
            this.Controls.Add(this.lblDesDieta);
            this.Controls.Add(this.txtDesDieta);
            this.Controls.Add(this.btnPerfilDieta);
            this.Controls.Add(this.btnCSDieta);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblFechaDieta);
            this.Controls.Add(this.lblDieta);
            this.Controls.Add(this.pcbLogoDieta);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmDieta";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmDieta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoDieta)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tlpDieta.ResumeLayout(false);
            this.tlpDieta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pcbLogoDieta;
        private System.Windows.Forms.Label lblDieta;
        private System.Windows.Forms.Label lblFechaDieta;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContacto;
        private System.Windows.Forms.Button btnRevisionDieta;
        private System.Windows.Forms.Button btnForoDieta;
        private System.Windows.Forms.Button btnDietaDieta;
        private System.Windows.Forms.Button btnAlternDieta;
        private System.Windows.Forms.Button btnCSDieta;
        private System.Windows.Forms.Button btnPerfilDieta;
        private System.Windows.Forms.TextBox txtDesDieta;
        private System.Windows.Forms.Label lblDesDieta;
        private System.Windows.Forms.Label lblAlmuDieta;
        private System.Windows.Forms.TextBox txtAlmuDieta;
        private System.Windows.Forms.TextBox txtComDieta;
        private System.Windows.Forms.Label lblComDieta;
        private System.Windows.Forms.TextBox txtMerDieta;
        private System.Windows.Forms.Label lblMerDieta;
        private System.Windows.Forms.TextBox txtCenaDieta;
        private System.Windows.Forms.Label lblCenaDieta;
        private System.Windows.Forms.TableLayoutPanel tlpDieta;
        private System.Windows.Forms.TextBox txtBFD;
        private System.Windows.Forms.TextBox txtBTHD;
        private System.Windows.Forms.TextBox txtBWD;
        private System.Windows.Forms.TextBox txtxBTD;
        private System.Windows.Forms.TextBox txtBMD;
        private System.Windows.Forms.Label lblCenaD;
        private System.Windows.Forms.Label lblAlmuerzoD;
        private System.Windows.Forms.Label lblDesayunoD;
        private System.Windows.Forms.Label lblDomingoD;
        private System.Windows.Forms.Label lblSabadoD;
        private System.Windows.Forms.Label lblViernesD;
        private System.Windows.Forms.Label lblJuevesD;
        private System.Windows.Forms.Label lblMiercolesD;
        private System.Windows.Forms.Label lblLunesD;
        private System.Windows.Forms.Label lblMartesD;
        private System.Windows.Forms.Label lblComidaD;
        private System.Windows.Forms.Label lblMeriendaD;
        private System.Windows.Forms.TextBox txtDSUD;
        private System.Windows.Forms.TextBox txtDSAD;
        private System.Windows.Forms.TextBox txtDFD;
        private System.Windows.Forms.TextBox txtDTHD;
        private System.Windows.Forms.TextBox txtDWD;
        private System.Windows.Forms.TextBox txtDTD;
        private System.Windows.Forms.TextBox txtDMD;
        private System.Windows.Forms.TextBox txtSSUD;
        private System.Windows.Forms.TextBox txtSSAD;
        private System.Windows.Forms.TextBox txtSFD;
        private System.Windows.Forms.TextBox txtSTHD;
        private System.Windows.Forms.TextBox txtSWD;
        private System.Windows.Forms.TextBox txtSTD;
        private System.Windows.Forms.TextBox txtSMD;
        private System.Windows.Forms.TextBox txtMSUD;
        private System.Windows.Forms.TextBox txtMSAD;
        private System.Windows.Forms.TextBox txtMFD;
        private System.Windows.Forms.TextBox txtMTHD;
        private System.Windows.Forms.TextBox txtMWD;
        private System.Windows.Forms.TextBox txtMTD;
        private System.Windows.Forms.TextBox txtMMD;
        private System.Windows.Forms.TextBox txtLSUD;
        private System.Windows.Forms.TextBox txtLSAD;
        private System.Windows.Forms.TextBox txtLFD;
        private System.Windows.Forms.TextBox txtLTHD;
        private System.Windows.Forms.TextBox txtLWD;
        private System.Windows.Forms.TextBox txtLTD;
        private System.Windows.Forms.TextBox txtLMD;
        private System.Windows.Forms.TextBox txtBSUD;
        private System.Windows.Forms.TextBox txtBSAD;
        private System.Windows.Forms.Button btnSaveDieta;
    }
}