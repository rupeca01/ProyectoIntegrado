﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmDieta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pcbLogoDieta = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblDieta = new System.Windows.Forms.Label();
            this.lblFechaDieta = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContacto = new System.Windows.Forms.Button();
            this.btnRevisionDieta = new System.Windows.Forms.Button();
            this.btnForoDieta = new System.Windows.Forms.Button();
            this.btnDietaDieta = new System.Windows.Forms.Button();
            this.btnAlternDieta = new System.Windows.Forms.Button();
            this.btnCSDieta = new System.Windows.Forms.Button();
            this.btnPerfilDieta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoDieta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pcbLogoDieta
            // 
            this.pcbLogoDieta.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoDieta.Name = "pcbLogoDieta";
            this.pcbLogoDieta.Size = new System.Drawing.Size(160, 148);
            this.pcbLogoDieta.TabIndex = 4;
            this.pcbLogoDieta.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(224, 126);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(714, 454);
            this.dataGridView1.TabIndex = 5;
            // 
            // lblDieta
            // 
            this.lblDieta.AutoSize = true;
            this.lblDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDieta.Location = new System.Drawing.Point(255, 35);
            this.lblDieta.Name = "lblDieta";
            this.lblDieta.Size = new System.Drawing.Size(88, 44);
            this.lblDieta.TabIndex = 6;
            this.lblDieta.Text = "Diet";
            // 
            // lblFechaDieta
            // 
            this.lblFechaDieta.AutoSize = true;
            this.lblFechaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaDieta.Location = new System.Drawing.Point(636, 52);
            this.lblFechaDieta.Name = "lblFechaDieta";
            this.lblFechaDieta.Size = new System.Drawing.Size(53, 24);
            this.lblFechaDieta.TabIndex = 9;
            this.lblFechaDieta.Text = "Date:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnContacto);
            this.panel1.Controls.Add(this.btnRevisionDieta);
            this.panel1.Controls.Add(this.btnForoDieta);
            this.panel1.Controls.Add(this.btnDietaDieta);
            this.panel1.Controls.Add(this.btnAlternDieta);
            this.panel1.Location = new System.Drawing.Point(12, 184);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 10;
            // 
            // btnContacto
            // 
            this.btnContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContacto.Location = new System.Drawing.Point(0, 260);
            this.btnContacto.Name = "btnContacto";
            this.btnContacto.Size = new System.Drawing.Size(160, 59);
            this.btnContacto.TabIndex = 4;
            this.btnContacto.Text = "Contact";
            this.btnContacto.UseVisualStyleBackColor = true;
            this.btnContacto.Click += new System.EventHandler(this.btnContacto_Click);
            // 
            // btnRevisionDieta
            // 
            this.btnRevisionDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionDieta.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionDieta.Name = "btnRevisionDieta";
            this.btnRevisionDieta.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionDieta.TabIndex = 3;
            this.btnRevisionDieta.Text = "Review";
            this.btnRevisionDieta.UseVisualStyleBackColor = true;
            this.btnRevisionDieta.Click += new System.EventHandler(this.btnRevisionDieta_Click);
            // 
            // btnForoDieta
            // 
            this.btnForoDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoDieta.Location = new System.Drawing.Point(0, 130);
            this.btnForoDieta.Name = "btnForoDieta";
            this.btnForoDieta.Size = new System.Drawing.Size(160, 59);
            this.btnForoDieta.TabIndex = 2;
            this.btnForoDieta.Text = "Forum";
            this.btnForoDieta.UseVisualStyleBackColor = true;
            this.btnForoDieta.Click += new System.EventHandler(this.btnForoDieta_Click);
            // 
            // btnDietaDieta
            // 
            this.btnDietaDieta.Enabled = false;
            this.btnDietaDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaDieta.Location = new System.Drawing.Point(0, 0);
            this.btnDietaDieta.Name = "btnDietaDieta";
            this.btnDietaDieta.Size = new System.Drawing.Size(160, 59);
            this.btnDietaDieta.TabIndex = 1;
            this.btnDietaDieta.Text = "Diet";
            this.btnDietaDieta.UseVisualStyleBackColor = true;
            // 
            // btnAlternDieta
            // 
            this.btnAlternDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternDieta.Location = new System.Drawing.Point(0, 65);
            this.btnAlternDieta.Name = "btnAlternDieta";
            this.btnAlternDieta.Size = new System.Drawing.Size(160, 59);
            this.btnAlternDieta.TabIndex = 0;
            this.btnAlternDieta.Text = "Alternatives";
            this.btnAlternDieta.UseVisualStyleBackColor = true;
            this.btnAlternDieta.Click += new System.EventHandler(this.btnAlternDieta_Click);
            // 
            // btnCSDieta
            // 
            this.btnCSDieta.Location = new System.Drawing.Point(891, 12);
            this.btnCSDieta.Name = "btnCSDieta";
            this.btnCSDieta.Size = new System.Drawing.Size(78, 26);
            this.btnCSDieta.TabIndex = 11;
            this.btnCSDieta.Text = "Log Out";
            this.btnCSDieta.UseVisualStyleBackColor = true;
            this.btnCSDieta.Click += new System.EventHandler(this.btnCSDieta_Click);
            // 
            // btnPerfilDieta
            // 
            this.btnPerfilDieta.Location = new System.Drawing.Point(975, 12);
            this.btnPerfilDieta.Name = "btnPerfilDieta";
            this.btnPerfilDieta.Size = new System.Drawing.Size(78, 26);
            this.btnPerfilDieta.TabIndex = 12;
            this.btnPerfilDieta.Text = "Profile";
            this.btnPerfilDieta.UseVisualStyleBackColor = true;
            this.btnPerfilDieta.Click += new System.EventHandler(this.btnPerfilDieta_Click);
            // 
            // FrmDieta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 692);
            this.Controls.Add(this.btnPerfilDieta);
            this.Controls.Add(this.btnCSDieta);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblFechaDieta);
            this.Controls.Add(this.lblDieta);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pcbLogoDieta);
            this.Name = "FrmDieta";
            this.Text = "FrmDieta";
            this.Load += new System.EventHandler(this.FrmDieta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoDieta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pcbLogoDieta;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblDieta;
        private System.Windows.Forms.Label lblFechaDieta;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContacto;
        private System.Windows.Forms.Button btnRevisionDieta;
        private System.Windows.Forms.Button btnForoDieta;
        private System.Windows.Forms.Button btnDietaDieta;
        private System.Windows.Forms.Button btnAlternDieta;
        private System.Windows.Forms.Button btnCSDieta;
        private System.Windows.Forms.Button btnPerfilDieta;
    }
}