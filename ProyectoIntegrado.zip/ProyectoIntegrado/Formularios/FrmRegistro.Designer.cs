﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRegistro));
            this.lblRegistro = new System.Windows.Forms.Label();
            this.pcbLogoRegistro = new System.Windows.Forms.PictureBox();
            this.lblNombreRegistro = new System.Windows.Forms.Label();
            this.txtNombreRegistro = new System.Windows.Forms.TextBox();
            this.lblApellidosRegistro = new System.Windows.Forms.Label();
            this.txtApellidosRegistro = new System.Windows.Forms.TextBox();
            this.lblEmailRegistro = new System.Windows.Forms.Label();
            this.txtEmailRegistro = new System.Windows.Forms.TextBox();
            this.lblPasswordRegistro = new System.Windows.Forms.Label();
            this.txtPasswordRegistro = new System.Windows.Forms.TextBox();
            this.btnRegistrarseRegistro = new System.Windows.Forms.Button();
            this.pbProfPicRegistro = new System.Windows.Forms.PictureBox();
            this.btnCargarRegistro = new System.Windows.Forms.Button();
            this.lblFpRegistro = new System.Windows.Forms.Label();
            this.lblSexoRegistro = new System.Windows.Forms.Label();
            this.grbSexoRegistro = new System.Windows.Forms.GroupBox();
            this.rdbFRegistro = new System.Windows.Forms.RadioButton();
            this.rdbHRegistro = new System.Windows.Forms.RadioButton();
            this.btnVolverRegistro = new System.Windows.Forms.Button();
            this.dtpFNRegistro = new System.Windows.Forms.DateTimePicker();
            this.lblFNacRegistro = new System.Windows.Forms.Label();
            this.opfdFotoRegistro = new System.Windows.Forms.OpenFileDialog();
            this.chkShowReg = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).BeginInit();
            this.grbSexoRegistro.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRegistro
            // 
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.Location = new System.Drawing.Point(443, 9);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(162, 44);
            this.lblRegistro.TabIndex = 1;
            this.lblRegistro.Text = "Register";
            // 
            // pcbLogoRegistro
            // 
            this.pcbLogoRegistro.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoRegistro.Location = new System.Drawing.Point(12, 64);
            this.pcbLogoRegistro.Name = "pcbLogoRegistro";
            this.pcbLogoRegistro.Size = new System.Drawing.Size(238, 148);
            this.pcbLogoRegistro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoRegistro.TabIndex = 2;
            this.pcbLogoRegistro.TabStop = false;
            // 
            // lblNombreRegistro
            // 
            this.lblNombreRegistro.AutoSize = true;
            this.lblNombreRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreRegistro.Location = new System.Drawing.Point(335, 120);
            this.lblNombreRegistro.Name = "lblNombreRegistro";
            this.lblNombreRegistro.Size = new System.Drawing.Size(70, 25);
            this.lblNombreRegistro.TabIndex = 4;
            this.lblNombreRegistro.Text = "Name:";
            // 
            // txtNombreRegistro
            // 
            this.txtNombreRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreRegistro.Location = new System.Drawing.Point(428, 117);
            this.txtNombreRegistro.Name = "txtNombreRegistro";
            this.txtNombreRegistro.Size = new System.Drawing.Size(236, 30);
            this.txtNombreRegistro.TabIndex = 6;
            // 
            // lblApellidosRegistro
            // 
            this.lblApellidosRegistro.AutoSize = true;
            this.lblApellidosRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidosRegistro.Location = new System.Drawing.Point(324, 183);
            this.lblApellidosRegistro.Name = "lblApellidosRegistro";
            this.lblApellidosRegistro.Size = new System.Drawing.Size(98, 25);
            this.lblApellidosRegistro.TabIndex = 7;
            this.lblApellidosRegistro.Text = "Surname:";
            // 
            // txtApellidosRegistro
            // 
            this.txtApellidosRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidosRegistro.Location = new System.Drawing.Point(428, 180);
            this.txtApellidosRegistro.Name = "txtApellidosRegistro";
            this.txtApellidosRegistro.Size = new System.Drawing.Size(236, 30);
            this.txtApellidosRegistro.TabIndex = 8;
            // 
            // lblEmailRegistro
            // 
            this.lblEmailRegistro.AutoSize = true;
            this.lblEmailRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRegistro.Location = new System.Drawing.Point(356, 328);
            this.lblEmailRegistro.Name = "lblEmailRegistro";
            this.lblEmailRegistro.Size = new System.Drawing.Size(73, 25);
            this.lblEmailRegistro.TabIndex = 9;
            this.lblEmailRegistro.Text = "E-mail:";
            // 
            // txtEmailRegistro
            // 
            this.txtEmailRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailRegistro.Location = new System.Drawing.Point(428, 325);
            this.txtEmailRegistro.Name = "txtEmailRegistro";
            this.txtEmailRegistro.Size = new System.Drawing.Size(236, 30);
            this.txtEmailRegistro.TabIndex = 10;
            // 
            // lblPasswordRegistro
            // 
            this.lblPasswordRegistro.AutoSize = true;
            this.lblPasswordRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordRegistro.Location = new System.Drawing.Point(302, 392);
            this.lblPasswordRegistro.Name = "lblPasswordRegistro";
            this.lblPasswordRegistro.Size = new System.Drawing.Size(104, 25);
            this.lblPasswordRegistro.TabIndex = 11;
            this.lblPasswordRegistro.Text = "Password:";
            // 
            // txtPasswordRegistro
            // 
            this.txtPasswordRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordRegistro.Location = new System.Drawing.Point(428, 389);
            this.txtPasswordRegistro.Name = "txtPasswordRegistro";
            this.txtPasswordRegistro.Size = new System.Drawing.Size(236, 30);
            this.txtPasswordRegistro.TabIndex = 12;
            // 
            // btnRegistrarseRegistro
            // 
            this.btnRegistrarseRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarseRegistro.Location = new System.Drawing.Point(426, 468);
            this.btnRegistrarseRegistro.Name = "btnRegistrarseRegistro";
            this.btnRegistrarseRegistro.Size = new System.Drawing.Size(238, 49);
            this.btnRegistrarseRegistro.TabIndex = 13;
            this.btnRegistrarseRegistro.Text = "Register";
            this.btnRegistrarseRegistro.UseVisualStyleBackColor = true;
            this.btnRegistrarseRegistro.Click += new System.EventHandler(this.btnRegistrarseRegistro_Click);
            // 
            // pbProfPicRegistro
            // 
            this.pbProfPicRegistro.Location = new System.Drawing.Point(754, 180);
            this.pbProfPicRegistro.Name = "pbProfPicRegistro";
            this.pbProfPicRegistro.Size = new System.Drawing.Size(248, 161);
            this.pbProfPicRegistro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbProfPicRegistro.TabIndex = 14;
            this.pbProfPicRegistro.TabStop = false;
            // 
            // btnCargarRegistro
            // 
            this.btnCargarRegistro.Location = new System.Drawing.Point(927, 347);
            this.btnCargarRegistro.Name = "btnCargarRegistro";
            this.btnCargarRegistro.Size = new System.Drawing.Size(75, 28);
            this.btnCargarRegistro.TabIndex = 15;
            this.btnCargarRegistro.Text = "Load";
            this.btnCargarRegistro.UseVisualStyleBackColor = true;
            this.btnCargarRegistro.Click += new System.EventHandler(this.btnCargarRegistro_Click);
            // 
            // lblFpRegistro
            // 
            this.lblFpRegistro.AutoSize = true;
            this.lblFpRegistro.Location = new System.Drawing.Point(751, 149);
            this.lblFpRegistro.Name = "lblFpRegistro";
            this.lblFpRegistro.Size = new System.Drawing.Size(99, 17);
            this.lblFpRegistro.TabIndex = 17;
            this.lblFpRegistro.Text = "Profile picture:";
            // 
            // lblSexoRegistro
            // 
            this.lblSexoRegistro.AutoSize = true;
            this.lblSexoRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSexoRegistro.Location = new System.Drawing.Point(349, 272);
            this.lblSexoRegistro.Name = "lblSexoRegistro";
            this.lblSexoRegistro.Size = new System.Drawing.Size(53, 25);
            this.lblSexoRegistro.TabIndex = 18;
            this.lblSexoRegistro.Text = "Sex:";
            // 
            // grbSexoRegistro
            // 
            this.grbSexoRegistro.Controls.Add(this.rdbFRegistro);
            this.grbSexoRegistro.Controls.Add(this.rdbHRegistro);
            this.grbSexoRegistro.Location = new System.Drawing.Point(433, 262);
            this.grbSexoRegistro.Name = "grbSexoRegistro";
            this.grbSexoRegistro.Size = new System.Drawing.Size(231, 44);
            this.grbSexoRegistro.TabIndex = 19;
            this.grbSexoRegistro.TabStop = false;
            // 
            // rdbFRegistro
            // 
            this.rdbFRegistro.AutoSize = true;
            this.rdbFRegistro.Location = new System.Drawing.Point(113, 15);
            this.rdbFRegistro.Name = "rdbFRegistro";
            this.rdbFRegistro.Size = new System.Drawing.Size(75, 21);
            this.rdbFRegistro.TabIndex = 1;
            this.rdbFRegistro.TabStop = true;
            this.rdbFRegistro.Text = "Female";
            this.rdbFRegistro.UseVisualStyleBackColor = true;
            // 
            // rdbHRegistro
            // 
            this.rdbHRegistro.AutoSize = true;
            this.rdbHRegistro.Location = new System.Drawing.Point(6, 14);
            this.rdbHRegistro.Name = "rdbHRegistro";
            this.rdbHRegistro.Size = new System.Drawing.Size(59, 21);
            this.rdbHRegistro.TabIndex = 0;
            this.rdbHRegistro.TabStop = true;
            this.rdbHRegistro.Text = "Male";
            this.rdbHRegistro.UseVisualStyleBackColor = true;
            // 
            // btnVolverRegistro
            // 
            this.btnVolverRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverRegistro.Location = new System.Drawing.Point(904, 530);
            this.btnVolverRegistro.Name = "btnVolverRegistro";
            this.btnVolverRegistro.Size = new System.Drawing.Size(98, 36);
            this.btnVolverRegistro.TabIndex = 20;
            this.btnVolverRegistro.Text = "Return";
            this.btnVolverRegistro.UseVisualStyleBackColor = true;
            this.btnVolverRegistro.Click += new System.EventHandler(this.btnVolverRegistro_Click);
            // 
            // dtpFNRegistro
            // 
            this.dtpFNRegistro.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFNRegistro.Location = new System.Drawing.Point(433, 228);
            this.dtpFNRegistro.Name = "dtpFNRegistro";
            this.dtpFNRegistro.Size = new System.Drawing.Size(159, 30);
            this.dtpFNRegistro.TabIndex = 22;
            // 
            // lblFNacRegistro
            // 
            this.lblFNacRegistro.AutoSize = true;
            this.lblFNacRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFNacRegistro.Location = new System.Drawing.Point(324, 233);
            this.lblFNacRegistro.Name = "lblFNacRegistro";
            this.lblFNacRegistro.Size = new System.Drawing.Size(95, 25);
            this.lblFNacRegistro.TabIndex = 21;
            this.lblFNacRegistro.Text = "Birthdate:";
            // 
            // opfdFotoRegistro
            // 
            this.opfdFotoRegistro.FileName = "openFileDialog1";
            // 
            // chkShowReg
            // 
            this.chkShowReg.AutoSize = true;
            this.chkShowReg.Location = new System.Drawing.Point(426, 425);
            this.chkShowReg.Name = "chkShowReg";
            this.chkShowReg.Size = new System.Drawing.Size(128, 21);
            this.chkShowReg.TabIndex = 23;
            this.chkShowReg.Text = "Show password";
            this.chkShowReg.UseVisualStyleBackColor = true;
            this.chkShowReg.CheckedChanged += new System.EventHandler(this.chkShowReg_CheckedChanged);
            // 
            // FrmRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 578);
            this.Controls.Add(this.chkShowReg);
            this.Controls.Add(this.dtpFNRegistro);
            this.Controls.Add(this.lblFNacRegistro);
            this.Controls.Add(this.btnVolverRegistro);
            this.Controls.Add(this.grbSexoRegistro);
            this.Controls.Add(this.lblSexoRegistro);
            this.Controls.Add(this.lblFpRegistro);
            this.Controls.Add(this.btnCargarRegistro);
            this.Controls.Add(this.pbProfPicRegistro);
            this.Controls.Add(this.btnRegistrarseRegistro);
            this.Controls.Add(this.txtPasswordRegistro);
            this.Controls.Add(this.lblPasswordRegistro);
            this.Controls.Add(this.txtEmailRegistro);
            this.Controls.Add(this.lblEmailRegistro);
            this.Controls.Add(this.txtApellidosRegistro);
            this.Controls.Add(this.lblApellidosRegistro);
            this.Controls.Add(this.txtNombreRegistro);
            this.Controls.Add(this.lblNombreRegistro);
            this.Controls.Add(this.pcbLogoRegistro);
            this.Controls.Add(this.lblRegistro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRegistro";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmRegistro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRegistro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).EndInit();
            this.grbSexoRegistro.ResumeLayout(false);
            this.grbSexoRegistro.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.PictureBox pcbLogoRegistro;
        private System.Windows.Forms.Label lblNombreRegistro;
        private System.Windows.Forms.TextBox txtNombreRegistro;
        private System.Windows.Forms.Label lblApellidosRegistro;
        private System.Windows.Forms.TextBox txtApellidosRegistro;
        private System.Windows.Forms.Label lblEmailRegistro;
        private System.Windows.Forms.TextBox txtEmailRegistro;
        private System.Windows.Forms.Label lblPasswordRegistro;
        private System.Windows.Forms.TextBox txtPasswordRegistro;
        private System.Windows.Forms.Button btnRegistrarseRegistro;
        private System.Windows.Forms.PictureBox pbProfPicRegistro;
        private System.Windows.Forms.Button btnCargarRegistro;
        private System.Windows.Forms.Label lblFpRegistro;
        private System.Windows.Forms.Label lblSexoRegistro;
        private System.Windows.Forms.GroupBox grbSexoRegistro;
        private System.Windows.Forms.RadioButton rdbFRegistro;
        private System.Windows.Forms.RadioButton rdbHRegistro;
        private System.Windows.Forms.Button btnVolverRegistro;
        private System.Windows.Forms.DateTimePicker dtpFNRegistro;
        private System.Windows.Forms.Label lblFNacRegistro;
        private System.Windows.Forms.OpenFileDialog opfdFotoRegistro;
        private System.Windows.Forms.CheckBox chkShowReg;
    }
}