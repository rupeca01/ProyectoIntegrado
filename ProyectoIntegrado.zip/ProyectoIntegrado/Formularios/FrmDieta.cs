﻿using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmDieta : Form
    {
        public FrmDieta()
        {
            InitializeComponent();
        }

        private void btnCSDieta_Click(object sender, EventArgs e)
        {
            FrmInicioSesion f2 = new FrmInicioSesion();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnPerfilDieta_Click(object sender, EventArgs e)
        {
            FrmPerfil f2 = new FrmPerfil();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void FrmDieta_Load(object sender, EventArgs e)
        {
            lblFechaDieta.Text = String.Format("Starting: {0} - Ending: {1}",Dieta.FechaInicio(FrmInicioSesion.mail),Dieta.FechaFinal(FrmInicioSesion.mail));
        }

        private void btnAlternDieta_Click(object sender, EventArgs e)
        {

        }

        private void btnForoDieta_Click(object sender, EventArgs e)
        {
            FrmForo f2 = new FrmForo();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnRevisionDieta_Click(object sender, EventArgs e)
        {
            FrmRevision f2 = new FrmRevision();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnContacto_Click(object sender, EventArgs e)
        {
            FrmContacto f2 = new FrmContacto();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }
    }
}
