﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmDieta : Form
    {
        public FrmDieta()
        {
            InitializeComponent();
        }

        private void btnCSDieta_Click(object sender, EventArgs e)
        {
            FrmInicioSesion f2 = new FrmInicioSesion();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnPerfilDieta_Click(object sender, EventArgs e)
        {
            FrmPerfil f2 = new FrmPerfil();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void FrmDieta_Load(object sender, EventArgs e)
        {
            try
            {
                ConexionBD.CerrarConexion();
                if (ConexionBD.Conexion != null)
                {

                    ConexionBD.AbrirConexion();
                    lblFechaDieta.Text = String.Format("Starting: {0} - Ending: {1}", Dieta.FechaInicio(FrmInicioSesion.mail), Dieta.FechaFinal(FrmInicioSesion.mail));
                    txtBMD.Text = Dieta.BajarOpciones("desayuno1", FrmInicioSesion.mail);
                    txtxBTD.Text = Dieta.BajarOpciones("desayuno2", FrmInicioSesion.mail);
                    txtBWD.Text = Dieta.BajarOpciones("desayuno3", FrmInicioSesion.mail);
                    txtBTHD.Text = Dieta.BajarOpciones("desayuno4", FrmInicioSesion.mail);
                    txtBFD.Text = Dieta.BajarOpciones("desayuno5", FrmInicioSesion.mail);
                    txtBSAD.Text = Dieta.BajarOpciones("desayuno6", FrmInicioSesion.mail);
                    txtBSUD.Text = Dieta.BajarOpciones("desayuno7", FrmInicioSesion.mail);


                    txtLMD.Text = Dieta.BajarOpciones("almuerzo1", FrmInicioSesion.mail);
                    txtLTD.Text = Dieta.BajarOpciones("almuerzo2", FrmInicioSesion.mail);
                    txtLWD.Text = Dieta.BajarOpciones("almuerzo3", FrmInicioSesion.mail);
                    txtLTHD.Text = Dieta.BajarOpciones("almuerzo4", FrmInicioSesion.mail);
                    txtLFD.Text = Dieta.BajarOpciones("almuerzo5", FrmInicioSesion.mail);
                    txtLSAD.Text = Dieta.BajarOpciones("almuerzo6", FrmInicioSesion.mail);
                    txtLSUD.Text = Dieta.BajarOpciones("almuerzo7", FrmInicioSesion.mail);


                    txtMMD.Text = Dieta.BajarOpciones("comidaa1", FrmInicioSesion.mail);
                    txtMTD.Text = Dieta.BajarOpciones("comidaa2", FrmInicioSesion.mail);
                    txtMWD.Text = Dieta.BajarOpciones("comidaa3", FrmInicioSesion.mail);
                    txtMTHD.Text = Dieta.BajarOpciones("comidaa4", FrmInicioSesion.mail);
                    txtMFD.Text = Dieta.BajarOpciones("comidaa5", FrmInicioSesion.mail);
                    txtMSAD.Text = Dieta.BajarOpciones("comidaa6", FrmInicioSesion.mail);
                    txtMSUD.Text = Dieta.BajarOpciones("comidaa7", FrmInicioSesion.mail);


                    txtSMD.Text = Dieta.BajarOpciones("merienda1", FrmInicioSesion.mail);
                    txtSTD.Text = Dieta.BajarOpciones("merienda2", FrmInicioSesion.mail);
                    txtSWD.Text = Dieta.BajarOpciones("merienda3", FrmInicioSesion.mail);
                    txtSTHD.Text = Dieta.BajarOpciones("merienda4", FrmInicioSesion.mail);
                    txtSFD.Text = Dieta.BajarOpciones("merienda5", FrmInicioSesion.mail);
                    txtSSAD.Text = Dieta.BajarOpciones("merienda6", FrmInicioSesion.mail);
                    txtSSUD.Text = Dieta.BajarOpciones("merienda7", FrmInicioSesion.mail);


                    txtDMD.Text = Dieta.BajarOpciones("cena1", FrmInicioSesion.mail);
                    txtDTD.Text = Dieta.BajarOpciones("cena2", FrmInicioSesion.mail);
                    txtDWD.Text = Dieta.BajarOpciones("cena3", FrmInicioSesion.mail);
                    txtDTHD.Text = Dieta.BajarOpciones("cena4", FrmInicioSesion.mail);
                    txtDFD.Text = Dieta.BajarOpciones("cena5", FrmInicioSesion.mail);
                    txtDSAD.Text = Dieta.BajarOpciones("cena6", FrmInicioSesion.mail);
                    txtDSUD.Text = Dieta.BajarOpciones("cena7", FrmInicioSesion.mail);

                    txtDesDieta.Text = Comidas.BajarComidas("desayuno", FrmInicioSesion.mail);
                    txtAlmuDieta.Text = Comidas.BajarComidas("almuerzo", FrmInicioSesion.mail);
                    txtComDieta.Text = Comidas.BajarComidas("comidaa", FrmInicioSesion.mail);
                    txtMerDieta.Text = Comidas.BajarComidas("merienda", FrmInicioSesion.mail);
                    txtCenaDieta.Text = Comidas.BajarComidas("cena", FrmInicioSesion.mail);
                    ConexionBD.CerrarConexion();
                }
                else
                {
                    MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    ConexionBD.CerrarConexion();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }

        private void btnAlternDieta_Click(object sender, EventArgs e)
        {
            FrmAlternativas f2 = new FrmAlternativas();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnForoDieta_Click(object sender, EventArgs e)
        {
            FrmForo f2 = new FrmForo();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnRevisionDieta_Click(object sender, EventArgs e)
        {
            FrmRevision f2 = new FrmRevision();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnContacto_Click(object sender, EventArgs e)
        {
            FrmContacto f2 = new FrmContacto();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnSaveDieta_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConexionBD.Conexion != null)
                {

                    ConexionBD.CerrarConexion();
                    ConexionBD.AbrirConexion();
                    int resultado = Dieta.SubirOpciones(FrmInicioSesion.mail, txtBMD.Text, txtxBTD.Text, txtBWD.Text, txtBTHD.Text, txtBFD.Text, txtBSAD.Text, txtBSUD.Text,
                                             txtLMD.Text, txtLTD.Text, txtLWD.Text, txtLTHD.Text, txtLFD.Text, txtLSAD.Text, txtLSUD.Text,
                                             txtMMD.Text, txtMTD.Text, txtMWD.Text, txtMTHD.Text, txtMFD.Text, txtMSAD.Text, txtMSUD.Text,
                                             txtSMD.Text, txtSTD.Text, txtSWD.Text, txtSTHD.Text, txtSFD.Text, txtSSAD.Text, txtSSUD.Text,
                                             txtDMD.Text, txtDTD.Text, txtDWD.Text, txtDTHD.Text, txtDFD.Text, txtDSAD.Text, txtDSUD.Text);
                    if (resultado > 0)
                    {
                        MessageBox.Show("Data saved correctly");
                        ConexionBD.CerrarConexion();
                    }
                    ConexionBD.CerrarConexion();

                }
                else
                {
                    MessageBox.Show("Couldn't connect to DB");
                    ConexionBD.CerrarConexion();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }

        private void pcbHelpDieta_Click(object sender, EventArgs e)
        {
            MessageBox.Show("In this table you can organize your own meals by writing them." +
                "\nClick on the 'save' button to save them for later.","Table using instructions");
        }
    }
}
