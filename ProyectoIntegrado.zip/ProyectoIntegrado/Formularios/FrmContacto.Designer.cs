﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmContacto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmContacto));
            this.lblContacto = new System.Windows.Forms.Label();
            this.pcbLogoContacto = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContactoContacto = new System.Windows.Forms.Button();
            this.btnRevisionContacto = new System.Windows.Forms.Button();
            this.btnForoContacto = new System.Windows.Forms.Button();
            this.btnDietaContacto = new System.Windows.Forms.Button();
            this.btnAlternContacto = new System.Windows.Forms.Button();
            this.btnPerfilDieta = new System.Windows.Forms.Button();
            this.btnCSDieta = new System.Windows.Forms.Button();
            this.lblAsuntoContacto = new System.Windows.Forms.Label();
            this.txtAsuntoContacto = new System.Windows.Forms.TextBox();
            this.lblMensajeContacto = new System.Windows.Forms.Label();
            this.txtMsgContacto = new System.Windows.Forms.TextBox();
            this.btnEnviarContacto = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoContacto)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblContacto
            // 
            this.lblContacto.AutoSize = true;
            this.lblContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContacto.Location = new System.Drawing.Point(256, 33);
            this.lblContacto.Name = "lblContacto";
            this.lblContacto.Size = new System.Drawing.Size(201, 44);
            this.lblContacto.TabIndex = 13;
            this.lblContacto.Text = "Contact us";
            // 
            // pcbLogoContacto
            // 
            this.pcbLogoContacto.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoContacto.Location = new System.Drawing.Point(12, 12);
            this.pcbLogoContacto.Name = "pcbLogoContacto";
            this.pcbLogoContacto.Size = new System.Drawing.Size(238, 148);
            this.pcbLogoContacto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoContacto.TabIndex = 11;
            this.pcbLogoContacto.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.btnContactoContacto);
            this.panel1.Controls.Add(this.btnRevisionContacto);
            this.panel1.Controls.Add(this.btnForoContacto);
            this.panel1.Controls.Add(this.btnDietaContacto);
            this.panel1.Controls.Add(this.btnAlternContacto);
            this.panel1.Location = new System.Drawing.Point(12, 166);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 320);
            this.panel1.TabIndex = 14;
            // 
            // btnContactoContacto
            // 
            this.btnContactoContacto.Enabled = false;
            this.btnContactoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactoContacto.Location = new System.Drawing.Point(0, 260);
            this.btnContactoContacto.Name = "btnContactoContacto";
            this.btnContactoContacto.Size = new System.Drawing.Size(160, 59);
            this.btnContactoContacto.TabIndex = 4;
            this.btnContactoContacto.Text = "Contact";
            this.btnContactoContacto.UseVisualStyleBackColor = true;
            this.btnContactoContacto.Click += new System.EventHandler(this.btnContactoContacto_Click);
            // 
            // btnRevisionContacto
            // 
            this.btnRevisionContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionContacto.Location = new System.Drawing.Point(0, 195);
            this.btnRevisionContacto.Name = "btnRevisionContacto";
            this.btnRevisionContacto.Size = new System.Drawing.Size(160, 59);
            this.btnRevisionContacto.TabIndex = 3;
            this.btnRevisionContacto.Text = "Review";
            this.btnRevisionContacto.UseVisualStyleBackColor = true;
            this.btnRevisionContacto.Click += new System.EventHandler(this.btnRevisionContacto_Click);
            // 
            // btnForoContacto
            // 
            this.btnForoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoContacto.Location = new System.Drawing.Point(0, 130);
            this.btnForoContacto.Name = "btnForoContacto";
            this.btnForoContacto.Size = new System.Drawing.Size(160, 59);
            this.btnForoContacto.TabIndex = 2;
            this.btnForoContacto.Text = "Forum";
            this.btnForoContacto.UseVisualStyleBackColor = true;
            this.btnForoContacto.Click += new System.EventHandler(this.btnForoContacto_Click);
            // 
            // btnDietaContacto
            // 
            this.btnDietaContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaContacto.Location = new System.Drawing.Point(0, 0);
            this.btnDietaContacto.Name = "btnDietaContacto";
            this.btnDietaContacto.Size = new System.Drawing.Size(160, 59);
            this.btnDietaContacto.TabIndex = 1;
            this.btnDietaContacto.Text = "Diet";
            this.btnDietaContacto.UseVisualStyleBackColor = true;
            this.btnDietaContacto.Click += new System.EventHandler(this.btnDietaContacto_Click);
            // 
            // btnAlternContacto
            // 
            this.btnAlternContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternContacto.Location = new System.Drawing.Point(0, 65);
            this.btnAlternContacto.Name = "btnAlternContacto";
            this.btnAlternContacto.Size = new System.Drawing.Size(160, 59);
            this.btnAlternContacto.TabIndex = 0;
            this.btnAlternContacto.Text = "Alternatives";
            this.btnAlternContacto.UseVisualStyleBackColor = true;
            this.btnAlternContacto.Click += new System.EventHandler(this.btnAlternContacto_Click);
            // 
            // btnPerfilDieta
            // 
            this.btnPerfilDieta.Location = new System.Drawing.Point(864, 12);
            this.btnPerfilDieta.Name = "btnPerfilDieta";
            this.btnPerfilDieta.Size = new System.Drawing.Size(78, 26);
            this.btnPerfilDieta.TabIndex = 16;
            this.btnPerfilDieta.Text = "Profile";
            this.btnPerfilDieta.UseVisualStyleBackColor = true;
            this.btnPerfilDieta.Click += new System.EventHandler(this.btnPerfilDieta_Click);
            // 
            // btnCSDieta
            // 
            this.btnCSDieta.Location = new System.Drawing.Point(780, 12);
            this.btnCSDieta.Name = "btnCSDieta";
            this.btnCSDieta.Size = new System.Drawing.Size(78, 26);
            this.btnCSDieta.TabIndex = 15;
            this.btnCSDieta.Text = "Log Out";
            this.btnCSDieta.UseVisualStyleBackColor = true;
            this.btnCSDieta.Click += new System.EventHandler(this.btnCSDieta_Click);
            // 
            // lblAsuntoContacto
            // 
            this.lblAsuntoContacto.AutoSize = true;
            this.lblAsuntoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAsuntoContacto.Location = new System.Drawing.Point(322, 136);
            this.lblAsuntoContacto.Name = "lblAsuntoContacto";
            this.lblAsuntoContacto.Size = new System.Drawing.Size(84, 25);
            this.lblAsuntoContacto.TabIndex = 17;
            this.lblAsuntoContacto.Text = "Subject:";
            // 
            // txtAsuntoContacto
            // 
            this.txtAsuntoContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAsuntoContacto.Location = new System.Drawing.Point(412, 133);
            this.txtAsuntoContacto.Name = "txtAsuntoContacto";
            this.txtAsuntoContacto.Size = new System.Drawing.Size(495, 30);
            this.txtAsuntoContacto.TabIndex = 18;
            // 
            // lblMensajeContacto
            // 
            this.lblMensajeContacto.AutoSize = true;
            this.lblMensajeContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensajeContacto.Location = new System.Drawing.Point(307, 213);
            this.lblMensajeContacto.Name = "lblMensajeContacto";
            this.lblMensajeContacto.Size = new System.Drawing.Size(99, 25);
            this.lblMensajeContacto.TabIndex = 19;
            this.lblMensajeContacto.Text = "Message:";
            // 
            // txtMsgContacto
            // 
            this.txtMsgContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMsgContacto.Location = new System.Drawing.Point(412, 210);
            this.txtMsgContacto.Multiline = true;
            this.txtMsgContacto.Name = "txtMsgContacto";
            this.txtMsgContacto.Size = new System.Drawing.Size(495, 293);
            this.txtMsgContacto.TabIndex = 20;
            // 
            // btnEnviarContacto
            // 
            this.btnEnviarContacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarContacto.Location = new System.Drawing.Point(412, 509);
            this.btnEnviarContacto.Name = "btnEnviarContacto";
            this.btnEnviarContacto.Size = new System.Drawing.Size(160, 59);
            this.btnEnviarContacto.TabIndex = 21;
            this.btnEnviarContacto.Text = "Send";
            this.btnEnviarContacto.UseVisualStyleBackColor = true;
            this.btnEnviarContacto.Click += new System.EventHandler(this.btnEnviarContacto_Click);
            // 
            // FrmContacto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 578);
            this.Controls.Add(this.btnEnviarContacto);
            this.Controls.Add(this.txtMsgContacto);
            this.Controls.Add(this.lblMensajeContacto);
            this.Controls.Add(this.txtAsuntoContacto);
            this.Controls.Add(this.lblAsuntoContacto);
            this.Controls.Add(this.btnPerfilDieta);
            this.Controls.Add(this.btnCSDieta);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblContacto);
            this.Controls.Add(this.pcbLogoContacto);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmContacto";
            this.Text = "DietU";
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoContacto)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblContacto;
        private System.Windows.Forms.PictureBox pcbLogoContacto;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContactoContacto;
        private System.Windows.Forms.Button btnRevisionContacto;
        private System.Windows.Forms.Button btnForoContacto;
        private System.Windows.Forms.Button btnDietaContacto;
        private System.Windows.Forms.Button btnAlternContacto;
        private System.Windows.Forms.Button btnPerfilDieta;
        private System.Windows.Forms.Button btnCSDieta;
        private System.Windows.Forms.Label lblAsuntoContacto;
        private System.Windows.Forms.TextBox txtAsuntoContacto;
        private System.Windows.Forms.Label lblMensajeContacto;
        private System.Windows.Forms.TextBox txtMsgContacto;
        private System.Windows.Forms.Button btnEnviarContacto;
    }
}