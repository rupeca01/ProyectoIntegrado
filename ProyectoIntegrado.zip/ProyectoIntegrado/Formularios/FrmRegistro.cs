﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmRegistro : Form
    {
        public FrmRegistro()
        {
            InitializeComponent();
        }

        private void btnRegistrarseRegistro_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            try
            {
                if (ConexionBD.Conexion != null)
                {
                    ConexionBD.CerrarConexion();
                    ConexionBD.AbrirConexion();
                    Usuario usu = new Usuario();
                    usu.Nombre = txtNombreRegistro.Text;
                    usu.Apellidos = txtApellidosRegistro.Text;
                    usu.Correo = txtEmailRegistro.Text;
                    usu.Contrasenya = txtPasswordRegistro.Text;
                    usu.FechaNacimiento = dtpFNRegistro.Value;
                    if (rdbHRegistro.Checked)
                    {
                        usu.Sexo = "male";
                    }
                    else if (rdbFRegistro.Checked)
                    {
                        usu.Sexo = "female";
                    }
                    List<Usuario> listaUsu = new List<Usuario>();
                    listaUsu = Usuario.BuscarUsuario(string.Format("SELECT idUsuario, nombre, apellidos, correo, contraseña, fecha_nacimiento  FROM usuario WHERE correo LIKE '{0}'", txtEmailRegistro.Text));
                    if (listaUsu.Count == 0)
                    {
                        resultado = usu.AgregarUsuario(usu);
                    }
                    else
                    {
                        MessageBox.Show("Ya hay un usuario con ese correo registrado.");
                    }
                    if (resultado > 0)
                    {
                        txtApellidosRegistro.Clear();
                        txtEmailRegistro.Clear();
                        txtNombreRegistro.Clear();
                        txtPasswordRegistro.Clear();
                        FrmInicioSesion f2 = new FrmInicioSesion();
                        this.Hide();
                        f2.ShowDialog();
                        this.Close();
                        this.Dispose();


                    }
                    ConexionBD.CerrarConexion();

                }
                else
                {
                    MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    ConexionBD.CerrarConexion();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }

        private void btnVolverRegistro_Click(object sender, EventArgs e)
        {
            FrmInicioSesion f2 = new FrmInicioSesion();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void FrmRegistro_Load(object sender, EventArgs e)
        {

        }
    }
}
