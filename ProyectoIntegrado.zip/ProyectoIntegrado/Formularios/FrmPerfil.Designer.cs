﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPerfil));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnContactoContacto = new System.Windows.Forms.Button();
            this.btnRevisionContacto = new System.Windows.Forms.Button();
            this.btnForoContacto = new System.Windows.Forms.Button();
            this.btnDietaContacto = new System.Windows.Forms.Button();
            this.btnAlternContacto = new System.Windows.Forms.Button();
            this.pcbLogoPerfil = new System.Windows.Forms.PictureBox();
            this.txtNombrePerfil = new System.Windows.Forms.TextBox();
            this.lblNombrePerfil = new System.Windows.Forms.Label();
            this.lblPerfil = new System.Windows.Forms.Label();
            this.lblApePerfil = new System.Windows.Forms.Label();
            this.txtApellidosPerfil = new System.Windows.Forms.TextBox();
            this.lblCorreoPerfil = new System.Windows.Forms.Label();
            this.txtCorreoPerfil = new System.Windows.Forms.TextBox();
            this.lblAlturaPerfil = new System.Windows.Forms.Label();
            this.txtAlturaPerfil = new System.Windows.Forms.TextBox();
            this.lblPesoPerfil = new System.Windows.Forms.Label();
            this.txtPesoPerfil = new System.Windows.Forms.TextBox();
            this.lblEdadPerfil = new System.Windows.Forms.Label();
            this.txtEdadPerfil = new System.Windows.Forms.TextBox();
            this.btnPerfilDieta = new System.Windows.Forms.Button();
            this.btnCSDieta = new System.Windows.Forms.Button();
            this.btnGuardarPerfil = new System.Windows.Forms.Button();
            this.lblFpRegistro = new System.Windows.Forms.Label();
            this.btnCargarRegistro = new System.Windows.Forms.Button();
            this.pbFotoPerfil = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoPerfil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFotoPerfil)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.btnContactoContacto);
            this.panel1.Controls.Add(this.btnRevisionContacto);
            this.panel1.Controls.Add(this.btnForoContacto);
            this.panel1.Controls.Add(this.btnDietaContacto);
            this.panel1.Controls.Add(this.btnAlternContacto);
            this.panel1.Location = new System.Drawing.Point(14, 197);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 360);
            this.panel1.TabIndex = 15;
            // 
            // btnContactoContacto
            // 
            this.btnContactoContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnContactoContacto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnContactoContacto.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContactoContacto.Location = new System.Drawing.Point(0, 292);
            this.btnContactoContacto.Name = "btnContactoContacto";
            this.btnContactoContacto.Size = new System.Drawing.Size(180, 66);
            this.btnContactoContacto.TabIndex = 4;
            this.btnContactoContacto.Text = "Contact";
            this.btnContactoContacto.UseVisualStyleBackColor = false;
            this.btnContactoContacto.Click += new System.EventHandler(this.btnContactoContacto_Click);
            // 
            // btnRevisionContacto
            // 
            this.btnRevisionContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRevisionContacto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRevisionContacto.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRevisionContacto.Location = new System.Drawing.Point(0, 219);
            this.btnRevisionContacto.Name = "btnRevisionContacto";
            this.btnRevisionContacto.Size = new System.Drawing.Size(180, 66);
            this.btnRevisionContacto.TabIndex = 3;
            this.btnRevisionContacto.Text = "Review";
            this.btnRevisionContacto.UseVisualStyleBackColor = false;
            this.btnRevisionContacto.Click += new System.EventHandler(this.btnRevisionContacto_Click);
            // 
            // btnForoContacto
            // 
            this.btnForoContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnForoContacto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnForoContacto.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForoContacto.Location = new System.Drawing.Point(0, 146);
            this.btnForoContacto.Name = "btnForoContacto";
            this.btnForoContacto.Size = new System.Drawing.Size(180, 66);
            this.btnForoContacto.TabIndex = 2;
            this.btnForoContacto.Text = "Forum";
            this.btnForoContacto.UseVisualStyleBackColor = false;
            this.btnForoContacto.Click += new System.EventHandler(this.btnForoContacto_Click);
            // 
            // btnDietaContacto
            // 
            this.btnDietaContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDietaContacto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDietaContacto.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDietaContacto.Location = new System.Drawing.Point(0, 0);
            this.btnDietaContacto.Name = "btnDietaContacto";
            this.btnDietaContacto.Size = new System.Drawing.Size(180, 66);
            this.btnDietaContacto.TabIndex = 1;
            this.btnDietaContacto.Text = "Diet";
            this.btnDietaContacto.UseVisualStyleBackColor = false;
            this.btnDietaContacto.Click += new System.EventHandler(this.btnDietaContacto_Click);
            // 
            // btnAlternContacto
            // 
            this.btnAlternContacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAlternContacto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAlternContacto.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlternContacto.Location = new System.Drawing.Point(0, 73);
            this.btnAlternContacto.Name = "btnAlternContacto";
            this.btnAlternContacto.Size = new System.Drawing.Size(180, 66);
            this.btnAlternContacto.TabIndex = 0;
            this.btnAlternContacto.Text = "Alternatives";
            this.btnAlternContacto.UseVisualStyleBackColor = false;
            this.btnAlternContacto.Click += new System.EventHandler(this.btnAlternContacto_Click);
            // 
            // pcbLogoPerfil
            // 
            this.pcbLogoPerfil.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoPerfil.Location = new System.Drawing.Point(14, 14);
            this.pcbLogoPerfil.Name = "pcbLogoPerfil";
            this.pcbLogoPerfil.Size = new System.Drawing.Size(268, 166);
            this.pcbLogoPerfil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoPerfil.TabIndex = 16;
            this.pcbLogoPerfil.TabStop = false;
            // 
            // txtNombrePerfil
            // 
            this.txtNombrePerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNombrePerfil.Enabled = false;
            this.txtNombrePerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombrePerfil.Location = new System.Drawing.Point(412, 191);
            this.txtNombrePerfil.Name = "txtNombrePerfil";
            this.txtNombrePerfil.Size = new System.Drawing.Size(265, 34);
            this.txtNombrePerfil.TabIndex = 18;
            // 
            // lblNombrePerfil
            // 
            this.lblNombrePerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNombrePerfil.AutoSize = true;
            this.lblNombrePerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombrePerfil.Location = new System.Drawing.Point(287, 191);
            this.lblNombrePerfil.Name = "lblNombrePerfil";
            this.lblNombrePerfil.Size = new System.Drawing.Size(93, 32);
            this.lblNombrePerfil.TabIndex = 17;
            this.lblNombrePerfil.Text = "Name:";
            // 
            // lblPerfil
            // 
            this.lblPerfil.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPerfil.AutoSize = true;
            this.lblPerfil.Font = new System.Drawing.Font("High Tower Text", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerfil.Location = new System.Drawing.Point(431, 55);
            this.lblPerfil.Name = "lblPerfil";
            this.lblPerfil.Size = new System.Drawing.Size(198, 71);
            this.lblPerfil.TabIndex = 19;
            this.lblPerfil.Text = "Profile";
            // 
            // lblApePerfil
            // 
            this.lblApePerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblApePerfil.AutoSize = true;
            this.lblApePerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApePerfil.Location = new System.Drawing.Point(238, 251);
            this.lblApePerfil.Name = "lblApePerfil";
            this.lblApePerfil.Size = new System.Drawing.Size(136, 32);
            this.lblApePerfil.TabIndex = 20;
            this.lblApePerfil.Text = "Surnames:";
            // 
            // txtApellidosPerfil
            // 
            this.txtApellidosPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtApellidosPerfil.Enabled = false;
            this.txtApellidosPerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidosPerfil.Location = new System.Drawing.Point(412, 252);
            this.txtApellidosPerfil.Name = "txtApellidosPerfil";
            this.txtApellidosPerfil.Size = new System.Drawing.Size(265, 34);
            this.txtApellidosPerfil.TabIndex = 21;
            // 
            // lblCorreoPerfil
            // 
            this.lblCorreoPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCorreoPerfil.AutoSize = true;
            this.lblCorreoPerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorreoPerfil.Location = new System.Drawing.Point(277, 315);
            this.lblCorreoPerfil.Name = "lblCorreoPerfil";
            this.lblCorreoPerfil.Size = new System.Drawing.Size(102, 32);
            this.lblCorreoPerfil.TabIndex = 22;
            this.lblCorreoPerfil.Text = "E-Mail:";
            // 
            // txtCorreoPerfil
            // 
            this.txtCorreoPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCorreoPerfil.Enabled = false;
            this.txtCorreoPerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreoPerfil.Location = new System.Drawing.Point(412, 316);
            this.txtCorreoPerfil.Name = "txtCorreoPerfil";
            this.txtCorreoPerfil.Size = new System.Drawing.Size(265, 34);
            this.txtCorreoPerfil.TabIndex = 23;
            // 
            // lblAlturaPerfil
            // 
            this.lblAlturaPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAlturaPerfil.AutoSize = true;
            this.lblAlturaPerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlturaPerfil.Location = new System.Drawing.Point(276, 374);
            this.lblAlturaPerfil.Name = "lblAlturaPerfil";
            this.lblAlturaPerfil.Size = new System.Drawing.Size(103, 32);
            this.lblAlturaPerfil.TabIndex = 24;
            this.lblAlturaPerfil.Text = "Height:";
            // 
            // txtAlturaPerfil
            // 
            this.txtAlturaPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAlturaPerfil.Enabled = false;
            this.txtAlturaPerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlturaPerfil.Location = new System.Drawing.Point(412, 376);
            this.txtAlturaPerfil.Name = "txtAlturaPerfil";
            this.txtAlturaPerfil.Size = new System.Drawing.Size(265, 34);
            this.txtAlturaPerfil.TabIndex = 25;
            // 
            // lblPesoPerfil
            // 
            this.lblPesoPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPesoPerfil.AutoSize = true;
            this.lblPesoPerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoPerfil.Location = new System.Drawing.Point(264, 438);
            this.lblPesoPerfil.Name = "lblPesoPerfil";
            this.lblPesoPerfil.Size = new System.Drawing.Size(108, 32);
            this.lblPesoPerfil.TabIndex = 26;
            this.lblPesoPerfil.Text = "Weight:";
            // 
            // txtPesoPerfil
            // 
            this.txtPesoPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPesoPerfil.Enabled = false;
            this.txtPesoPerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesoPerfil.Location = new System.Drawing.Point(412, 435);
            this.txtPesoPerfil.Name = "txtPesoPerfil";
            this.txtPesoPerfil.Size = new System.Drawing.Size(265, 34);
            this.txtPesoPerfil.TabIndex = 27;
            // 
            // lblEdadPerfil
            // 
            this.lblEdadPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEdadPerfil.AutoSize = true;
            this.lblEdadPerfil.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdadPerfil.Location = new System.Drawing.Point(308, 498);
            this.lblEdadPerfil.Name = "lblEdadPerfil";
            this.lblEdadPerfil.Size = new System.Drawing.Size(69, 32);
            this.lblEdadPerfil.TabIndex = 28;
            this.lblEdadPerfil.Text = "Age:";
            // 
            // txtEdadPerfil
            // 
            this.txtEdadPerfil.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEdadPerfil.Enabled = false;
            this.txtEdadPerfil.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEdadPerfil.Location = new System.Drawing.Point(412, 496);
            this.txtEdadPerfil.Name = "txtEdadPerfil";
            this.txtEdadPerfil.Size = new System.Drawing.Size(265, 34);
            this.txtEdadPerfil.TabIndex = 29;
            // 
            // btnPerfilDieta
            // 
            this.btnPerfilDieta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPerfilDieta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnPerfilDieta.Enabled = false;
            this.btnPerfilDieta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPerfilDieta.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerfilDieta.Location = new System.Drawing.Point(962, 14);
            this.btnPerfilDieta.Name = "btnPerfilDieta";
            this.btnPerfilDieta.Size = new System.Drawing.Size(88, 29);
            this.btnPerfilDieta.TabIndex = 31;
            this.btnPerfilDieta.Text = "Profile";
            this.btnPerfilDieta.UseVisualStyleBackColor = false;
            // 
            // btnCSDieta
            // 
            this.btnCSDieta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCSDieta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCSDieta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCSDieta.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCSDieta.Location = new System.Drawing.Point(867, 14);
            this.btnCSDieta.Name = "btnCSDieta";
            this.btnCSDieta.Size = new System.Drawing.Size(88, 29);
            this.btnCSDieta.TabIndex = 30;
            this.btnCSDieta.Text = "Log Out";
            this.btnCSDieta.UseVisualStyleBackColor = false;
            this.btnCSDieta.Click += new System.EventHandler(this.btnCSDieta_Click);
            // 
            // btnGuardarPerfil
            // 
            this.btnGuardarPerfil.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnGuardarPerfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnGuardarPerfil.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardarPerfil.Location = new System.Drawing.Point(937, 381);
            this.btnGuardarPerfil.Name = "btnGuardarPerfil";
            this.btnGuardarPerfil.Size = new System.Drawing.Size(94, 32);
            this.btnGuardarPerfil.TabIndex = 33;
            this.btnGuardarPerfil.Text = "Save";
            this.btnGuardarPerfil.UseVisualStyleBackColor = false;
            this.btnGuardarPerfil.Click += new System.EventHandler(this.btnGuardarPerfil_Click);
            // 
            // lblFpRegistro
            // 
            this.lblFpRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblFpRegistro.AutoSize = true;
            this.lblFpRegistro.Font = new System.Drawing.Font("High Tower Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFpRegistro.Location = new System.Drawing.Point(842, 158);
            this.lblFpRegistro.Name = "lblFpRegistro";
            this.lblFpRegistro.Size = new System.Drawing.Size(133, 22);
            this.lblFpRegistro.TabIndex = 38;
            this.lblFpRegistro.Text = "Profile picture:";
            // 
            // btnCargarRegistro
            // 
            this.btnCargarRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnCargarRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCargarRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCargarRegistro.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCargarRegistro.Location = new System.Drawing.Point(846, 381);
            this.btnCargarRegistro.Name = "btnCargarRegistro";
            this.btnCargarRegistro.Size = new System.Drawing.Size(84, 32);
            this.btnCargarRegistro.TabIndex = 36;
            this.btnCargarRegistro.Text = "Load";
            this.btnCargarRegistro.UseVisualStyleBackColor = false;
            this.btnCargarRegistro.Click += new System.EventHandler(this.btnCargarRegistro_Click);
            // 
            // pbFotoPerfil
            // 
            this.pbFotoPerfil.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pbFotoPerfil.Location = new System.Drawing.Point(846, 194);
            this.pbFotoPerfil.Name = "pbFotoPerfil";
            this.pbFotoPerfil.Size = new System.Drawing.Size(186, 181);
            this.pbFotoPerfil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFotoPerfil.TabIndex = 35;
            this.pbFotoPerfil.TabStop = false;
            // 
            // FrmPerfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1063, 622);
            this.Controls.Add(this.lblFpRegistro);
            this.Controls.Add(this.btnCargarRegistro);
            this.Controls.Add(this.pbFotoPerfil);
            this.Controls.Add(this.btnGuardarPerfil);
            this.Controls.Add(this.btnPerfilDieta);
            this.Controls.Add(this.btnCSDieta);
            this.Controls.Add(this.txtEdadPerfil);
            this.Controls.Add(this.lblEdadPerfil);
            this.Controls.Add(this.txtPesoPerfil);
            this.Controls.Add(this.lblPesoPerfil);
            this.Controls.Add(this.txtAlturaPerfil);
            this.Controls.Add(this.lblAlturaPerfil);
            this.Controls.Add(this.txtCorreoPerfil);
            this.Controls.Add(this.lblCorreoPerfil);
            this.Controls.Add(this.txtApellidosPerfil);
            this.Controls.Add(this.lblApePerfil);
            this.Controls.Add(this.lblPerfil);
            this.Controls.Add(this.txtNombrePerfil);
            this.Controls.Add(this.lblNombrePerfil);
            this.Controls.Add(this.pcbLogoPerfil);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("High Tower Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmPerfil";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmPerfil_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoPerfil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFotoPerfil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnContactoContacto;
        private System.Windows.Forms.Button btnRevisionContacto;
        private System.Windows.Forms.Button btnForoContacto;
        private System.Windows.Forms.Button btnDietaContacto;
        private System.Windows.Forms.Button btnAlternContacto;
        private System.Windows.Forms.PictureBox pcbLogoPerfil;
        private System.Windows.Forms.TextBox txtNombrePerfil;
        private System.Windows.Forms.Label lblNombrePerfil;
        private System.Windows.Forms.Label lblPerfil;
        private System.Windows.Forms.Label lblApePerfil;
        private System.Windows.Forms.TextBox txtApellidosPerfil;
        private System.Windows.Forms.Label lblCorreoPerfil;
        private System.Windows.Forms.TextBox txtCorreoPerfil;
        private System.Windows.Forms.Label lblAlturaPerfil;
        private System.Windows.Forms.TextBox txtAlturaPerfil;
        private System.Windows.Forms.Label lblPesoPerfil;
        private System.Windows.Forms.TextBox txtPesoPerfil;
        private System.Windows.Forms.Label lblEdadPerfil;
        private System.Windows.Forms.TextBox txtEdadPerfil;
        private System.Windows.Forms.Button btnPerfilDieta;
        private System.Windows.Forms.Button btnCSDieta;
        private System.Windows.Forms.Button btnGuardarPerfil;
        private System.Windows.Forms.Label lblFpRegistro;
        private System.Windows.Forms.Button btnCargarRegistro;
        private System.Windows.Forms.PictureBox pbFotoPerfil;
    }
}