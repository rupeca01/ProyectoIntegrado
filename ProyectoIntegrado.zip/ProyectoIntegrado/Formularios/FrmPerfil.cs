﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmPerfil : Form
    {
        public FrmPerfil()
        {
            InitializeComponent();
        }

        private void btnCargarRegistro_Click(object sender, EventArgs e)
        {

        }

        private void FrmPerfil_Load(object sender, EventArgs e)
        {
            Usuario usu = Usuario.CargaUsuario(FrmInicioSesion.mail);
            txtAlturaPerfil.Text = usu.Altura.ToString();
            txtApellidosPerfil.Text = usu.Apellidos;
            txtCorreoPerfil.Text = usu.Correo;
            txtEdadPerfil.Text = usu.CalcularEdad().ToString();
            txtNombrePerfil.Text = usu.Nombre;
            txtPesoPerfil.Text = usu.Peso.ToString();
        }
    }
}
