﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmPerfil : Form
    {
        public FrmPerfil()
        {
            InitializeComponent();
        }

        private void btnCargarRegistro_Click(object sender, EventArgs e)
        {

        }

        private void FrmPerfil_Load(object sender, EventArgs e)
        {
            ConexionBD.AbrirConexion();
            Usuario usu = Usuario.CargaUsuario(FrmInicioSesion.mail);
            txtAlturaPerfil.Text = usu.Altura.ToString();
            txtApellidosPerfil.Text = usu.Apellidos;
            txtCorreoPerfil.Text = usu.Correo;
            txtEdadPerfil.Text = usu.CalcularEdad().ToString();
            txtNombrePerfil.Text = usu.Nombre;
            txtPesoPerfil.Text = usu.Peso.ToString();
            ConexionBD.CerrarConexion();
        }

        private void btnDietaContacto_Click(object sender, EventArgs e)
        {
            FrmDieta f2 = new FrmDieta();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnAlternContacto_Click(object sender, EventArgs e)
        {
            FrmAlternativas f2 = new FrmAlternativas();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnForoContacto_Click(object sender, EventArgs e)
        {
            FrmForo f2 = new FrmForo();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnRevisionContacto_Click(object sender, EventArgs e)
        {
            FrmRevision f2 = new FrmRevision();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnContactoContacto_Click(object sender, EventArgs e)
        {
            FrmContacto f2 = new FrmContacto();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnCSDieta_Click(object sender, EventArgs e)
        {
            FrmInicioSesion f2 = new FrmInicioSesion();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }
    }
}
