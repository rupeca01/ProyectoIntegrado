﻿namespace ProyectoIntegrado
{
    partial class FrmInicioSesion
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInicioSesion));
            this.lblInicioSesion = new System.Windows.Forms.Label();
            this.pcbLogoInicio = new System.Windows.Forms.PictureBox();
            this.lblExplicacionInicio = new System.Windows.Forms.Label();
            this.lblCorreoInicio = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtEmailInicio = new System.Windows.Forms.TextBox();
            this.txtPasswordInicio = new System.Windows.Forms.TextBox();
            this.btnInicioSesion = new System.Windows.Forms.Button();
            this.lblRegistroInicio = new System.Windows.Forms.Label();
            this.linklblRegistro = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoInicio)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInicioSesion
            // 
            this.lblInicioSesion.AutoSize = true;
            this.lblInicioSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInicioSesion.Location = new System.Drawing.Point(532, 9);
            this.lblInicioSesion.Name = "lblInicioSesion";
            this.lblInicioSesion.Size = new System.Drawing.Size(113, 44);
            this.lblInicioSesion.TabIndex = 0;
            this.lblInicioSesion.Text = "Login";
            // 
            // pcbLogoInicio
            // 
            this.pcbLogoInicio.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoInicio.Location = new System.Drawing.Point(9, 30);
            this.pcbLogoInicio.Name = "pcbLogoInicio";
            this.pcbLogoInicio.Size = new System.Drawing.Size(382, 226);
            this.pcbLogoInicio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoInicio.TabIndex = 1;
            this.pcbLogoInicio.TabStop = false;
            // 
            // lblExplicacionInicio
            // 
            this.lblExplicacionInicio.AutoSize = true;
            this.lblExplicacionInicio.Location = new System.Drawing.Point(397, 93);
            this.lblExplicacionInicio.Name = "lblExplicacionInicio";
            this.lblExplicacionInicio.Size = new System.Drawing.Size(46, 17);
            this.lblExplicacionInicio.TabIndex = 2;
            this.lblExplicacionInicio.Text = "label1";
            // 
            // lblCorreoInicio
            // 
            this.lblCorreoInicio.AutoSize = true;
            this.lblCorreoInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorreoInicio.Location = new System.Drawing.Point(372, 327);
            this.lblCorreoInicio.Name = "lblCorreoInicio";
            this.lblCorreoInicio.Size = new System.Drawing.Size(73, 25);
            this.lblCorreoInicio.TabIndex = 3;
            this.lblCorreoInicio.Text = "E-mail:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(341, 395);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(104, 25);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            // 
            // txtEmailInicio
            // 
            this.txtEmailInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailInicio.Location = new System.Drawing.Point(469, 322);
            this.txtEmailInicio.Name = "txtEmailInicio";
            this.txtEmailInicio.Size = new System.Drawing.Size(236, 30);
            this.txtEmailInicio.TabIndex = 5;
            // 
            // txtPasswordInicio
            // 
            this.txtPasswordInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordInicio.Location = new System.Drawing.Point(467, 390);
            this.txtPasswordInicio.Name = "txtPasswordInicio";
            this.txtPasswordInicio.Size = new System.Drawing.Size(236, 30);
            this.txtPasswordInicio.TabIndex = 6;
            // 
            // btnInicioSesion
            // 
            this.btnInicioSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInicioSesion.Location = new System.Drawing.Point(467, 508);
            this.btnInicioSesion.Name = "btnInicioSesion";
            this.btnInicioSesion.Size = new System.Drawing.Size(238, 49);
            this.btnInicioSesion.TabIndex = 7;
            this.btnInicioSesion.Text = "Log In";
            this.btnInicioSesion.UseVisualStyleBackColor = true;
            this.btnInicioSesion.Click += new System.EventHandler(this.btnInicioSesion_Click);
            // 
            // lblRegistroInicio
            // 
            this.lblRegistroInicio.AutoSize = true;
            this.lblRegistroInicio.Location = new System.Drawing.Point(505, 444);
            this.lblRegistroInicio.Name = "lblRegistroInicio";
            this.lblRegistroInicio.Size = new System.Drawing.Size(73, 17);
            this.lblRegistroInicio.TabIndex = 8;
            this.lblRegistroInicio.Text = "First time?";
            // 
            // linklblRegistro
            // 
            this.linklblRegistro.AutoSize = true;
            this.linklblRegistro.Location = new System.Drawing.Point(584, 444);
            this.linklblRegistro.Name = "linklblRegistro";
            this.linklblRegistro.Size = new System.Drawing.Size(61, 17);
            this.linklblRegistro.TabIndex = 9;
            this.linklblRegistro.TabStop = true;
            this.linklblRegistro.Text = "Register";
            this.linklblRegistro.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblRegistro_LinkClicked);
            // 
            // FrmInicioSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 583);
            this.Controls.Add(this.linklblRegistro);
            this.Controls.Add(this.lblRegistroInicio);
            this.Controls.Add(this.btnInicioSesion);
            this.Controls.Add(this.txtPasswordInicio);
            this.Controls.Add(this.txtEmailInicio);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblCorreoInicio);
            this.Controls.Add(this.lblExplicacionInicio);
            this.Controls.Add(this.pcbLogoInicio);
            this.Controls.Add(this.lblInicioSesion);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmInicioSesion";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmInicioSesion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoInicio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInicioSesion;
        private System.Windows.Forms.PictureBox pcbLogoInicio;
        private System.Windows.Forms.Label lblExplicacionInicio;
        private System.Windows.Forms.Label lblCorreoInicio;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtEmailInicio;
        private System.Windows.Forms.TextBox txtPasswordInicio;
        private System.Windows.Forms.Button btnInicioSesion;
        private System.Windows.Forms.Label lblRegistroInicio;
        private System.Windows.Forms.LinkLabel linklblRegistro;
    }
}

