﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoIntegrado.Clases.Tests
{
    [TestClass()]
    public class ComidasTests
    {
        [TestMethod()]
        public void GenerarCaloriasDiariasTest()
        {
            string sexo = "hombre";
            decimal peso = 60;
            decimal altura = 170;
            int edad = 20;
            string objetivo = "Gain Muscle";
            double expected = 500;
            double actual;
            actual = Comidas.GenerarCaloriasDiarias(sexo, peso, altura, edad, objetivo);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void calcularProteinasTest()
        {
            decimal peso = 50;
            double expected = 200;
            double actual;
            actual = Comidas.calcularProteinas(peso);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void calcularGrasasTest()
        {
            decimal peso = 50;
            double expected = 200;
            double actual = Comidas.calcularGrasas(peso);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void calcularHidratosCarbonoTest()
        {
            string sexo = "hombre";
            decimal peso = 60;
            decimal altura = 170;
            int edad = 20;
            string objetivo = "Gain muscle";
            double expected = 500;
            double actual;
            actual = Comidas.calcularHidratosCarbono(sexo, peso, altura, edad, objetivo);
            Assert.AreEqual(expected, actual);
        }
    }
}