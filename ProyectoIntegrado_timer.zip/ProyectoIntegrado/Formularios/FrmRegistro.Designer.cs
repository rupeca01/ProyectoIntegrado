﻿namespace ProyectoIntegrado.Formularios
{
    partial class FrmRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRegistro));
            this.lblRegistro = new System.Windows.Forms.Label();
            this.pcbLogoRegistro = new System.Windows.Forms.PictureBox();
            this.lblNombreRegistro = new System.Windows.Forms.Label();
            this.txtNombreRegistro = new System.Windows.Forms.TextBox();
            this.lblApellidosRegistro = new System.Windows.Forms.Label();
            this.txtApellidosRegistro = new System.Windows.Forms.TextBox();
            this.lblEmailRegistro = new System.Windows.Forms.Label();
            this.txtEmailRegistro = new System.Windows.Forms.TextBox();
            this.lblPasswordRegistro = new System.Windows.Forms.Label();
            this.txtPasswordRegistro = new System.Windows.Forms.TextBox();
            this.btnRegistrarseRegistro = new System.Windows.Forms.Button();
            this.pbProfPicRegistro = new System.Windows.Forms.PictureBox();
            this.btnCargarRegistro = new System.Windows.Forms.Button();
            this.lblFpRegistro = new System.Windows.Forms.Label();
            this.lblSexoRegistro = new System.Windows.Forms.Label();
            this.grbSexoRegistro = new System.Windows.Forms.GroupBox();
            this.rdbFRegistro = new System.Windows.Forms.RadioButton();
            this.rdbHRegistro = new System.Windows.Forms.RadioButton();
            this.btnVolverRegistro = new System.Windows.Forms.Button();
            this.dtpFNRegistro = new System.Windows.Forms.DateTimePicker();
            this.lblFNacRegistro = new System.Windows.Forms.Label();
            this.opfdFotoRegistro = new System.Windows.Forms.OpenFileDialog();
            this.chkShowReg = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).BeginInit();
            this.grbSexoRegistro.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRegistro
            // 
            this.lblRegistro.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.Font = new System.Drawing.Font("High Tower Text", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.ForeColor = System.Drawing.Color.White;
            this.lblRegistro.Location = new System.Drawing.Point(427, 9);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(230, 71);
            this.lblRegistro.TabIndex = 1;
            this.lblRegistro.Text = "Register";
            // 
            // pcbLogoRegistro
            // 
            this.pcbLogoRegistro.Image = global::ProyectoIntegrado.Properties.Resources.DietU;
            this.pcbLogoRegistro.Location = new System.Drawing.Point(12, 21);
            this.pcbLogoRegistro.Name = "pcbLogoRegistro";
            this.pcbLogoRegistro.Size = new System.Drawing.Size(267, 191);
            this.pcbLogoRegistro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbLogoRegistro.TabIndex = 2;
            this.pcbLogoRegistro.TabStop = false;
            // 
            // lblNombreRegistro
            // 
            this.lblNombreRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNombreRegistro.AutoSize = true;
            this.lblNombreRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreRegistro.ForeColor = System.Drawing.Color.White;
            this.lblNombreRegistro.Location = new System.Drawing.Point(329, 115);
            this.lblNombreRegistro.Name = "lblNombreRegistro";
            this.lblNombreRegistro.Size = new System.Drawing.Size(93, 32);
            this.lblNombreRegistro.TabIndex = 4;
            this.lblNombreRegistro.Text = "Name:";
            // 
            // txtNombreRegistro
            // 
            this.txtNombreRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNombreRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreRegistro.Location = new System.Drawing.Point(428, 112);
            this.txtNombreRegistro.Name = "txtNombreRegistro";
            this.txtNombreRegistro.Size = new System.Drawing.Size(236, 39);
            this.txtNombreRegistro.TabIndex = 6;
            // 
            // lblApellidosRegistro
            // 
            this.lblApellidosRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblApellidosRegistro.AutoSize = true;
            this.lblApellidosRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidosRegistro.ForeColor = System.Drawing.Color.White;
            this.lblApellidosRegistro.Location = new System.Drawing.Point(294, 176);
            this.lblApellidosRegistro.Name = "lblApellidosRegistro";
            this.lblApellidosRegistro.Size = new System.Drawing.Size(125, 32);
            this.lblApellidosRegistro.TabIndex = 7;
            this.lblApellidosRegistro.Text = "Surname:";
            // 
            // txtApellidosRegistro
            // 
            this.txtApellidosRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtApellidosRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidosRegistro.Location = new System.Drawing.Point(428, 173);
            this.txtApellidosRegistro.Name = "txtApellidosRegistro";
            this.txtApellidosRegistro.Size = new System.Drawing.Size(236, 39);
            this.txtApellidosRegistro.TabIndex = 8;
            // 
            // lblEmailRegistro
            // 
            this.lblEmailRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEmailRegistro.AutoSize = true;
            this.lblEmailRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRegistro.ForeColor = System.Drawing.Color.White;
            this.lblEmailRegistro.Location = new System.Drawing.Point(324, 323);
            this.lblEmailRegistro.Name = "lblEmailRegistro";
            this.lblEmailRegistro.Size = new System.Drawing.Size(98, 32);
            this.lblEmailRegistro.TabIndex = 9;
            this.lblEmailRegistro.Text = "E-mail:";
            // 
            // txtEmailRegistro
            // 
            this.txtEmailRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailRegistro.Location = new System.Drawing.Point(428, 320);
            this.txtEmailRegistro.Name = "txtEmailRegistro";
            this.txtEmailRegistro.Size = new System.Drawing.Size(236, 39);
            this.txtEmailRegistro.TabIndex = 10;
            // 
            // lblPasswordRegistro
            // 
            this.lblPasswordRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPasswordRegistro.AutoSize = true;
            this.lblPasswordRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordRegistro.ForeColor = System.Drawing.Color.White;
            this.lblPasswordRegistro.Location = new System.Drawing.Point(292, 387);
            this.lblPasswordRegistro.Name = "lblPasswordRegistro";
            this.lblPasswordRegistro.Size = new System.Drawing.Size(130, 32);
            this.lblPasswordRegistro.TabIndex = 11;
            this.lblPasswordRegistro.Text = "Password:";
            // 
            // txtPasswordRegistro
            // 
            this.txtPasswordRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPasswordRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordRegistro.Location = new System.Drawing.Point(428, 384);
            this.txtPasswordRegistro.Name = "txtPasswordRegistro";
            this.txtPasswordRegistro.Size = new System.Drawing.Size(236, 39);
            this.txtPasswordRegistro.TabIndex = 12;
            // 
            // btnRegistrarseRegistro
            // 
            this.btnRegistrarseRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegistrarseRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRegistrarseRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRegistrarseRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarseRegistro.ForeColor = System.Drawing.Color.White;
            this.btnRegistrarseRegistro.Location = new System.Drawing.Point(426, 468);
            this.btnRegistrarseRegistro.Name = "btnRegistrarseRegistro";
            this.btnRegistrarseRegistro.Size = new System.Drawing.Size(238, 49);
            this.btnRegistrarseRegistro.TabIndex = 13;
            this.btnRegistrarseRegistro.Text = "Register";
            this.btnRegistrarseRegistro.UseVisualStyleBackColor = false;
            this.btnRegistrarseRegistro.Click += new System.EventHandler(this.btnRegistrarseRegistro_Click);
            // 
            // pbProfPicRegistro
            // 
            this.pbProfPicRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pbProfPicRegistro.Location = new System.Drawing.Point(754, 180);
            this.pbProfPicRegistro.Name = "pbProfPicRegistro";
            this.pbProfPicRegistro.Size = new System.Drawing.Size(248, 161);
            this.pbProfPicRegistro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbProfPicRegistro.TabIndex = 14;
            this.pbProfPicRegistro.TabStop = false;
            // 
            // btnCargarRegistro
            // 
            this.btnCargarRegistro.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnCargarRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnCargarRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCargarRegistro.ForeColor = System.Drawing.Color.White;
            this.btnCargarRegistro.Location = new System.Drawing.Point(927, 347);
            this.btnCargarRegistro.Name = "btnCargarRegistro";
            this.btnCargarRegistro.Size = new System.Drawing.Size(75, 28);
            this.btnCargarRegistro.TabIndex = 15;
            this.btnCargarRegistro.Text = "Load";
            this.btnCargarRegistro.UseVisualStyleBackColor = false;
            this.btnCargarRegistro.Click += new System.EventHandler(this.btnCargarRegistro_Click);
            // 
            // lblFpRegistro
            // 
            this.lblFpRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFpRegistro.AutoSize = true;
            this.lblFpRegistro.Font = new System.Drawing.Font("High Tower Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFpRegistro.ForeColor = System.Drawing.Color.White;
            this.lblFpRegistro.Location = new System.Drawing.Point(751, 150);
            this.lblFpRegistro.Name = "lblFpRegistro";
            this.lblFpRegistro.Size = new System.Drawing.Size(97, 18);
            this.lblFpRegistro.TabIndex = 17;
            this.lblFpRegistro.Text = "Profile picture:";
            // 
            // lblSexoRegistro
            // 
            this.lblSexoRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSexoRegistro.AutoSize = true;
            this.lblSexoRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSexoRegistro.ForeColor = System.Drawing.Color.White;
            this.lblSexoRegistro.Location = new System.Drawing.Point(354, 272);
            this.lblSexoRegistro.Name = "lblSexoRegistro";
            this.lblSexoRegistro.Size = new System.Drawing.Size(65, 32);
            this.lblSexoRegistro.TabIndex = 18;
            this.lblSexoRegistro.Text = "Sex:";
            // 
            // grbSexoRegistro
            // 
            this.grbSexoRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbSexoRegistro.Controls.Add(this.rdbFRegistro);
            this.grbSexoRegistro.Controls.Add(this.rdbHRegistro);
            this.grbSexoRegistro.Location = new System.Drawing.Point(428, 264);
            this.grbSexoRegistro.Name = "grbSexoRegistro";
            this.grbSexoRegistro.Size = new System.Drawing.Size(231, 44);
            this.grbSexoRegistro.TabIndex = 19;
            this.grbSexoRegistro.TabStop = false;
            // 
            // rdbFRegistro
            // 
            this.rdbFRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rdbFRegistro.AutoSize = true;
            this.rdbFRegistro.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbFRegistro.ForeColor = System.Drawing.Color.White;
            this.rdbFRegistro.Location = new System.Drawing.Point(125, 14);
            this.rdbFRegistro.Name = "rdbFRegistro";
            this.rdbFRegistro.Size = new System.Drawing.Size(80, 24);
            this.rdbFRegistro.TabIndex = 1;
            this.rdbFRegistro.TabStop = true;
            this.rdbFRegistro.Text = "Female";
            this.rdbFRegistro.UseVisualStyleBackColor = true;
            // 
            // rdbHRegistro
            // 
            this.rdbHRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rdbHRegistro.AutoSize = true;
            this.rdbHRegistro.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbHRegistro.ForeColor = System.Drawing.Color.White;
            this.rdbHRegistro.Location = new System.Drawing.Point(6, 14);
            this.rdbHRegistro.Name = "rdbHRegistro";
            this.rdbHRegistro.Size = new System.Drawing.Size(66, 24);
            this.rdbHRegistro.TabIndex = 0;
            this.rdbHRegistro.TabStop = true;
            this.rdbHRegistro.Text = "Male";
            this.rdbHRegistro.UseVisualStyleBackColor = true;
            // 
            // btnVolverRegistro
            // 
            this.btnVolverRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVolverRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnVolverRegistro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolverRegistro.Font = new System.Drawing.Font("High Tower Text", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverRegistro.ForeColor = System.Drawing.Color.White;
            this.btnVolverRegistro.Location = new System.Drawing.Point(884, 526);
            this.btnVolverRegistro.Name = "btnVolverRegistro";
            this.btnVolverRegistro.Size = new System.Drawing.Size(118, 40);
            this.btnVolverRegistro.TabIndex = 20;
            this.btnVolverRegistro.Text = "Return";
            this.btnVolverRegistro.UseVisualStyleBackColor = false;
            this.btnVolverRegistro.Click += new System.EventHandler(this.btnVolverRegistro_Click);
            // 
            // dtpFNRegistro
            // 
            this.dtpFNRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpFNRegistro.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFNRegistro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFNRegistro.Location = new System.Drawing.Point(428, 228);
            this.dtpFNRegistro.Name = "dtpFNRegistro";
            this.dtpFNRegistro.Size = new System.Drawing.Size(168, 30);
            this.dtpFNRegistro.TabIndex = 22;
            // 
            // lblFNacRegistro
            // 
            this.lblFNacRegistro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFNacRegistro.AutoSize = true;
            this.lblFNacRegistro.Font = new System.Drawing.Font("High Tower Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFNacRegistro.ForeColor = System.Drawing.Color.White;
            this.lblFNacRegistro.Location = new System.Drawing.Point(292, 228);
            this.lblFNacRegistro.Name = "lblFNacRegistro";
            this.lblFNacRegistro.Size = new System.Drawing.Size(127, 32);
            this.lblFNacRegistro.TabIndex = 21;
            this.lblFNacRegistro.Text = "Birthdate:";
            // 
            // opfdFotoRegistro
            // 
            this.opfdFotoRegistro.FileName = "openFileDialog1";
            // 
            // chkShowReg
            // 
            this.chkShowReg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkShowReg.AutoSize = true;
            this.chkShowReg.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowReg.ForeColor = System.Drawing.Color.White;
            this.chkShowReg.Location = new System.Drawing.Point(428, 429);
            this.chkShowReg.Name = "chkShowReg";
            this.chkShowReg.Size = new System.Drawing.Size(138, 24);
            this.chkShowReg.TabIndex = 23;
            this.chkShowReg.Text = "Show password";
            this.chkShowReg.UseVisualStyleBackColor = true;
            this.chkShowReg.CheckedChanged += new System.EventHandler(this.chkShowReg_CheckedChanged);
            // 
            // FrmRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1014, 578);
            this.Controls.Add(this.chkShowReg);
            this.Controls.Add(this.dtpFNRegistro);
            this.Controls.Add(this.lblFNacRegistro);
            this.Controls.Add(this.btnVolverRegistro);
            this.Controls.Add(this.grbSexoRegistro);
            this.Controls.Add(this.lblSexoRegistro);
            this.Controls.Add(this.lblFpRegistro);
            this.Controls.Add(this.btnCargarRegistro);
            this.Controls.Add(this.pbProfPicRegistro);
            this.Controls.Add(this.btnRegistrarseRegistro);
            this.Controls.Add(this.txtPasswordRegistro);
            this.Controls.Add(this.lblPasswordRegistro);
            this.Controls.Add(this.txtEmailRegistro);
            this.Controls.Add(this.lblEmailRegistro);
            this.Controls.Add(this.txtApellidosRegistro);
            this.Controls.Add(this.lblApellidosRegistro);
            this.Controls.Add(this.txtNombreRegistro);
            this.Controls.Add(this.lblNombreRegistro);
            this.Controls.Add(this.pcbLogoRegistro);
            this.Controls.Add(this.lblRegistro);
            this.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRegistro";
            this.Text = "DietU";
            this.Load += new System.EventHandler(this.FrmRegistro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbLogoRegistro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfPicRegistro)).EndInit();
            this.grbSexoRegistro.ResumeLayout(false);
            this.grbSexoRegistro.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.PictureBox pcbLogoRegistro;
        private System.Windows.Forms.Label lblNombreRegistro;
        private System.Windows.Forms.TextBox txtNombreRegistro;
        private System.Windows.Forms.Label lblApellidosRegistro;
        private System.Windows.Forms.TextBox txtApellidosRegistro;
        private System.Windows.Forms.Label lblEmailRegistro;
        private System.Windows.Forms.TextBox txtEmailRegistro;
        private System.Windows.Forms.Label lblPasswordRegistro;
        private System.Windows.Forms.TextBox txtPasswordRegistro;
        private System.Windows.Forms.Button btnRegistrarseRegistro;
        private System.Windows.Forms.PictureBox pbProfPicRegistro;
        private System.Windows.Forms.Button btnCargarRegistro;
        private System.Windows.Forms.Label lblFpRegistro;
        private System.Windows.Forms.Label lblSexoRegistro;
        private System.Windows.Forms.GroupBox grbSexoRegistro;
        private System.Windows.Forms.RadioButton rdbFRegistro;
        private System.Windows.Forms.RadioButton rdbHRegistro;
        private System.Windows.Forms.Button btnVolverRegistro;
        private System.Windows.Forms.DateTimePicker dtpFNRegistro;
        private System.Windows.Forms.Label lblFNacRegistro;
        private System.Windows.Forms.OpenFileDialog opfdFotoRegistro;
        private System.Windows.Forms.CheckBox chkShowReg;
    }
}