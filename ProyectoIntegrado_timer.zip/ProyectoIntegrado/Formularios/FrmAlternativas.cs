﻿using aev7;
using ProyectoIntegrado.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoIntegrado.Formularios
{
    public partial class FrmAlternativas : Form
    {
        private void CargaListaAlimentos(string tipo)
        {
            if (ConexionBD.Conexion != null)
            {
                ConexionBD.AbrirConexion();
                dtgvAlt.DataSource = Alimento.BuscarAlimentos(tipo);
                ConexionBD.CerrarConexion();
            }
            else
            {
                MessageBox.Show("No existe conexión a la Base de datos");
            }
        }
        public FrmAlternativas()
        {
            InitializeComponent();
        }

        private void btnDietaAlt_Click(object sender, EventArgs e)
        {
            FrmDieta f2 = new FrmDieta();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnForoAlt_Click(object sender, EventArgs e)
        {
            FrmForo f2 = new FrmForo();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnRevisionAlt_Click(object sender, EventArgs e)
        {
            FrmRevision f2 = new FrmRevision();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnContactoAlt_Click(object sender, EventArgs e)
        {
            FrmContacto f2 = new FrmContacto();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnCSAlt_Click(object sender, EventArgs e)
        {
            FrmInicioSesion f2 = new FrmInicioSesion();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void btnPerfilAlt_Click(object sender, EventArgs e)
        {
            FrmPerfil f2 = new FrmPerfil();
            this.Hide();
            f2.ShowDialog();
            this.Close();
            this.Dispose();
        }

        private void FrmAlternativas_Load(object sender, EventArgs e)
        {
            dtgvAlt.DefaultCellStyle.ForeColor = Color.White;
            dtgvAlt.DefaultCellStyle.BackColor = Color.Black;
            dtgvAlt.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dtgvAlt.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dtgvAlt.EnableHeadersVisualStyles = false;
            dtgvAlt.RowHeadersDefaultCellStyle.BackColor = Color.Black;
        }

        private void rdbProteinAlt_CheckedChanged(object sender, EventArgs e)
        {
            CargaListaAlimentos("Protein");
        }

        private void rdbFatsAlt_CheckedChanged(object sender, EventArgs e)
        {
            CargaListaAlimentos("Fats");
        }

        private void rdbCarboAlt_CheckedChanged(object sender, EventArgs e)
        {
            CargaListaAlimentos("Carbohydrates");
        }

        private void dtgvAlt_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnCalcAlt_Click(object sender, EventArgs e)
        {


            if (dtgvAlt.SelectedRows.Count == 1) // Si hay una fila seleccionada en el datagridview
            {
                int calorias = Convert.ToInt32( dtgvAlt.CurrentRow.Cells[0].Value); // Obtenemos el dni de la fila seleccionada
                txtQuantAlt.Text = Alimento.Calculadora(calorias, Convert.ToInt32(txtCalAlt.Text)).ToString("F");


            }

        }

        private void pcbHelpAlt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Click on the empty space of the row you want to select.\n" +
                "2. Input the number of calories that you want to be calculated on the calories field.\n" +
                "3. Click on the 'Calculate' button.", "Calculator instructions");
        }
    }
}
